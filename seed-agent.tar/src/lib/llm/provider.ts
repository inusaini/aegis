// LLM Provider abstraction for the AI Seed Release Agent.
// Adapted from spec section 5 — we use z-ai-web-dev-sdk as the LLM gateway
// (equivalent to 9Router). The agent layer depends only on the LLMProvider
// interface so the underlying provider can be swapped without touching agent logic.

import ZAI from 'z-ai-web-dev-sdk';
import type { LLMMessage, LLMCompletionResult } from '../agent/types';

export interface LLMProvider {
  complete(messages: LLMMessage[]): Promise<LLMCompletionResult>;
  completeJson<T = unknown>(messages: LLMMessage[]): Promise<{ data: T; raw: string }>;
}

/**
 * Default LLM provider backed by z-ai-web-dev-sdk (the OpenAI-compatible
 * gateway available in this environment — equivalent to the spec's 9Router).
 */
export class ZAILLMProvider implements LLMProvider {
  private client: Awaited<ReturnType<typeof ZAI.create>> | null = null;

  private async getClient() {
    if (!this.client) {
      this.client = await ZAI.create();
    }
    return this.client;
  }

  async complete(messages: LLMMessage[]): Promise<LLMCompletionResult> {
    const client = await this.getClient();
    const completion = await client.chat.completions.create({
      messages: messages.map((m) => ({ role: m.role, content: m.content })),
      thinking: { type: 'disabled' },
    });
    const content = completion.choices[0]?.message?.content ?? '';
    return { content };
  }

  async completeJson<T = unknown>(messages: LLMMessage[]): Promise<{ data: T; raw: string }> {
    const raw = (await this.complete(messages)).content;
    const data = safeParseJson<T>(raw);
    return { data, raw };
  }
}

function safeParseJson<T>(raw: string): T {
  // Try to find a JSON object or array in the response (LLMs sometimes wrap in prose)
  const trimmed = raw.trim();
  try {
    return JSON.parse(trimmed) as T;
  } catch {
    // fall through
  }
  const objStart = trimmed.indexOf('{');
  const arrStart = trimmed.indexOf('[');
  let start = -1;
  if (objStart >= 0 && (arrStart < 0 || objStart < arrStart)) start = objStart;
  else if (arrStart >= 0) start = arrStart;
  if (start >= 0) {
    const lastObj = trimmed.lastIndexOf('}');
    const lastArr = trimmed.lastIndexOf(']');
    let end = -1;
    if (lastObj >= 0 && (lastArr < 0 || lastObj > lastArr)) end = lastObj;
    else if (lastArr >= 0) end = lastArr;
    if (end > start) {
      const slice = trimmed.slice(start, end + 1);
      try {
        return JSON.parse(slice) as T;
      } catch {
        // ignore
      }
    }
  }
  return {} as T;
}

let _provider: LLMProvider | null = null;

export function getLLMProvider(): LLMProvider {
  if (!_provider) _provider = new ZAILLMProvider();
  return _provider;
}

export function setLLMProvider(provider: LLMProvider): void {
  _provider = provider;
}
