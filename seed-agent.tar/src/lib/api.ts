// Typed API client for the AI Seed Release Agent.

// ---------- Common ----------
export interface AgentRunSummary {
  id: string;
  runId: string;
  userRequest: string;
  mode: 'observe' | 'plan' | 'execute' | 'release' | 'recover';
  status: 'pending' | 'running' | 'completed' | 'failed' | 'blocked' | 'cancelled';
  currentStep: string;
  requestIntent?: string;
  retryCount: number;
  warnings: string[];
  errors: string[];
  summary?: string;
  createdAt: string;
  startedAt?: string;
  finishedAt?: string;
  releases?: ReleaseSummary[];
}

export interface WorkflowStateRow {
  id: string;
  step: string;
  status: string;
  data?: Record<string, unknown>;
  attempts: number;
  startedAt?: string;
  finishedAt?: string;
  createdAt: string;
}

export interface AgentActionRow {
  id: string;
  agent: string;
  tool: string;
  args: Record<string, unknown>;
  result?: Record<string, unknown>;
  risk: 'read' | 'write' | 'destructive';
  status: 'pending' | 'success' | 'failed' | 'blocked';
  reason: string;
  createdAt: string;
}

export interface AgentEventRow {
  id: string;
  event: string;
  payload: Record<string, unknown>;
  timestamp: string;
}

// ---------- Jira ----------
export interface JiraComment {
  id: string;
  author: string;
  body: string;
  createdAt: string;
}
export interface JiraAttachment {
  id: string;
  filename: string;
  mimeType: string;
  size: number;
  content: string;
  isApproval: boolean;
  createdAt: string;
}
export interface JiraApprovalEvidence {
  id: string;
  source: string;
  evidence: string;
  confidence: number;
  createdAt: string;
}
export interface JiraTicket {
  id: string;
  key: string;
  projectKey: string;
  summary: string;
  description: string;
  status: string;
  assignee?: string;
  reporter?: string;
  approvalField?: string;
  prUrl?: string;
  comments: JiraComment[];
  attachments: JiraAttachment[];
  approvals: JiraApprovalEvidence[];
  pullRequest?: PullRequest;
  createdAt: string;
  updatedAt: string;
}

// ---------- Pull Requests ----------
export interface CommitInfo {
  sha: string;
  message: string;
  author: string;
}
export interface FileChangeInfo {
  path: string;
  additions: number;
  deletions: number;
}
export interface PullRequest {
  id: string;
  prNumber: number;
  title: string;
  sourceBranch: string;
  targetBranch: string;
  state: string;
  description?: string;
  author: string;
  reviewStatus: string;
  reviewers: number;
  requiredReviewers: number;
  approved: boolean;
  mergeable: boolean;
  jiraTicket?: JiraTicket | null;
  commits: CommitInfo[];
  filesChanged: FileChangeInfo[];
  mergeResults?: MergeResult[];
  createdAt: string;
}
export interface MergeResult {
  id: string;
  strategy: string;
  commitSha?: string;
  status: string;
  filesChanged: { path: string }[];
  output?: string;
  createdAt: string;
}

// ---------- Conflicts ----------
export interface ConflictRecord {
  id: string;
  conflictId: string;
  file: string;
  base: unknown;
  ours: unknown;
  theirs: unknown;
  riskLevel: 'low' | 'medium' | 'high';
  status: 'detected' | 'analyzing' | 'resolved' | 'blocked' | 'failed';
  createdAt: string;
  updatedAt: string;
  resolution?: ConflictResolution | null;
  pullRequest?: { prNumber: number; jiraTicket?: { key: string; summary: string } | null } | null;
}
export interface ConflictResolution {
  id: string;
  strategy: 'semantic_merge' | 'ours' | 'theirs' | 'manual_block' | 'custom';
  proposed: unknown;
  final: unknown;
  riskLevel: 'low' | 'medium' | 'high';
  confidence: number;
  reasoning?: string;
  evidence: string[];
  validationPassed: boolean;
  appliedAt?: string;
  createdAt: string;
}

// ---------- Releases ----------
export interface ReleaseSummary {
  id: string;
  releaseId: string;
  runId?: string;
  targetBranch: string;
  releaseBranch?: string;
  status: string;
  totalTickets: number;
  approvedTickets: number;
  alreadyMerged: number;
  toIntegrate: number;
  conflictsCount: number;
  recordsAdded: number;
  recordsUpdated: number;
  recordsDeleted: number;
  riskLevel: 'low' | 'medium' | 'high';
  planJson?: Record<string, unknown>;
  validationJson?: Record<string, unknown> | null;
  createdAt: string;
  updatedAt: string;
  deployments?: Deployment[];
  repository?: { name: string; targetBranch: string };
  items?: ReleaseItem[];
}
export interface ReleaseItem {
  id: string;
  jiraTicket?: { key: string; summary: string };
  pullRequest?: { prNumber: number; title: string; sourceBranch: string };
  strategy: string;
  executionOrder: number;
  status: string;
  reason?: string;
}

// ---------- Deployments ----------
export interface Deployment {
  id: string;
  deploymentId: string;
  releaseId: string;
  jenkinsJob: string;
  buildNumber?: number;
  branch?: string;
  parameters: Record<string, unknown>;
  status: 'pending' | 'queued' | 'building' | 'success' | 'failed' | 'aborted' | 'retrying';
  stage?: string;
  consoleLog?: string;
  failureAnalysis?: {
    status: string;
    likelyCause: string;
    evidence: string[];
    retryable: boolean;
    recommendedAction: string;
    confidence: number;
  } | null;
  retryCount: number;
  startedAt?: string;
  finishedAt?: string;
  durationMs?: number;
  createdAt: string;
  updatedAt: string;
  release?: ReleaseSummary;
}

// ---------- Audit ----------
export interface AuditLog {
  id: string;
  actor: string;
  action: string;
  resource?: string;
  reason?: string;
  result: 'success' | 'failed' | 'blocked';
  metadata?: Record<string, unknown>;
  createdAt: string;
  run?: { runId: string } | null;
  pullRequest?: { prNumber: number } | null;
  ticket?: { key: string } | null;
}

// ---------- Live run state (from /api/agent/runs/:id) ----------
export interface LiveRunState {
  workflowId: string;
  mode: string;
  currentStep: string;
  status: string;
  jiraTickets: number;
  pullRequests: number;
  correlations: number;
  approvedTickets: number;
  conflicts: ConflictRecord[];
  conflictResolutions: ConflictResolution[];
  releasePlan?: {
    releaseId: string;
    targetBranch: string;
    items: {
      id: string;
      jiraTicketKey: string;
      prNumber: number;
      strategy: string;
      executionOrder: number;
      reason: string;
      status: string;
    }[];
    dependencies: { from: string; to: string; reason: string }[];
    conflicts: string[];
    alreadyIntegrated: string[];
    skipped: string[];
    executionOrder: string[];
    justification?: string;
  } | null;
  validationReport?: {
    filesChanged: number;
    recordsAdded: number;
    recordsUpdated: number;
    recordsDeleted: number;
    results: { validator: string; file?: string; status: string; message: string }[];
    warnings: string[];
    errors: string[];
    riskLevel: string;
    passed: boolean;
  } | null;
  mergeResults: { prNumber: number; strategy: string; commitSha?: string; status: string }[];
  deployment?: {
    deploymentId: string;
    jenkinsJob: string;
    buildNumber?: number;
    status: string;
    stage?: string;
    consoleLog?: string;
    failureAnalysis?: {
      status: string;
      likelyCause: string;
      evidence: string[];
      retryable: boolean;
      recommendedAction: string;
      confidence: number;
    } | null;
    retryCount: number;
    durationMs?: number;
  } | null;
  warnings: string[];
  errors: string[];
}

export interface RunDetailResponse {
  run: AgentRunSummary;
  liveState: LiveRunState | null;
  workflowStates: WorkflowStateRow[];
  agentActions: AgentActionRow[];
  events: AgentEventRow[];
  releases: ReleaseSummary[];
}

// ---------- Dashboard ----------
export interface DashboardResponse {
  metrics: {
    activeRuns: number;
    approvedTickets: number;
    pendingTickets: number;
    blockedTickets: number;
    approvedPRs: number;
    blockedPRs: number;
    activeConflicts: number;
    resolvedConflicts: number;
    blockedConflicts: number;
    recentFailures: number;
    successfulReleases: number;
    totalReleases: number;
    totalTickets: number;
    totalPRs: number;
  };
  recentRuns: AgentRunSummary[];
  recentReleases: ReleaseSummary[];
  recentDeployments: Deployment[];
  recentConflicts: ConflictRecord[];
  recentAudit: AuditLog[];
  liveRunIds: string[];
}

// ---------- Fetch helpers ----------
async function getJSON<T>(path: string): Promise<T> {
  const res = await fetch(path, { cache: 'no-store' });
  if (!res.ok) throw new Error(`${res.status} ${res.statusText} on ${path}`);
  return (await res.json()) as T;
}
async function postJSON<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => '');
    throw new Error(`${res.status} ${res.statusText} on ${path}: ${txt}`);
  }
  return (await res.json()) as T;
}

export const api = {
  dashboard: () => getJSON<DashboardResponse>('/api/dashboard'),
  listRuns: () => getJSON<{ runs: AgentRunSummary[] }>('/api/agent/runs'),
  getRun: (runId: string) => getJSON<RunDetailResponse>(`/api/agent/runs/${encodeURIComponent(runId)}`),
  startRun: (userRequest: string, mode: string) =>
    postJSON<{ runId: string; status: string }>('/api/agent/runs', { userRequest, mode }),
  resumeRun: (runId: string) => postJSON<{ runId: string; status: string }>(`/api/agent/runs/${encodeURIComponent(runId)}/resume`, {}),
  cancelRun: (runId: string) => postJSON<{ runId: string; status: string }>(`/api/agent/runs/${encodeURIComponent(runId)}/cancel`, {}),
  listReleases: () => getJSON<{ releases: ReleaseSummary[] }>('/api/releases'),
  getRelease: (id: string) => getJSON<{ release: ReleaseSummary & { items?: ReleaseItem[]; deployments?: Deployment[]; repository?: { name: string; targetBranch: string } } }>(`/api/releases/${encodeURIComponent(id)}`),
  planRelease: (userRequest?: string) => postJSON<{ runId: string }>('/api/releases/plan', { userRequest }),
  listJira: () => getJSON<{ tickets: JiraTicket[] }>('/api/jira/issues'),
  listPRs: () => getJSON<{ pullRequests: PullRequest[] }>('/api/pull-requests'),
  listConflicts: () => getJSON<{ conflicts: ConflictRecord[] }>('/api/conflicts'),
  getConflict: (id: string) => getJSON<{ conflict: ConflictRecord }>(`/api/conflicts/${encodeURIComponent(id)}`),
  listDeployments: () => getJSON<{ deployments: Deployment[] }>('/api/deployments'),
  getDeployment: (id: string) => getJSON<{ deployment: Deployment }>(`/api/deployments/${encodeURIComponent(id)}`),
  listAudit: (limit = 100) => getJSON<{ logs: AuditLog[] }>(`/api/audit?limit=${limit}`),
};
