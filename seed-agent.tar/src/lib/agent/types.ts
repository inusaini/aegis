// Domain type definitions for the AI Seed Release Agent
// Adapted from spec sections 28, 14, 17, 21, 24, 52

// ---------- Workflow ----------

export type WorkflowStatus =
  | 'pending'
  | 'running'
  | 'completed'
  | 'failed'
  | 'blocked'
  | 'cancelled';

export type AgentMode = 'observe' | 'plan' | 'execute' | 'release' | 'recover';

export type WorkflowStep =
  | 'interpret_request'
  | 'jira_discovery'
  | 'pr_discovery'
  | 'jira_pr_correlation'
  | 'approval_evaluation'
  | 'clone_repository'
  | 'fetch_repository_state'
  | 'analyze_git_state'
  | 'build_release_plan'
  | 'create_release_workspace'
  | 'apply_changes'
  | 'conflict_resolution'
  | 'validate_release'
  | 'final_git_verification'
  | 'integrate_changes'
  | 'update_jira'
  | 'trigger_jenkins'
  | 'monitor_jenkins'
  | 'analyze_failure'
  | 'generate_report';

// ---------- LLM ----------

export interface LLMMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface LLMCompletionResult {
  content: string;
  usage?: { promptTokens?: number; completionTokens?: number };
}

// ---------- Jira ----------

export interface JiraTicketSummary {
  key: string;
  projectKey: string;
  summary: string;
  status: string;
  assignee?: string;
  reporter?: string;
  prUrl?: string;
  approvalField?: string;
}

export interface JiraCommentSummary {
  id: string;
  author: string;
  body: string;
  createdAt: string;
}

export interface JiraAttachmentSummary {
  id: string;
  filename: string;
  mimeType: string;
  size: number;
  isApproval: boolean;
}

// ---------- Pull Request ----------

export interface PullRequestSummary {
  id: string;
  prNumber: number;
  title: string;
  sourceBranch: string;
  targetBranch: string;
  state: string;
  author: string;
  reviewStatus: string;
  reviewers: number;
  requiredReviewers: number;
  approved: boolean;
  mergeable: boolean;
  jiraTicketKey?: string;
  commits: CommitInfo[];
  filesChanged: FileChangeInfo[];
}

export interface CommitInfo {
  sha: string;
  message: string;
  author: string;
}

export interface FileChangeInfo {
  path: string;
  additions: number;
  deletions: number;
}

// ---------- Approval ----------

export type ApprovalSource =
  | 'jira_status'
  | 'jira_comment'
  | 'jira_attachment'
  | 'bitbucket_reviewer'
  | 'bitbucket_pr_approval';

export interface ApprovalEvidence {
  source: ApprovalSource;
  evidence: string;
  confidence: number;
}

export interface ApprovalDecision {
  approved: boolean;
  confidence: number;
  evidence: ApprovalEvidence[];
  blockers: string[];
}

// ---------- Correlation ----------

export type CorrelationMatchType =
  | 'pr_url_field'
  | 'jira_comment'
  | 'jira_attachment'
  | 'pr_description'
  | 'pr_title'
  | 'branch_name'
  | 'commit_message'
  | 'metadata'
  | 'llm_assisted';

export interface CorrelationResult {
  matchType: CorrelationMatchType;
  confidence: number;
  evidence: string[];
}

// ---------- Release Planning ----------

export interface ReleaseItem {
  id: string;
  jiraTicketKey: string;
  prNumber: number;
  strategy: 'merge' | 'cherry_pick' | 'skip' | 'blocked';
  executionOrder: number;
  reason: string;
  status: 'pending' | 'applied' | 'conflict' | 'resolved' | 'validated' | 'skipped' | 'failed';
}

export interface ReleaseDependency {
  from: string; // PR number
  to: string; // PR number
  reason: string;
}

export interface ReleasePlan {
  releaseId: string;
  targetBranch: string;
  items: ReleaseItem[];
  dependencies: ReleaseDependency[];
  conflicts: string[];
  alreadyIntegrated: string[];
  skipped: string[];
  executionOrder: string[]; // PR identifiers in order
  justification?: string;
}

// ---------- Conflicts ----------

export type ConflictRisk = 'low' | 'medium' | 'high';
export type ConflictStrategy = 'semantic_merge' | 'ours' | 'theirs' | 'manual_block' | 'custom';

export interface ConflictRecord {
  conflictId: string;
  file: string;
  base: unknown;
  ours: unknown;
  theirs: unknown;
  riskLevel: ConflictRisk;
  status: 'detected' | 'analyzing' | 'resolved' | 'blocked' | 'failed';
}

export interface ConflictResolution {
  conflictId: string;
  strategy: ConflictStrategy;
  proposed: unknown;
  final: unknown;
  riskLevel: ConflictRisk;
  confidence: number;
  reasoning: string;
  evidence: string[];
  validationPassed: boolean;
}

// ---------- Validation ----------

export type ValidationStatus = 'pass' | 'fail' | 'warning';

export interface ValidationResult {
  validator: string; // e.g. "json_schema" | "duplicate_employee_id" | "referential_integrity"
  file?: string;
  status: ValidationStatus;
  message: string;
  details?: unknown;
}

export interface ReleaseValidationReport {
  filesChanged: number;
  recordsAdded: number;
  recordsUpdated: number;
  recordsDeleted: number;
  results: ValidationResult[];
  warnings: string[];
  errors: string[];
  riskLevel: ConflictRisk;
  passed: boolean;
}

// ---------- Deployment ----------

export interface DeploymentStatus {
  deploymentId: string;
  jenkinsJob: string;
  buildNumber?: number;
  status: 'pending' | 'queued' | 'building' | 'success' | 'failed' | 'aborted' | 'retrying';
  stage?: string;
  consoleLog?: string;
  failureAnalysis?: FailureAnalysis;
  retryCount: number;
  durationMs?: number;
}

export interface FailureAnalysis {
  status: 'failed' | 'unknown';
  likelyCause: string;
  evidence: string[];
  retryable: boolean;
  recommendedAction: 'retry_build' | 'block' | 'investigate' | 'fix_seed_data';
  confidence: number;
}

// ---------- Agent State (LangGraph equivalent) ----------

export interface SeedReleaseState {
  workflowId: string;
  runId: string;
  userRequest: string;
  mode: AgentMode;

  repository?: { id: string; name: string; targetBranch: string };

  jiraTickets: JiraTicketSummary[];
  pullRequests: PullRequestSummary[];
  correlations: Record<string, CorrelationResult>; // prNumber -> correlation
  approvalEvidence: Record<string, ApprovalDecision>; // ticketKey -> decision

  releasePlan?: ReleasePlan;

  workspacePath?: string;
  releaseBranch?: string;

  currentItem?: string;

  conflicts: ConflictRecord[];
  conflictResolutions: ConflictResolution[];

  validationReport?: ReleaseValidationReport;

  mergeResults: { prNumber: number; strategy: string; commitSha?: string; status: string }[];

  deployment?: DeploymentStatus;

  retryCount: number;
  currentStep: WorkflowStep;

  warnings: string[];
  errors: string[];
  status: WorkflowStatus;

  // event stream
  events: AgentEventPayload[];
}

export interface AgentEventPayload {
  event: string;
  workflowId: string;
  step?: WorkflowStep;
  timestamp: string;
  [key: string]: unknown;
}

// ---------- Audit ----------

export interface AuditEntry {
  workflowId?: string;
  actionId: string;
  actor: string;
  action: string;
  resource?: string;
  reason?: string;
  result: 'success' | 'failed' | 'blocked';
  metadata?: Record<string, unknown>;
}

// ---------- Policy ----------

export type ToolRisk = 'read' | 'write' | 'destructive';

export interface PolicyDecision {
  allowed: boolean;
  reason: string;
  risk: ToolRisk;
}
