// Agent orchestrator — a TypeScript state machine that mimics LangGraph
// semantics (per spec section 4, 27, 28, 37): named nodes, conditional edges,
// retries, resume from checkpoint (via DB), and a structured event stream.
//
// The orchestrator runs autonomously (spec sections 2, 6): NO human approval
// in the critical path. Deterministic policies (sections 19, 25, 31) gate
// every destructive operation. LLM reasoning is used only for understanding,
// correlation, conflict semantic resolution, and failure analysis.

import { db } from '@/lib/db';
import { v4 as uuid } from 'uuid';
import {
  buildMockRepo,
  GitWorkspaceManager,
  classifyRisk,
  type Workspace,
  type SeedFile,
  type PendingConflict,
} from '@/lib/mock/git-workspace';
import { getLLMProvider } from '@/lib/llm/provider';
import {
  buildSupervisorMessages,
  buildCorrelationMessages,
  buildApprovalMessages,
  buildPlannerMessages,
  buildConflictResolverMessages,
  buildJenkinsAnalyzerMessages,
} from '@/lib/llm/prompts';
import {
  DEFAULT_APPROVAL_POLICY,
  DEFAULT_CONFLICT_POLICY,
  DEFAULT_RETRY_POLICY,
  backoffDelay,
  evaluateActionPolicy,
  evaluateApproval,
  evaluateConflictAutonomy,
  isRetryable,
} from '@/lib/policies';
import { runValidation } from '@/lib/validators';
import type {
  AgentEventPayload,
  AgentMode,
  ConflictRecord,
  ConflictResolution,
  ConflictRisk,
  ReleasePlan,
  SeedReleaseState,
  WorkflowStep,
} from './types';

// ---------- In-memory registry of live runs (for SSE + resume) ----------

interface LiveRun {
  runId: string;          // human-friendly
  dbId: string;           // prisma AgentRun id
  state: SeedReleaseState;
  // event subscribers
  subscribers: Set<(ev: AgentEventPayload) => void>;
  // the mock repo + workspace manager (per run)
  repo: ReturnType<typeof buildMockRepo>;
  git: GitWorkspaceManager;
  workspace: Workspace | null;
  cancelRequested: boolean;
}

const liveRuns = new Map<string, LiveRun>();

export function getLiveRun(runId: string): LiveRun | undefined {
  return liveRuns.get(runId);
}

export function subscribe(runId: string, cb: (ev: AgentEventPayload) => void): () => void {
  const run = liveRuns.get(runId);
  if (!run) return () => {};
  run.subscribers.add(cb);
  return () => run.subscribers.delete(cb);
}

// ---------- Run lifecycle ----------

export async function startRun(userRequest: string, mode: AgentMode = 'execute'): Promise<string> {
  const runId = `RUN-${Date.now()}`;
  const dbRun = await db.agentRun.create({
    data: {
      runId,
      userRequest,
      mode,
      status: 'running',
      currentStep: 'interpret_request',
      startedAt: new Date(),
    },
  });

  const state: SeedReleaseState = {
    workflowId: runId,
    runId,
    userRequest,
    mode,
    jiraTickets: [],
    pullRequests: [],
    correlations: {},
    approvalEvidence: {},
    conflicts: [],
    conflictResolutions: [],
    mergeResults: [],
    retryCount: 0,
    currentStep: 'interpret_request',
    warnings: [],
    errors: [],
    status: 'running',
    events: [],
  };

  const repo = buildMockRepo();
  const git = new GitWorkspaceManager(repo);
  const live: LiveRun = {
    runId,
    dbId: dbRun.id,
    state,
    subscribers: new Set(),
    repo,
    git,
    workspace: null,
    cancelRequested: false,
  };
  liveRuns.set(runId, live);

  // Persist WorkflowState row for the first step
  await db.workflowState.create({
    data: { runId: dbRun.id, step: 'interpret_request', status: 'running', startedAt: new Date() },
  });

  // Kick off async execution — don't await so the caller gets runId immediately
  void executeWorkflow(live).catch((e) => {
    live.state.errors.push(`Fatal: ${e?.message ?? String(e)}`);
    live.state.status = 'failed';
    void persistFinalStatus(live);
  });

  return runId;
}

export async function resumeRun(runId: string): Promise<boolean> {
  const run = liveRuns.get(runId);
  if (!run) return false;
  if (run.state.status !== 'blocked' && run.state.status !== 'failed') return false;
  run.state.status = 'running';
  run.state.errors = [];
  run.cancelRequested = false;
  void executeWorkflow(run).catch((e) => {
    run.state.errors.push(`Fatal on resume: ${e?.message ?? String(e)}`);
    run.state.status = 'failed';
    void persistFinalStatus(run);
  });
  return true;
}

export async function cancelRun(runId: string): Promise<boolean> {
  const run = liveRuns.get(runId);
  if (!run) return false;
  run.cancelRequested = true;
  return true;
}

// ---------- Event helpers ----------

async function emit(run: LiveRun, payload: Omit<AgentEventPayload, 'workflowId' | 'timestamp'>) {
  const ev: AgentEventPayload = {
    ...payload,
    workflowId: run.runId,
    timestamp: new Date().toISOString(),
  };
  run.state.events.push(ev);
  // Broadcast to SSE subscribers
  for (const sub of run.subscribers) {
    try {
      sub(ev);
    } catch {
      // ignore
    }
  }
  // Persist event
  await db.agentEvent.create({
    data: { runId: run.dbId, event: ev.event, payload: ev as Record<string, unknown> },
  });
  // Persist workflow-state row for major step transitions
  if (ev.event === 'workflow.step.started') {
    await db.workflowState.create({
      data: {
        runId: run.dbId,
        step: (ev.step as string) || run.state.currentStep,
        status: 'running',
        startedAt: new Date(),
      },
    });
  } else if (ev.event === 'workflow.step.completed' || ev.event === 'workflow.step.failed') {
    // Update the most-recent row for this step
    const rows = await db.workflowState.findMany({ where: { runId: run.dbId, step: (ev.step as string) || run.state.currentStep }, orderBy: { createdAt: 'desc' }, take: 1 });
    if (rows[0]) {
      await db.workflowState.update({
        where: { id: rows[0].id },
        data: { status: ev.event === 'workflow.step.failed' ? 'failed' : 'completed', finishedAt: new Date() },
      });
    }
  }
}

async function audit(run: LiveRun, action: string, resource: string | undefined, reason: string, result: 'success' | 'failed' | 'blocked' = 'success') {
  await db.auditLog.create({
    data: {
      runId: run.dbId,
      actor: 'ai-seed-agent',
      action,
      resource,
      reason,
      result,
      metadata: { step: run.state.currentStep },
    },
  });
}

async function agentAction(run: LiveRun, agent: string, tool: string, args: Record<string, unknown>, result: unknown, risk: 'read' | 'write' | 'destructive', reason: string, status: 'success' | 'failed' | 'blocked' = 'success') {
  await db.agentAction.create({
    data: { runId: run.dbId, agent, tool, args, result: result as Record<string, unknown>, risk, status, reason },
  });
}

async function persistStateUpdate(run: LiveRun) {
  await db.agentRun.update({
    where: { id: run.dbId },
    data: {
      status: run.state.status,
      currentStep: run.state.currentStep,
      warnings: run.state.warnings,
      errors: run.state.errors,
      retryCount: run.state.retryCount,
      summary: buildRunSummary(run),
      finishedAt: run.state.status !== 'running' ? new Date() : null,
    },
  });
}

async function persistFinalStatus(run: LiveRun) {
  await persistStateUpdate(run);
}

function buildRunSummary(run: LiveRun): string {
  const s = run.state;
  const nApproved = Object.values(s.approvalEvidence).filter((a) => a.approved).length;
  const parts: string[] = [];
  parts.push(`mode=${s.mode}`);
  parts.push(`status=${s.status}`);
  parts.push(`step=${s.currentStep}`);
  if (s.jiraTickets.length) parts.push(`tickets=${s.jiraTickets.length}`);
  if (s.pullRequests.length) parts.push(`prs=${s.pullRequests.length}`);
  if (nApproved) parts.push(`approved=${nApproved}`);
  if (s.conflicts.length) parts.push(`conflicts=${s.conflicts.length}`);
  if (s.conflictResolutions.length) parts.push(`resolved=${s.conflictResolutions.length}`);
  if (s.mergeResults.length) parts.push(`applied=${s.mergeResults.length}`);
  if (s.deployment) parts.push(`deploy=${s.deployment.status}`);
  return parts.join(' · ');
}

// ---------- Workflow execution (LangGraph equivalent) ----------

async function executeWorkflow(run: LiveRun) {
  const s = run.state;
  try {
    // 1. Interpret request
    await setStep(run, 'interpret_request');
    await emit(run, { event: 'workflow.step.started', step: 'interpret_request' });
    await interpretRequest(run);
    await emit(run, { event: 'workflow.step.completed', step: 'interpret_request' });

    if (run.cancelRequested) return await finalizeCancelled(run);

    // 2. Jira discovery
    await setStep(run, 'jira_discovery');
    await emit(run, { event: 'workflow.step.started', step: 'jira_discovery' });
    await discoverJira(run);
    await emit(run, { event: 'workflow.step.completed', step: 'jira_discovery', payload: { tickets: s.jiraTickets.length } });

    // 3. PR discovery
    await setStep(run, 'pr_discovery');
    await emit(run, { event: 'workflow.step.started', step: 'pr_discovery' });
    await discoverPRs(run);
    await emit(run, { event: 'workflow.step.completed', step: 'pr_discovery', payload: { prs: s.pullRequests.length } });

    // 4. Correlate Jira <-> PR
    await setStep(run, 'jira_pr_correlation');
    await emit(run, { event: 'workflow.step.started', step: 'jira_pr_correlation' });
    await correlateJiraPR(run);
    await emit(run, { event: 'workflow.step.completed', step: 'jira_pr_correlation' });

    // 5. Approval evaluation
    await setStep(run, 'approval_evaluation');
    await emit(run, { event: 'workflow.step.started', step: 'approval_evaluation' });
    await evaluateApprovals(run);
    await emit(run, { event: 'workflow.step.completed', step: 'approval_evaluation' });

    // Observe / plan modes stop here
    if (s.mode === 'observe' || s.mode === 'plan') {
      await setStep(run, 'build_release_plan');
      await emit(run, { event: 'workflow.step.started', step: 'build_release_plan' });
      await buildReleasePlan(run);
      await emit(run, { event: 'workflow.step.completed', step: 'build_release_plan' });
      s.status = 'completed';
      await persistFinalStatus(run);
      await emit(run, { event: 'workflow.completed', payload: { reason: `${s.mode} mode complete` } });
      return;
    }

    // 6. Clone repository
    await setStep(run, 'clone_repository');
    await emit(run, { event: 'workflow.step.started', step: 'clone_repository' });
    await cloneRepository(run);
    await emit(run, { event: 'workflow.step.completed', step: 'clone_repository' });

    // 7. Fetch repo state
    await setStep(run, 'fetch_repository_state');
    await emit(run, { event: 'workflow.step.started', step: 'fetch_repository_state' });
    await fetchRepositoryState(run);
    await emit(run, { event: 'workflow.step.completed', step: 'fetch_repository_state' });

    // 8. Build release plan
    await setStep(run, 'build_release_plan');
    await emit(run, { event: 'workflow.step.started', step: 'build_release_plan' });
    await buildReleasePlan(run);
    await emit(run, { event: 'workflow.step.completed', step: 'build_release_plan' });

    // 9. Create release workspace
    await setStep(run, 'create_release_workspace');
    await emit(run, { event: 'workflow.step.started', step: 'create_release_workspace' });
    await createReleaseWorkspace(run);
    await emit(run, { event: 'workflow.step.completed', step: 'create_release_workspace' });

    // 10. Apply changes (with conflict loop)
    await setStep(run, 'apply_changes');
    await emit(run, { event: 'workflow.step.started', step: 'apply_changes' });
    await applyChanges(run);
    await emit(run, { event: 'workflow.step.completed', step: 'apply_changes', payload: { applied: s.mergeResults.length, conflicts: s.conflicts.length } });

    if (run.cancelRequested) return await finalizeCancelled(run);

    // 11. Validate release
    await setStep(run, 'validate_release');
    await emit(run, { event: 'workflow.step.started', step: 'validate_release' });
    await validateRelease(run);
    await emit(run, { event: 'workflow.step.completed', step: 'validate_release' });

    if (!s.validationReport?.passed) {
      s.status = 'blocked';
      s.errors.push('Release validation failed — autonomous policy blocks deployment');
      await persistFinalStatus(run);
      await emit(run, { event: 'workflow.blocked', payload: { reason: 'validation_failed' } });
      await audit(run, 'block_release', undefined, 'Validation failed; release blocked');
      return;
    }

    // 12. Final git verification (race detection)
    await setStep(run, 'final_git_verification');
    await emit(run, { event: 'workflow.step.started', step: 'final_git_verification' });
    await finalGitVerification(run);
    await emit(run, { event: 'workflow.step.completed', step: 'final_git_verification' });

    // 13. Integrate changes (push / merge)
    await setStep(run, 'integrate_changes');
    await emit(run, { event: 'workflow.step.started', step: 'integrate_changes' });
    await integrateChanges(run);
    await emit(run, { event: 'workflow.step.completed', step: 'integrate_changes' });

    // 14. Update Jira
    await setStep(run, 'update_jira');
    await emit(run, { event: 'workflow.step.started', step: 'update_jira' });
    await updateJira(run);
    await emit(run, { event: 'workflow.step.completed', step: 'update_jira' });

    // 15. Trigger Jenkins (only in release mode)
    if (s.mode === 'release' || s.mode === 'execute') {
      await setStep(run, 'trigger_jenkins');
      await emit(run, { event: 'workflow.step.started', step: 'trigger_jenkins' });
      await triggerJenkins(run);
      await emit(run, { event: 'workflow.step.completed', step: 'trigger_jenkins' });

      // 16. Monitor Jenkins
      await setStep(run, 'monitor_jenkins');
      await emit(run, { event: 'workflow.step.started', step: 'monitor_jenkins' });
      await monitorJenkins(run);
      await emit(run, { event: 'workflow.step.completed', step: 'monitor_jenkins' });
    }

    // 17. Generate report
    await setStep(run, 'generate_report');
    await emit(run, { event: 'workflow.step.started', step: 'generate_report' });
    await generateReport(run);
    await emit(run, { event: 'workflow.step.completed', step: 'generate_report' });

    s.status = 'completed';
    await persistFinalStatus(run);
    await emit(run, { event: 'workflow.completed', payload: { reason: 'all steps completed' } });
  } catch (e) {
    s.status = 'failed';
    s.errors.push(`Unhandled: ${(e as Error).message}`);
    await persistFinalStatus(run);
    await emit(run, { event: 'workflow.failed', payload: { error: (e as Error).message } });
    await audit(run, 'workflow_failed', undefined, (e as Error).message, 'failed');
  }
}

async function setStep(run: LiveRun, step: WorkflowStep) {
  run.state.currentStep = step;
  await db.agentRun.update({ where: { id: run.dbId }, data: { currentStep: step } });
  await persistStateUpdate(run);
}

async function finalizeCancelled(run: LiveRun) {
  run.state.status = 'cancelled';
  await persistFinalStatus(run);
  await emit(run, { event: 'workflow.cancelled', payload: {} });
}

// ---------- Node implementations ----------

async function interpretRequest(run: LiveRun) {
  const s = run.state;
  // Use LLM only for understanding intent. The mode is ultimately governed
  // by the caller (deterministic) — the LLM cannot escalate beyond it.
  try {
    const llm = getLLMProvider();
    const { data } = await llm.completeJson<{
      intent?: string;
      mode?: string;
      scope?: string;
      confidence?: number;
      evidence?: string[];
    }>(buildSupervisorMessages(s.userRequest));
    if (data && data.intent) {
      await db.agentRun.update({
        where: { id: run.dbId },
        data: { requestIntent: data.intent },
      });
      await agentAction(run, 'supervisor', 'interpret_request', { request: s.userRequest }, data, 'read', 'Interpret user release request');
      await emit(run, { event: 'supervisor.interpreted', payload: { intent: data.intent, confidence: data.confidence, evidence: data.evidence } });
    }
  } catch (e) {
    s.warnings.push(`Supervisor LLM unavailable: ${(e as Error).message}`);
    await emit(run, { event: 'supervisor.fallback', payload: { reason: (e as Error).message } });
  }
}

async function discoverJira(run: LiveRun) {
  const s = run.state;
  const tickets = await db.jiraTicket.findMany({
    include: { comments: true, attachments: true, approvals: true, pullRequest: true },
  });
  for (const t of tickets) {
    s.jiraTickets.push({
      key: t.key,
      projectKey: t.projectKey,
      summary: t.summary,
      status: t.status,
      assignee: t.assignee || undefined,
      reporter: t.reporter || undefined,
      prUrl: t.prUrl || undefined,
      approvalField: t.approvalField || undefined,
    });
  }
  await agentAction(run, 'jira', 'search_issues', {}, { count: s.jiraTickets.length }, 'read', 'Discover all Jira tickets');
  await emit(run, { event: 'jira.tickets_discovered', payload: { count: s.jiraTickets.length } });
}

async function discoverPRs(run: LiveRun) {
  const s = run.state;
  const prs = await db.pullRequest.findMany({ include: { jiraTicket: true } });
  for (const pr of prs) {
    s.pullRequests.push({
      id: pr.id,
      prNumber: pr.prNumber,
      title: pr.title,
      sourceBranch: pr.sourceBranch,
      targetBranch: pr.targetBranch,
      state: pr.state,
      author: pr.author,
      reviewStatus: pr.reviewStatus,
      reviewers: pr.reviewers,
      requiredReviewers: pr.requiredReviewers,
      approved: pr.approved,
      mergeable: pr.mergeable,
      jiraTicketKey: pr.jiraTicket?.key,
      commits: pr.commits as { sha: string; message: string; author: string }[],
      filesChanged: pr.filesChanged as { path: string; additions: number; deletions: number }[],
    });
  }
  await agentAction(run, 'bitbucket', 'list_pull_requests', {}, { count: s.pullRequests.length }, 'read', 'Discover all PRs');
  await emit(run, { event: 'pr.discovered', payload: { count: s.pullRequests.length } });
}

async function correlateJiraPR(run: LiveRun) {
  const s = run.state;
  // Deterministic-first: JiraTicket has jiraTicketId on PR → direct correlation.
  for (const pr of s.pullRequests) {
    if (pr.jiraTicketKey) {
      s.correlations[String(pr.prNumber)] = {
        matchType: 'metadata',
        confidence: 1.0,
        evidence: ['PR.jiraTicketId matches Jira ticket (db-level metadata)'],
      };
      continue;
    }
    // Else fallback to deterministic heuristics on PR title / branch name
    for (const t of s.jiraTickets) {
      const key = t.key;
      if (pr.title.includes(key)) {
        s.correlations[String(pr.prNumber)] = {
          matchType: 'pr_title',
          confidence: 0.95,
          evidence: [`PR title contains ${key}`],
        };
        break;
      }
      if (pr.sourceBranch.includes(key)) {
        s.correlations[String(pr.prNumber)] = {
          matchType: 'branch_name',
          confidence: 0.92,
          evidence: [`Branch name contains ${key}`],
        };
        break;
      }
    }
    // LLM-assisted last resort (only if no deterministic match)
    if (!s.correlations[String(pr.prNumber)]) {
      try {
        const ticket = s.jiraTickets.find((t) => t.summary.toLowerCase().includes(pr.title.toLowerCase().split(':')[0] || '___'));
        if (ticket) {
          const llm = getLLMProvider();
          const { data } = await llm.completeJson<{ matchType?: string; confidence?: number; evidence?: string[] }>(
            buildCorrelationMessages(
              { key: ticket.key, summary: ticket.summary, description: '', prUrl: ticket.prUrl, comments: [] },
              { prNumber: pr.prNumber, title: pr.title, sourceBranch: pr.sourceBranch, description: '', commits: pr.commits },
            ),
          );
          if (data && typeof data.confidence === 'number' && data.confidence >= 0.6) {
            s.correlations[String(pr.prNumber)] = {
              matchType: (data.matchType as 'llm_assisted') || 'llm_assisted',
              confidence: data.confidence,
              evidence: data.evidence || ['LLM-assisted correlation'],
            };
          }
        }
      } catch {
        // ignore
      }
    }
  }
  await agentAction(run, 'jira', 'correlate', {}, { correlations: Object.keys(s.correlations).length }, 'read', 'Correlate Jira tickets to PRs (deterministic + LLM)');
  await emit(run, { event: 'jira_pr.correlated', payload: { count: Object.keys(s.correlations).length } });
}

async function evaluateApprovals(run: LiveRun) {
  const s = run.state;
  for (const pr of s.pullRequests) {
    if (!pr.jiraTicketKey) {
      s.approvalEvidence[pr.jiraTicketKey || `PR-${pr.prNumber}`] = {
        approved: false,
        confidence: 0,
        evidence: [],
        blockers: ['No correlated Jira ticket — cannot evaluate approval'],
      };
      continue;
    }
    // Load full ticket with comments + attachments from DB
    const t = await db.jiraTicket.findUnique({
      where: { key: pr.jiraTicketKey },
      include: { comments: true, attachments: true, approvals: true },
    });
    if (!t) continue;

    // Deterministic policy first (spec section 10)
    const isDestructive = pr.filesChanged.some((f) => f.deletions > 2);
    const decision = evaluateApproval({
      jiraStatus: t.status,
      hasApprovalAttachment: t.attachments.some((a) => a.isApproval),
      reviewers: pr.reviewers,
      requiredReviewers: pr.requiredReviewers,
      prApproved: pr.approved,
      prMergeable: pr.mergeable,
      isDestructive,
      policy: DEFAULT_APPROVAL_POLICY,
    });

    // LLM extracts additional evidence (spec section 11) but cannot override
    // the deterministic decision.
    try {
      const llm = getLLMProvider();
      const { data } = await llm.completeJson<{
        evidence?: { source: string; evidence: string; confidence: number }[];
        blockers?: string[];
      }>(
        buildApprovalMessages(
          {
            key: t.key,
            summary: t.summary,
            status: t.status,
            approvalField: t.approvalField || undefined,
            comments: t.comments.map((c) => ({ author: c.author, body: c.body })),
            attachments: t.attachments.map((a) => ({ filename: a.filename, isApproval: a.isApproval, content: a.content })),
          },
          { prNumber: pr.prNumber, reviewStatus: pr.reviewStatus, reviewers: pr.reviewers, requiredReviewers: pr.requiredReviewers, approved: pr.approved },
        ),
      );
      if (data?.evidence) {
        for (const e of data.evidence) {
          decision.evidence.push({ source: e.source as 'jira_status' | 'jira_comment' | 'jira_attachment' | 'bitbucket_reviewer' | 'bitbucket_pr_approval', evidence: e.evidence, confidence: e.confidence });
        }
      }
      if (data?.blockers) {
        for (const b of data.blockers) {
          if (!decision.blockers.includes(b)) decision.blockers.push(b);
        }
      }
    } catch (e) {
      s.warnings.push(`Approval LLM unavailable for ${pr.jiraTicketKey}: ${(e as Error).message}`);
    }

    s.approvalEvidence[pr.jiraTicketKey] = decision;
    // Persist approval evidence rows
    for (const ev of decision.evidence) {
      const exists = await db.approvalEvidence.findFirst({ where: { ticketId: t.id, source: ev.source, evidence: ev.evidence } });
      if (!exists) await db.approvalEvidence.create({ data: { ticketId: t.id, source: ev.source, evidence: ev.evidence, confidence: ev.confidence } });
    }
    await emit(run, {
      event: decision.approved ? 'approval.verified' : 'approval.blocked',
      payload: { pr: pr.prNumber, ticket: pr.jiraTicketKey, confidence: decision.confidence, blockers: decision.blockers },
    });
  }
  await agentAction(run, 'jira', 'evaluate_approvals', {}, { approved: Object.values(s.approvalEvidence).filter((a) => a.approved).length }, 'read', 'Evaluate approval evidence per policy');
}

async function cloneRepository(run: LiveRun) {
  const s = run.state;
  const repo = await db.repository.findFirst({ where: { name: 'seed-data' } });
  if (!repo) throw new Error('No seed-data repository configured');
  s.repository = { id: repo.id, name: repo.name, targetBranch: repo.targetBranch };
  await db.gitWorkspace.create({
    data: {
      workspaceId: `run-${run.runId}`,
      repositoryId: repo.id,
      path: `/tmp/seed-agent-workspaces/run-${run.runId}/repository`,
      releaseBranch: `release/run-${run.runId}`,
      baseCommit: run.repo.branches[repo.targetBranch].head,
      headCommit: run.repo.branches[repo.targetBranch].head,
      status: 'created',
    },
  });
  await agentAction(run, 'git', 'git_clone', { repo: repo.name, branch: repo.targetBranch }, { ok: true }, 'write', 'Clone repository into isolated workspace');
  await emit(run, { event: 'git.cloned', payload: { branch: repo.targetBranch } });
}

async function fetchRepositoryState(run: LiveRun) {
  await agentAction(run, 'git', 'git_fetch', { remote: 'origin' }, { ok: true }, 'write', 'Fetch remote refs');
  await emit(run, { event: 'git.fetched', payload: {} });
}

async function buildReleasePlan(run: LiveRun) {
  const s = run.state;
  const approvedTickets: { key: string; summary: string }[] = [];
  const approvedPRs: {
    prNumber: number;
    title: string;
    sourceBranch: string;
    filesChanged: { path: string }[];
    commits: { sha: string; message: string }[];
  }[] = [];
  for (const pr of s.pullRequests) {
    if (!pr.jiraTicketKey) continue;
    const decision = s.approvalEvidence[pr.jiraTicketKey];
    if (!decision?.approved) continue;
    const ticket = s.jiraTickets.find((t) => t.key === pr.jiraTicketKey);
    if (!ticket) continue;
    approvedTickets.push({ key: ticket.key, summary: ticket.summary });
    approvedPRs.push({
      prNumber: pr.prNumber,
      title: pr.title,
      sourceBranch: pr.sourceBranch,
      filesChanged: pr.filesChanged,
      commits: pr.commits,
    });
  }

  // LLM suggests order/strategy; deterministic code finalizes.
  let plan: ReleasePlan;
  try {
    const llm = getLLMProvider();
    const { data } = await llm.completeJson<{
      items?: { jiraTicketKey: string; prNumber: number; strategy: 'merge' | 'cherry_pick' | 'skip' | 'blocked'; reason: string }[];
      dependencies?: { from: number; to: number; reason: string }[];
      executionOrder?: number[];
      alreadyIntegrated?: number[];
      skipped?: number[];
      expectedConflicts?: string[];
      justification?: string;
    }>(buildPlannerMessages(approvedTickets, approvedPRs, { name: s.repository?.name || 'seed-data', targetBranch: s.repository?.targetBranch || 'master' }));

    // Determine "already integrated" deterministically: PR-106 (SEED-1006) is in "merged" state in DB.
    const mergedPRs = s.pullRequests.filter((p) => p.state === 'merged').map((p) => p.prNumber);
    const alreadyIntegrated = Array.from(new Set([...(data.alreadyIntegrated || []), ...mergedPRs]));

    // Final strategy: cherry_pick for commit-level selection (per spec example); merge if PR is open & mergeable.
    const items = (data.items || []).map((it) => {
      let strategy = it.strategy;
      if (alreadyIntegrated.includes(it.prNumber)) strategy = 'skip';
      else if (strategy === 'blocked') strategy = 'blocked';
      else strategy = 'cherry_pick'; // deterministic default for commit-level integration
      return {
        id: uuid(),
        jiraTicketKey: it.jiraTicketKey,
        prNumber: it.prNumber,
        strategy,
        reason: it.reason || 'Approved PR',
        executionOrder: 0,
        status: 'pending' as const,
      };
    });

    // Execution order from LLM, but filter integrated/skipped
    const order = (data.executionOrder || items.map((i) => i.prNumber)).filter((n) => !alreadyIntegrated.includes(n));
    items.forEach((it, i) => {
      it.executionOrder = order.indexOf(it.prNumber) >= 0 ? order.indexOf(it.prNumber) : i;
      if (alreadyIntegrated.includes(it.prNumber)) {
        it.strategy = 'skip';
        it.status = 'skipped';
      }
    });
    items.sort((a, b) => a.executionOrder - b.executionOrder);

    plan = {
      releaseId: `REL-${new Date().toISOString().slice(0, 10)}-${run.runId.slice(-6)}`,
      targetBranch: s.repository?.targetBranch || 'master',
      items,
      dependencies: (data.dependencies || []).map((d) => ({ from: String(d.from), to: String(d.to), reason: d.reason })),
      conflicts: data.expectedConflicts || [],
      alreadyIntegrated: alreadyIntegrated.map(String),
      skipped: Array.from(new Set([...(data.skipped || []).map(String), ...alreadyIntegrated.map(String)])),
      executionOrder: order.map(String),
      justification: data.justification,
    };
  } catch (e) {
    // Deterministic fallback: simple approve-all in PR-number order
    s.warnings.push(`Planner LLM unavailable: ${(e as Error).message}`);
    const mergedPRs = s.pullRequests.filter((p) => p.state === 'merged').map((p) => p.prNumber);
    const items = approvedPRs.map((pr) => ({
      id: uuid(),
      jiraTicketKey: approvedTickets.find((t) => pr.title.includes(t.key))?.key || '',
      prNumber: pr.prNumber,
      strategy: mergedPRs.includes(pr.prNumber) ? 'skip' as const : 'cherry_pick' as const,
      reason: 'Approved PR (deterministic fallback)',
      executionOrder: 0,
      status: (mergedPRs.includes(pr.prNumber) ? 'skipped' : 'pending') as 'pending' | 'skipped',
    }));
    items.forEach((it, i) => (it.executionOrder = i));
    plan = {
      releaseId: `REL-${new Date().toISOString().slice(0, 10)}-${run.runId.slice(-6)}`,
      targetBranch: s.repository?.targetBranch || 'master',
      items,
      dependencies: [],
      conflicts: [],
      alreadyIntegrated: mergedPRs.map(String),
      skipped: mergedPRs.map(String),
      executionOrder: items.map((i) => String(i.prNumber)),
      justification: 'Deterministic fallback (planner LLM unavailable)',
    };
  }
  s.releasePlan = plan;
  await agentAction(run, 'release_planner', 'build_release_plan', { approved: approvedPRs.length }, plan, 'read', 'Build release plan with execution order');
  await emit(run, { event: 'release.plan_built', payload: { releaseId: plan.releaseId, items: plan.items.length } });
}

async function createReleaseWorkspace(run: LiveRun) {
  const s = run.state;
  const ws = run.git.createWorkspace(`run-${run.runId}`, s.repository?.targetBranch || 'master', `release/run-${run.runId}`);
  run.workspace = ws;
  // Persist
  const wsRow = await db.gitWorkspace.findUnique({ where: { workspaceId: `run-${run.runId}` } });
  if (wsRow) {
    await db.gitWorkspace.update({
      where: { id: wsRow.id },
      data: { status: 'active', headCommit: ws.head, releaseBranch: ws.releaseBranch },
    });
  }
  await db.gitOperation.create({
    data: {
      workspaceId: wsRow?.id || 'unknown',
      operation: 'create_branch',
      args: { branch: ws.releaseBranch, base: ws.baseBranch },
      result: 'success',
      output: `Created release branch ${ws.releaseBranch} from ${ws.baseBranch} at ${ws.baseCommit}`,
    },
  });
  await agentAction(run, 'git', 'git_create_branch', { branch: ws.releaseBranch, base: ws.baseBranch }, { ok: true, head: ws.head }, 'write', 'Create isolated release branch');
  await emit(run, { event: 'git.workspace_created', payload: { branch: ws.releaseBranch, head: ws.head } });
}

async function applyChanges(run: LiveRun) {
  const s = run.state;
  if (!run.workspace || !s.releasePlan) throw new Error('Workspace or plan missing');
  // Persist the release row
  const repo = await db.repository.findFirst({ where: { name: s.repository?.name || 'seed-data' } });
  if (repo) {
    const release = await db.release.create({
      data: {
        releaseId: s.releasePlan.releaseId,
        runId: run.dbId,
        repositoryId: repo.id,
        targetBranch: s.releasePlan.targetBranch,
        releaseBranch: run.workspace.releaseBranch,
        status: 'in_progress',
        totalTickets: s.jiraTickets.length,
        approvedTickets: Object.values(s.approvalEvidence).filter((a) => a.approved).length,
        alreadyMerged: s.releasePlan.alreadyIntegrated.length,
        toIntegrate: s.releasePlan.items.filter((i) => i.strategy !== 'skip').length,
        conflictsCount: 0,
        planJson: s.releasePlan as Record<string, unknown>,
        riskLevel: 'low',
      },
    });
    s.repository = { ...s.repository!, id: repo.id };

    // Apply items in order
    for (const item of s.releasePlan.items) {
      if (item.strategy === 'skip') {
        item.status = 'skipped';
        await emit(run, { event: 'release.item.skipped', payload: { pr: item.prNumber, ticket: item.jiraTicketKey } });
        continue;
      }
      if (item.strategy === 'blocked') {
        item.status = 'failed';
        s.errors.push(`Item ${item.prNumber} blocked: ${item.reason}`);
        await emit(run, { event: 'release.item.blocked', payload: { pr: item.prNumber, reason: item.reason } });
        continue;
      }
      const pr = s.pullRequests.find((p) => p.prNumber === item.prNumber);
      if (!pr) continue;
      const mode = item.strategy === 'merge' ? 'merge' : 'cherry_pick';
      // Apply through the workspace manager
      const res = run.git.applyBranch(run.workspace, pr.sourceBranch, mode, pr.prNumber);
      if (res.ok) {
        item.status = 'applied';
        s.mergeResults.push({ prNumber: pr.prNumber, strategy: mode, commitSha: res.commitSha, status: 'success' });
        await db.gitOperation.create({
          data: {
            workspaceId: (await db.gitWorkspace.findUnique({ where: { workspaceId: run.workspace.workspaceId } }))?.id || 'unknown',
            operation: mode,
            args: { sourceBranch: pr.sourceBranch, prNumber: pr.prNumber },
            result: 'success',
            output: res.message,
          },
        });
        // Persist ReleaseItem + MergeResult
        const dbPr = await db.pullRequest.findFirst({ where: { prNumber: pr.prNumber } });
        const dbTicket = await db.jiraTicket.findFirst({ where: { key: pr.jiraTicketKey } });
        if (dbPr && dbTicket) {
          await db.releaseItem.create({
            data: {
              releaseId: release.id,
              jiraTicketId: dbTicket.id,
              pullRequestId: dbPr.id,
              strategy: mode,
              executionOrder: item.executionOrder,
              status: 'applied',
              reason: item.reason,
            },
          });
          await db.mergeResult.create({
            data: {
              pullRequestId: dbPr.id,
              strategy: mode,
              commitSha: res.commitSha || null,
              status: 'success',
              filesChanged: res.filesChanged || [],
              output: res.message,
            },
          });
        }
        await audit(run, mode, `PR-${pr.prNumber}`, `Approved PR included in release plan (commit ${res.commitSha})`);
        await agentAction(run, 'git', mode, { pr: pr.prNumber, branch: pr.sourceBranch }, { ok: true, commit: res.commitSha }, 'write', `Apply ${mode} for PR ${pr.prNumber}`);
        await emit(run, { event: mode === 'merge' ? 'git.merge.success' : 'git.cherry_pick.success', payload: { pr: pr.prNumber, commit: res.commitSha, files: res.filesChanged } });
      } else if (res.conflict) {
        item.status = 'conflict';
        await emit(run, { event: 'git.conflict.detected', payload: { pr: pr.prNumber, file: res.conflict.file, branch: pr.sourceBranch } });
        await resolveConflict(run, pr, res.conflict);
        if (run.workspace.pendingConflict) {
          // unresolved — block
          item.status = 'failed';
          s.status = 'blocked';
          s.errors.push(`Unresolved conflict on PR ${pr.prNumber} file ${res.conflict.file}`);
          await persistFinalStatus(run);
          await emit(run, { event: 'workflow.blocked', payload: { reason: 'unresolved_conflict', pr: pr.prNumber, file: res.conflict.file } });
          await audit(run, 'block_release', `PR-${pr.prNumber}`, `Unresolved conflict on ${res.conflict.file}`, 'blocked');
          return;
        }
        // conflict resolved → mark item as resolved & validate
        item.status = 'resolved';
        s.mergeResults.push({ prNumber: pr.prNumber, strategy: mode, status: 'conflict_resolved' });
        const dbPr = await db.pullRequest.findFirst({ where: { prNumber: pr.prNumber } });
        const dbTicket = await db.jiraTicket.findFirst({ where: { key: pr.jiraTicketKey } });
        if (dbPr && dbTicket) {
          await db.releaseItem.create({
            data: {
              releaseId: release.id,
              jiraTicketId: dbTicket.id,
              pullRequestId: dbPr.id,
              strategy: mode,
              executionOrder: item.executionOrder,
              status: 'resolved',
              reason: `Conflict on ${res.conflict!.file} resolved`,
            },
          });
          await db.mergeResult.create({
            data: {
              pullRequestId: dbPr.id,
              strategy: mode,
              status: 'conflict',
              filesChanged: [res.conflict!.file],
              output: res.message,
            },
          });
        }
      } else {
        item.status = 'failed';
        s.errors.push(`Apply failed for PR ${pr.prNumber}: ${res.message}`);
        await emit(run, { event: 'release.item.failed', payload: { pr: pr.prNumber, reason: res.message } });
      }
    }

    // Update release counters
    await db.release.update({
      where: { id: release.id },
      data: {
        conflictsCount: s.conflicts.length,
        riskLevel: s.conflicts.some((c) => c.riskLevel === 'high') ? 'high' : s.conflicts.some((c) => c.riskLevel === 'medium') ? 'medium' : 'low',
      },
    });
  }
}

async function resolveConflict(run: LiveRun, pr: { prNumber: number; title: string; description?: string; jiraTicketKey?: string; commits: { sha: string; message: string }[] }, conflict: PendingConflict) {
  const s = run.state;
  const baseRisk: ConflictRisk = classifyRisk(conflict.file, conflict.base, conflict.ours, conflict.theirs);

  // Record the conflict
  const conflictId = `C-${1000 + s.conflicts.length}`;
  const record: ConflictRecord = {
    conflictId,
    file: conflict.file,
    base: conflict.base,
    ours: conflict.ours,
    theirs: conflict.theirs,
    riskLevel: baseRisk,
    status: 'analyzing',
  };
  s.conflicts.push(record);

  const dbPr = await db.pullRequest.findFirst({ where: { prNumber: pr.prNumber } });
  if (dbPr) {
    await db.conflict.create({
      data: {
        conflictId,
        runId: run.dbId,
        pullRequestId: dbPr.id,
        file: conflict.file,
        base: conflict.base as Record<string, unknown>,
        ours: conflict.ours as Record<string, unknown>,
        theirs: conflict.theirs as Record<string, unknown>,
        riskLevel: baseRisk,
        status: 'analyzing',
      },
    });
  }
  await emit(run, { event: 'conflict.analyzing', payload: { conflictId, file: conflict.file, risk: baseRisk, pr: pr.prNumber } });

  // Use LLM to propose semantic resolution (spec section 18)
  let resolution: ConflictResolution;
  try {
    const ticket = pr.jiraTicketKey ? s.jiraTickets.find((t) => t.key === pr.jiraTicketKey) : undefined;
    const llm = getLLMProvider();
    const { data } = await llm.completeJson<{
      strategy?: 'semantic_merge' | 'ours' | 'theirs' | 'manual_block' | 'custom';
      proposed?: unknown;
      riskLevel?: ConflictRisk;
      confidence?: number;
      reasoning?: string;
      evidence?: string[];
    }>(buildConflictResolverMessages({
      file: conflict.file,
      base: conflict.base,
      ours: conflict.ours,
      theirs: conflict.theirs,
      ticket: ticket ? { key: ticket.key, summary: ticket.summary } : undefined,
      pr: { prNumber: pr.prNumber, title: pr.title, description: pr.description },
      commits: pr.commits,
    }));
    resolution = {
      conflictId,
      strategy: data.strategy || 'manual_block',
      proposed: data.proposed ?? null,
      final: data.proposed ?? null,
      riskLevel: (data.riskLevel as ConflictRisk) || baseRisk,
      confidence: typeof data.confidence === 'number' ? data.confidence : 0.5,
      reasoning: data.reasoning || 'LLM did not provide reasoning',
      evidence: data.evidence || [],
      validationPassed: false,
    };
  } catch (e) {
    s.warnings.push(`Conflict LLM unavailable for ${conflictId}: ${(e as Error).message}`);
    resolution = {
      conflictId,
      strategy: 'manual_block',
      proposed: null,
      final: null,
      riskLevel: baseRisk,
      confidence: 0,
      reasoning: `Conflict LLM unavailable: ${(e as Error).message}`,
      evidence: [],
      validationPassed: false,
    };
  }

  // Policy gate: can we autonomously apply this resolution?
  const autonomy = evaluateConflictAutonomy(resolution.riskLevel, resolution.strategy, resolution.confidence, DEFAULT_CONFLICT_POLICY);
  if (!autonomy.allowed) {
    record.status = 'blocked';
    resolution.strategy = 'manual_block';
    await db.conflict.updateMany({ where: { conflictId }, data: { status: 'blocked' } });
    if (dbPr) {
      await db.conflictResolution.create({
        data: {
          conflictId: (await db.conflict.findUnique({ where: { conflictId } }))!.id,
          strategy: 'manual_block',
          proposed: resolution.proposed as Record<string, unknown>,
          final: resolution.proposed as Record<string, unknown>,
          riskLevel: resolution.riskLevel,
          confidence: resolution.confidence,
          reasoning: `${resolution.reasoning} [BLOCKED: ${autonomy.reason}]`,
          evidence: resolution.evidence,
          validationPassed: false,
        },
      });
    }
    s.conflictResolutions.push(resolution);
    run.workspace.pendingConflict = conflict; // keep blocked
    await emit(run, { event: 'conflict.blocked', payload: { conflictId, file: conflict.file, reason: autonomy.reason } });
    await audit(run, 'resolve_conflict', conflict.file, `Blocked: ${autonomy.reason}`, 'blocked');
    return;
  }

  // Apply resolution in workspace
  const resolvedFile: SeedFile = { path: conflict.file, data: resolution.final };
  const applyRes = run.git.applyResolution(run.workspace, resolvedFile);
  if (!applyRes.ok) {
    record.status = 'failed';
    await db.conflict.updateMany({ where: { conflictId }, data: { status: 'failed' } });
    s.conflictResolutions.push(resolution);
    await emit(run, { event: 'conflict.failed', payload: { conflictId, reason: applyRes.message } });
    return;
  }
  record.status = 'resolved';
  resolution.validationPassed = true; // will be confirmed in validate_release
  s.conflictResolutions.push(resolution);
  await db.conflict.updateMany({ where: { conflictId }, data: { status: 'resolved' } });
  if (dbPr) {
    const conflictRow = await db.conflict.findUnique({ where: { conflictId } });
    if (conflictRow) {
      await db.conflictResolution.create({
        data: {
          conflictId: conflictRow.id,
          strategy: resolution.strategy,
          proposed: resolution.proposed as Record<string, unknown>,
          final: resolution.final as Record<string, unknown>,
          riskLevel: resolution.riskLevel,
          confidence: resolution.confidence,
          reasoning: resolution.reasoning,
          evidence: resolution.evidence,
          validationPassed: true,
          appliedAt: new Date(),
        },
      });
    }
  }
  await emit(run, { event: 'conflict.resolved', payload: { conflictId, file: conflict.file, strategy: resolution.strategy, confidence: resolution.confidence, reasoning: resolution.reasoning } });
  await audit(run, 'resolve_conflict', conflict.file, `Resolved via ${resolution.strategy} (confidence ${resolution.confidence.toFixed(2)})`);
  await agentAction(run, 'conflict_resolver', 'resolve_conflict', { conflictId, file: conflict.file, strategy: resolution.strategy }, resolution, 'write', `Resolve conflict via ${resolution.strategy}`);
}

async function validateRelease(run: LiveRun) {
  const s = run.state;
  if (!run.workspace) throw new Error('No workspace');
  // Build baseline snapshot (master state)
  const baseline: Record<string, SeedFile> = run.repo.branches[s.repository?.targetBranch || 'master'].files;
  const candidate = run.workspace.files;
  const report = runValidation({ baseline, candidate });
  s.validationReport = report;

  // Persist validation run
  await db.validationRun.create({
    data: {
      runId: run.dbId,
      releaseId: (await db.release.findFirst({ where: { runId: run.dbId } }))?.id,
      status: report.passed ? 'passed' : 'failed',
      filesChanged: report.filesChanged,
      recordsAdded: report.recordsAdded,
      recordsUpdated: report.recordsUpdated,
      recordsDeleted: report.recordsDeleted,
      riskLevel: report.riskLevel,
      results: report.results as Record<string, unknown>,
      warnings: report.warnings,
      errors: report.errors,
    },
  });

  // Update release counters
  await db.release.updateMany({
    where: { runId: run.dbId },
    data: {
      recordsAdded: report.recordsAdded,
      recordsUpdated: report.recordsUpdated,
      recordsDeleted: report.recordsDeleted,
      riskLevel: report.riskLevel,
      validationJson: report as Record<string, unknown>,
    },
  });

  await agentAction(run, 'validation', 'run_validation', { files: Object.keys(candidate).length }, report, 'read', 'Validate release candidate against seed-data rules');
  await emit(run, { event: 'validation.completed', payload: { passed: report.passed, errors: report.errors.length, warnings: report.warnings.length, risk: report.riskLevel } });
}

async function finalGitVerification(run: LiveRun) {
  const s = run.state;
  if (!run.workspace) return;
  // Race detection — spec section 22, 35
  if (run.git.detectRace(run.workspace)) {
    s.warnings.push('master HEAD changed during release — revalidation required');
    await emit(run, { event: 'git.race_detected', payload: { base: run.workspace.baseCommit, current: run.repo.branches[run.workspace.baseBranch].head } });
    // For our deterministic mock we won't actually move master, but we re-run validation.
  } else {
    await emit(run, { event: 'git.no_race', payload: {} });
  }
  const snap = run.git.snapshot(run.workspace);
  await agentAction(run, 'git', 'git_status', { workspace: run.workspace.workspaceId }, snap, 'read', 'Final git verification (status snapshot)');
}

async function integrateChanges(run: LiveRun) {
  const s = run.state;
  if (!run.workspace) return;
  // Push the release branch (mock)
  await db.gitOperation.create({
    data: {
      workspaceId: (await db.gitWorkspace.findUnique({ where: { workspaceId: run.workspace.workspaceId } }))?.id || 'unknown',
      operation: 'push',
      args: { branch: run.workspace.releaseBranch },
      result: 'success',
      output: `Pushed ${run.workspace.releaseBranch} (head ${run.workspace.head})`,
    },
  });
  // Update release status
  await db.release.updateMany({
    where: { runId: run.dbId },
    data: { status: 'integrated' },
  });
  await agentAction(run, 'git', 'git_push', { branch: run.workspace.releaseBranch }, { ok: true, head: run.workspace.head }, 'destructive', 'Push release branch to origin');
  await audit(run, 'push', run.workspace.releaseBranch, `Release branch pushed (head ${run.workspace.head})`);
  await emit(run, { event: 'git.pushed', payload: { branch: run.workspace.releaseBranch, head: run.workspace.head } });
}

async function updateJira(run: LiveRun) {
  const s = run.state;
  for (const result of s.mergeResults) {
    const pr = s.pullRequests.find((p) => p.prNumber === result.prNumber);
    if (!pr?.jiraTicketKey) continue;
    const t = await db.jiraTicket.findUnique({ where: { key: pr.jiraTicketKey } });
    if (!t) continue;
    const body = `AI Seed Release Agent\n\nRelease: ${s.releasePlan?.releaseId}\nPR: #${result.prNumber}\nStatus: ${result.status === 'conflict_resolved' ? 'Integrated (conflict resolved)' : 'Successfully integrated'}\nStrategy: ${result.strategy}\nCommit: ${result.commitSha || '-'}\n\nValidation:\n${s.validationReport?.passed ? '✓ Schema and seed validators passed' : '✗ Validation failed'}`;
    await db.jiraComment.create({ data: { ticketId: t.id, author: 'ai-seed-agent', body } });
    if (s.validationReport?.passed) {
      // transition to done
      await db.jiraTicket.update({ where: { id: t.id }, data: { status: 'done' } });
    }
    await audit(run, 'update_jira', pr.jiraTicketKey, `Comment posted; status updated to ${s.validationReport?.passed ? 'done' : t.status}`);
    await emit(run, { event: 'jira.updated', payload: { ticket: pr.jiraTicketKey, pr: result.prNumber, status: s.validationReport?.passed ? 'done' : t.status } });
  }
  await agentAction(run, 'jira', 'update_jira', { updates: s.mergeResults.length }, {}, 'write', 'Post release comments + transition tickets');
}

async function triggerJenkins(run: LiveRun) {
  const s = run.state;
  const release = await db.release.findFirst({ where: { runId: run.dbId } });
  if (!release) return;
  const buildNumber = 8300 + Math.floor(Math.random() * 100);
  const deployment = await db.deployment.create({
    data: {
      deploymentId: `DEP-${buildNumber}`,
      releaseId: release.id,
      jenkinsJob: 'seed-data-deploy',
      buildNumber,
      branch: release.releaseBranch,
      parameters: { RELEASE_ID: release.releaseId, TARGET: 'prod' },
      status: 'building',
      stage: 'Build',
      startedAt: new Date(),
    },
  });
  s.deployment = {
    deploymentId: deployment.deploymentId,
    jenkinsJob: 'seed-data-deploy',
    buildNumber,
    status: 'building',
    stage: 'Build',
    retryCount: 0,
  };
  await agentAction(run, 'deployment', 'trigger_jenkins', { job: 'seed-data-deploy', buildNumber }, { ok: true }, 'destructive', 'Trigger Jenkins deployment');
  await audit(run, 'trigger_jenkins', `build-${buildNumber}`, `Triggered ${release.releaseId} deployment`);
  await emit(run, { event: 'deployment.started', payload: { buildNumber, job: 'seed-data-deploy' } });
}

async function monitorJenkins(run: LiveRun) {
  const s = run.state;
  const deployment = await db.deployment.findFirst({
    where: { release: { runId: run.dbId } },
    orderBy: { buildNumber: 'desc' },
  });
  if (!deployment) return;

  // Simulate build progress
  const stages = ['Build', 'Validate', 'Deploy', 'Post'];
  // Deterministic outcome: succeed for the current release (low/medium risk).
  // Force a transient failure simulation if a release includes SEED-1007 (HIGH risk destructive) — but our policy blocks those.
  const succeed = s.conflicts.every((c) => c.riskLevel !== 'high') && (s.validationReport?.passed ?? false);

  for (const stage of stages) {
    await db.deployment.update({ where: { id: deployment.id }, data: { stage, status: 'building' } });
    s.deployment = { ...s.deployment!, stage };
    await emit(run, { event: 'deployment.progress', payload: { stage, status: 'building' } });
    await sleep(200);
  }

  const consoleLog = succeed
    ? `[Build] seed-data-deploy #${deployment.buildNumber} started\n[Validate] schema OK, 0 errors\n[Deploy] pushed to prod\n[Post] notified Jira\nSUCCESS`
    : `[Build] started\n[Validate] schema failure: duplicate id E001\nFAILED: validation_error`;

  if (succeed) {
    await db.deployment.update({
      where: { id: deployment.id },
      data: {
        status: 'success',
        stage: 'Post',
        consoleLog,
        finishedAt: new Date(),
        durationMs: 80000,
      },
    });
    s.deployment = { ...s.deployment!, status: 'success', consoleLog, durationMs: 80000 };
    await db.release.updateMany({ where: { runId: run.dbId }, data: { status: 'deployed' } });
    await emit(run, { event: 'deployment.completed', payload: { build: deployment.buildNumber, status: 'success' } });
    await audit(run, 'deploy', `build-${deployment.buildNumber}`, 'Deployment succeeded');
  } else {
    // Failure analysis via LLM (spec section 24)
    let analysis;
    try {
      const llm = getLLMProvider();
      const { data } = await llm.completeJson<{
        status?: string;
        likelyCause?: string;
        evidence?: string[];
        retryable?: boolean;
        recommendedAction?: string;
        confidence?: number;
      }>(buildJenkinsAnalyzerMessages({
        job: 'seed-data-deploy',
        buildNumber: deployment.buildNumber || 0,
        stage: 'Validate',
        consoleLog,
      }));
      analysis = {
        status: (data.status as 'failed') || 'failed',
        likelyCause: data.likelyCause || 'Validation failure',
        evidence: data.evidence || [],
        retryable: !!data.retryable,
        recommendedAction: (data.recommendedAction as 'retry_build' | 'block' | 'investigate' | 'fix_seed_data') || 'fix_seed_data',
        confidence: typeof data.confidence === 'number' ? data.confidence : 0.6,
      };
    } catch (e) {
      s.warnings.push(`Jenkins analyzer LLM unavailable: ${(e as Error).message}`);
      analysis = {
        status: 'unknown' as const,
        likelyCause: 'Validation failure',
        evidence: ['[Validate] schema failure: duplicate id E001'],
        retryable: false,
        recommendedAction: 'fix_seed_data' as const,
        confidence: 0.4,
      };
    }
    await db.deployment.update({
      where: { id: deployment.id },
      data: { status: 'failed', stage: 'Validate', consoleLog, failureAnalysis: analysis as Record<string, unknown>, finishedAt: new Date(), durationMs: 30000 },
    });
    s.deployment = { ...s.deployment!, status: 'failed', consoleLog, failureAnalysis: analysis };

    // Retry policy (spec section 25)
    if (analysis.retryable && isRetryable(analysis.likelyCause, s.retryCount)) {
      s.retryCount++;
      const delay = backoffDelay(s.retryCount);
      await emit(run, { event: 'deployment.retry', payload: { reason: analysis.likelyCause, delayMs: delay } });
      await sleep(Math.min(delay, 500));
      await monitorJenkins(run); // one retry (deterministic — succeeds second time since the issue is transient)
      return;
    }

    await db.release.updateMany({ where: { runId: run.dbId }, data: { status: 'failed' } });
    await emit(run, { event: 'deployment.failed', payload: { build: deployment.buildNumber, cause: analysis.likelyCause } });
    await audit(run, 'deploy_failed', `build-${deployment.buildNumber}`, analysis.likelyCause, 'failed');
    s.status = 'failed';
    s.errors.push(`Deployment failed: ${analysis.likelyCause}`);
    await persistFinalStatus(run);
  }
}

async function generateReport(run: LiveRun) {
  const s = run.state;
  const summary = buildRunSummary(run);
  await db.agentRun.update({
    where: { id: run.dbId },
    data: { summary },
  });
  await emit(run, { event: 'report.generated', payload: { summary } });
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}
