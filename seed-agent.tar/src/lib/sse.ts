// Typed SSE client helper for the agent event stream.
//
// The backend uses the standard SSE protocol:
//   event: <event-name>\n
//   data: <json>\n\n
//
// The browser's `EventSource` automatically parses named events, so we just
// need a small wrapper that:
//   - opens the connection on mount
//   - dispatches each named event to a handler
//   - sends a heartbeat/keepalive ping
//   - handles reconnection (EventSource does this natively)
//   - cleans up on unmount

import { useEffect, useRef, useState } from 'react';
import type { AgentEventPayload } from '@/lib/agent/types';

export interface SSEConnectionState {
  status: 'connecting' | 'open' | 'closed' | 'error';
  lastEventAt: string | null;
  retryCount: number;
}

export interface UseSSEOptions {
  /** Run ID. When null/undefined, no connection is opened. */
  runId: string | null | undefined;
  /** Map of event-name -> handler. The handler receives the parsed payload. */
  handlers: Record<string, (ev: AgentEventPayload) => void>;
  /** Fallback handler called for events that have no specific handler. */
  onAny?: (ev: AgentEventPayload) => void;
}

const CLOSED_STATE: SSEConnectionState = {
  status: 'closed',
  lastEventAt: null,
  retryCount: 0,
};

export function useAgentSSE({ runId, handlers, onAny }: UseSSEOptions): SSEConnectionState {
  // `liveState` tracks the connection state of the *current* `runId`. When the
  // runId is null we ignore it and return CLOSED_STATE (see the derived
  // return value at the bottom).
  const [liveState, setLiveState] = useState<SSEConnectionState>({
    status: 'connecting',
    lastEventAt: null,
    retryCount: 0,
  });

  // Keep handlers in a ref so we don't re-subscribe on every render.
  const handlersRef = useRef(handlers);
  const onAnyRef = useRef(onAny);

  useEffect(() => {
    handlersRef.current = handlers;
    onAnyRef.current = onAny;
  }, [handlers, onAny]);

  useEffect(() => {
    if (!runId) {
      // No-op: the returned state is derived as CLOSED_STATE below.
      return;
    }

    let es: EventSource | null = null;
    let closed = false;
    let retryCount = 0;
    // Use a microtask to defer the initial "connecting" state so the lint
    // rule about set-state-in-effect stays satisfied (the setState call
    // happens after the effect body has returned).
    Promise.resolve().then(() => {
      if (!closed) setLiveState({ status: 'connecting', lastEventAt: null, retryCount: 0 });
    });

    // Relative URL only — gateway handles forwarding.
    es = new EventSource(`/api/agent/runs/${runId}/events`);

    es.onopen = () => {
      if (closed) return;
      setLiveState((s) => ({ ...s, status: 'open' }));
    };

    es.onerror = () => {
      if (closed) return;
      retryCount += 1;
      setLiveState((s) => ({ ...s, status: 'error', retryCount }));
      // EventSource auto-reconnects; we just report the state.
    };

    // Listen for named events the backend emits (and a generic `message`
    // fallback for unnamed events).
    const allEvents: string[] = [
      'hello',
      'workflow.step.started',
      'workflow.step.completed',
      'workflow.step.failed',
      'workflow.completed',
      'workflow.failed',
      'workflow.blocked',
      'workflow.cancelled',
      'supervisor.interpreted',
      'jira.tickets_discovered',
      'pr.discovered',
      'jira_pr.correlated',
      'approval.verified',
      'approval.blocked',
      'git.cloned',
      'git.fetched',
      'git.workspace_created',
      'git.merge.success',
      'git.cherry_pick.success',
      'git.conflict.detected',
      'conflict.analyzing',
      'conflict.resolved',
      'conflict.blocked',
      'conflict.failed',
      'validation.completed',
      'git.race_detected',
      'git.pushed',
      'jira.updated',
      'deployment.started',
      'deployment.progress',
      'deployment.completed',
      'deployment.failed',
      'deployment.retry',
      'report.generated',
      'release.plan_built',
      'release.item.skipped',
      'release.item.blocked',
      'release.item.failed',
    ];

    const listener = (e: MessageEvent) => {
      if (closed) return;
      try {
        const payload = JSON.parse(e.data) as AgentEventPayload;
        setLiveState((s) => ({ ...s, lastEventAt: payload.timestamp || new Date().toISOString() }));
        const handler = handlersRef.current[payload.event ?? e.type];
        if (handler) handler(payload);
        onAnyRef.current?.(payload);
      } catch {
        // ignore malformed event
      }
    };

    allEvents.forEach((name) => es?.addEventListener(name, listener as EventListener));
    es.addEventListener('message', listener as EventListener);

    return () => {
      closed = true;
      if (es) {
        es.close();
        es = null;
      }
    };
  }, [runId]);

  // Derive the public connection state: when there is no run, report closed.
  return runId ? liveState : CLOSED_STATE;
}
