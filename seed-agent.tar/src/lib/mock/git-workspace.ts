// Mock seed-data repository simulator.
//
// Per spec section 7-8, the Git workspace is a FIRST-CLASS component. We can't
// reach a real Bitbucket server from this sandbox, so we simulate an isolated
// Git workspace backed by in-memory seed-data files. The simulator supports
// clone, fetch, checkout, create_branch, merge, cherry_pick, conflict
// detection (real semantic diff on JSON), abort, and patch application —
// enough to drive the autonomous workflow exactly like the spec describes.

import { v4 as uuid } from 'uuid';

// ---------- Seed data types ----------

export interface EmployeeRecord {
  id: string;
  name: string;
  email: string;
  department: string;
  role: string;
  active: boolean;
}

export interface ProjectRecord {
  id: string;
  name: string;
  owner: string;
  status: 'active' | 'archived' | 'planned';
}

export interface SeedFile {
  path: string;
  data: unknown; // usually object/array
}

export interface BranchState {
  name: string;
  head: string; // commit sha
  files: Record<string, SeedFile>;
  commits: { sha: string; message: string; author: string; parents: string[] }[];
}

// ---------- Mock repository ----------

const BASE_EMPLOYEES: EmployeeRecord[] = [
  { id: 'E001', name: 'Alice Anderson', email: 'alice@corp.io', department: 'Engineering', role: 'Staff Engineer', active: true },
  { id: 'E002', name: 'Bob Brown', email: 'bob@corp.io', department: 'Engineering', role: 'Senior Engineer', active: true },
  { id: 'E003', name: 'Carol Chen', email: 'carol@corp.io', department: 'Design', role: 'Lead Designer', active: true },
  { id: 'E004', name: 'David Diaz', email: 'david@corp.io', department: 'Engineering', role: 'Engineer', active: true },
  { id: 'E005', name: 'Eve Edwards', email: 'eve@corp.io', department: 'Engineering', role: 'Engineer', active: true },
  { id: 'E006', name: 'Frank Foster', email: 'frank@corp.io', department: 'Sales', role: 'Account Exec', active: true },
  { id: 'E007', name: 'Grace Green', email: 'grace@corp.io', department: 'Sales', role: 'Account Exec', active: true },
  { id: 'E008', name: 'Henry Harris', email: 'henry@corp.io', department: 'HR', role: 'HR Partner', active: true },
];

const BASE_PROJECTS: ProjectRecord[] = [
  { id: 'P100', name: 'Atlas Platform', owner: 'E001', status: 'active' },
  { id: 'P101', name: 'Beacon Mobile', owner: 'E002', status: 'active' },
  { id: 'P102', name: 'Compass Analytics', owner: 'E003', status: 'planned' },
];

export interface MockRepo {
  name: string;
  branches: Record<string, BranchState>; // branch name -> state
  targetBranch: string;
}

// Build the canonical mock repository used for every fresh simulation.
export function buildMockRepo(): MockRepo {
  const masterSha = randomSha();
  const masterFiles: Record<string, SeedFile> = {
    'seed/employees.json': { path: 'seed/employees.json', data: BASE_EMPLOYEES.slice() },
    'seed/projects.json': { path: 'seed/projects.json', data: BASE_PROJECTS.slice() },
    'seed/config.json': {
      path: 'seed/config.json',
      data: {
        version: '2026.09',
        schema: 'v1',
        retentionDays: 90,
        flags: { enableAudit: true, enableRollback: false },
      },
    },
  };
  const masterBranch: BranchState = {
    name: 'master',
    head: masterSha,
    files: deepClone(masterFiles),
    commits: [{ sha: masterSha, message: 'chore(seed): baseline seed data 2026.09', author: 'seed-bot', parents: [] }],
  };

  // Branch A: feature/SEED-1001 — add 2 employees (non-conflicting additive)
  const branchA = branchFrom(masterBranch, 'feature/SEED-1001', [
    {
      path: 'seed/employees.json',
      transform: (data: unknown) => {
        const arr = (data as EmployeeRecord[]).slice();
        arr.push(
          { id: 'E009', name: 'Ivy Irwin', email: 'ivy@corp.io', department: 'Engineering', role: 'Engineer', active: true },
          { id: 'E010', name: 'Jack Jones', email: 'jack@corp.io', department: 'Engineering', role: 'Engineer', active: true },
        );
        return arr;
      },
      message: 'SEED-1001: add Ivy and Jack to Engineering',
    },
  ]);

  // Branch B: feature/SEED-1002 — modify E001 role (non-conflicting single record edit)
  const branchB = branchFrom(masterBranch, 'feature/SEED-1002', [
    {
      path: 'seed/employees.json',
      transform: (data: unknown) => {
        const arr = (data as EmployeeRecord[]).map((e) =>
          e.id === 'E001' ? { ...e, role: 'Principal Engineer' } : e,
        );
        return arr;
      },
      message: 'SEED-1002: promote Alice to Principal Engineer',
    },
  ]);

  // Branch C: feature/SEED-1003 — add a project (additive, separate file region)
  const branchC = branchFrom(masterBranch, 'feature/SEED-1003', [
    {
      path: 'seed/projects.json',
      transform: (data: unknown) => {
        const arr = (data as ProjectRecord[]).slice();
        arr.push({ id: 'P103', name: 'Delta Data Lake', owner: 'E004', status: 'planned' });
        return arr;
      },
      message: 'SEED-1003: add Delta Data Lake project',
    },
  ]);

  // Branch D: feature/SEED-1004 — CONFLICT with branch B: also modifies E001 (different field)
  // This conflict IS resolvable semantically (different fields) → LOW/MEDIUM risk.
  const branchD = branchFrom(masterBranch, 'feature/SEED-1004', [
    {
      path: 'seed/employees.json',
      transform: (data: unknown) => {
        const arr = (data as EmployeeRecord[]).map((e) =>
          e.id === 'E001' ? { ...e, department: 'Office of the CTO' } : e,
        );
        return arr;
      },
      message: 'SEED-1004: move Alice to Office of the CTO',
    },
  ]);

  // Branch E: feature/SEED-1005 — HIGH risk conflict: changes E001 role to a different value than B.
  // Same field, conflicting values → manual_block expected.
  const branchE = branchFrom(masterBranch, 'feature/SEED-1005', [
    {
      path: 'seed/employees.json',
      transform: (data: unknown) => {
        const arr = (data as EmployeeRecord[]).map((e) =>
          e.id === 'E001' ? { ...e, role: 'VP Engineering' } : e,
        );
        return arr;
      },
      message: 'SEED-1005: appoint Alice as VP Engineering',
    },
  ]);

  // Branch F: feature/SEED-1006 — already integrated (simulated: mergeable cleanly)
  const branchF = branchFrom(masterBranch, 'feature/SEED-1006', [
    {
      path: 'seed/config.json',
      transform: (data: unknown) => {
        const cfg = data as { version: string; schema: string; retentionDays: number; flags: { enableAudit: boolean; enableRollback: boolean } };
        return { ...cfg, retentionDays: 120 };
      },
      message: 'SEED-1006: extend retention to 120 days',
    },
  ]);

  // Branch G: feature/SEED-1007 — mass deletion (HIGH risk destructive change)
  const branchG = branchFrom(masterBranch, 'feature/SEED-1007', [
    {
      path: 'seed/employees.json',
      transform: (data: unknown) => {
        const arr = (data as EmployeeRecord[]).filter((e) => !['E006', 'E007', 'E008'].includes(e.id));
        return arr;
      },
      message: 'SEED-1007: remove departed Sales/HR employees',
    },
  ]);

  return {
    name: 'seed-data',
    targetBranch: 'master',
    branches: {
      master: masterBranch,
      'feature/SEED-1001': branchA,
      'feature/SEED-1002': branchB,
      'feature/SEED-1003': branchC,
      'feature/SEED-1004': branchD,
      'feature/SEED-1005': branchE,
      'feature/SEED-1006': branchF,
      'feature/SEED-1007': branchG,
    },
  };
}

function branchFrom(
  base: BranchState,
  name: string,
  changes: { path: string; transform: (data: unknown) => unknown; message: string }[],
): BranchState {
  const files = deepClone(base.files);
  const commits = base.commits.slice();
  let parent = base.head;
  for (const change of changes) {
    const file = files[change.path];
    const newData = change.transform(file ? file.data : null);
    files[change.path] = { path: change.path, data: newData };
    const sha = randomSha();
    commits.push({ sha, message: change.message, author: 'employee@corp.io', parents: [parent] });
    parent = sha;
  }
  return { name, head: parent, files, commits };
}

// ---------- Workspace operations ----------

export interface Workspace {
  workspaceId: string;
  repoName: string;
  baseBranch: string;
  releaseBranch: string;
  // current state
  head: string;
  files: Record<string, SeedFile>;
  commits: { sha: string; message: string; author: string; parents: string[] }[];
  // pending merge/cherry-pick state
  pendingConflict: PendingConflict | null;
  baseCommit: string; // master HEAD when workspace was created (for race detection)
}

export interface PendingConflict {
  file: string;
  base: unknown;
  ours: unknown;
  theirs: unknown;
  sourceBranch: string;
  sourceHead: string;
  prNumber?: number;
}

export interface GitOperationResult {
  ok: boolean;
  conflict?: PendingConflict;
  message?: string;
  filesChanged?: string[];
  commitSha?: string;
}

export class GitWorkspaceManager {
  private repo: MockRepo;
  constructor(repo: MockRepo) {
    this.repo = repo;
  }

  createWorkspace(workspaceId: string, baseBranch: string, releaseBranch: string): Workspace {
    const base = this.repo.branches[baseBranch];
    if (!base) throw new Error(`Branch ${baseBranch} not found in mock repo`);
    return {
      workspaceId,
      repoName: this.repo.name,
      baseBranch,
      releaseBranch,
      head: base.head,
      files: deepClone(base.files),
      commits: base.commits.slice(),
      pendingConflict: null,
      baseCommit: base.head,
    };
  }

  fetch(_remote: string): GitOperationResult {
    return { ok: true, message: 'Fetched origin' };
  }

  checkout(_branch: string): GitOperationResult {
    return { ok: true };
  }

  // Try to merge or cherry-pick a branch's tip into the workspace.
  // Returns conflict info if a real semantic conflict is detected.
  applyBranch(
    ws: Workspace,
    sourceBranch: string,
    mode: 'merge' | 'cherry_pick',
    prNumber?: number,
  ): GitOperationResult {
    const source = this.repo.branches[sourceBranch];
    if (!source) return { ok: false, message: `Branch ${sourceBranch} not found` };

    // Compute diff between base commit (master) and source head, applied onto current ws.
    // We do this by comparing each file in source vs base.
    const baseBranchState = this.repo.branches[this.repo.targetBranch];
    const filesChanged: string[] = [];
    const newFiles: Record<string, SeedFile> = deepClone(ws.files);

    for (const [path, sourceFile] of Object.entries(source.files)) {
      const baseFile = baseBranchState.files[path];
      const ourFile = ws.files[path];
      if (JSON.stringify(sourceFile.data) === JSON.stringify(baseFile?.data)) {
        // No change in source for this file
        continue;
      }
      if (!ourFile || JSON.stringify(ourFile.data) === JSON.stringify(baseFile?.data)) {
        // We haven't changed this file since base → fast-forward
        newFiles[path] = deepClone(sourceFile);
        filesChanged.push(path);
        continue;
      }
      // Both we and source changed this file since base → potential conflict
      const conflict = detectConflict(path, baseFile?.data, ourFile.data, sourceFile.data);
      if (conflict) {
        ws.pendingConflict = {
          file: path,
          base: baseFile?.data,
          ours: ourFile.data,
          theirs: sourceFile.data,
          sourceBranch,
          sourceHead: source.head,
          prNumber,
        };
        return {
          ok: false,
          conflict: ws.pendingConflict,
          message: `CONFLICT on ${path} while ${mode === 'merge' ? 'merging' : 'cherry-picking'} ${sourceBranch}`,
          filesChanged,
        };
      }
      // No real conflict (both modified same file but produced equal results) → take source
      newFiles[path] = deepClone(sourceFile);
      filesChanged.push(path);
    }

    // Commit the result
    ws.files = newFiles;
    const sha = randomSha();
    ws.commits.push({
      sha,
      message:
        mode === 'merge'
          ? `Merge branch '${sourceBranch}' into ${ws.releaseBranch}`
          : `Cherry-pick ${sourceBranch}: ${source.commits[source.commits.length - 1]?.message || ''}`,
      author: 'ai-seed-agent',
      parents: [ws.head, ...(mode === 'merge' ? [source.head] : [])],
    });
    ws.head = sha;
    ws.pendingConflict = null;
    return { ok: true, message: `${mode} of ${sourceBranch} succeeded`, filesChanged, commitSha: sha };
  }

  applyResolution(ws: Workspace, resolvedFile: SeedFile): GitOperationResult {
    if (!ws.pendingConflict) return { ok: false, message: 'No pending conflict' };
    const conflict = ws.pendingConflict;
    ws.files[conflict.file] = resolvedFile;
    const sha = randomSha();
    ws.commits.push({
      sha,
      message: `Resolve conflict on ${conflict.file} (${conflict.sourceBranch})`,
      author: 'ai-seed-agent',
      parents: [ws.head],
    });
    ws.head = sha;
    ws.pendingConflict = null;
    return { ok: true, message: `Conflict resolved on ${conflict.file}`, filesChanged: [conflict.file], commitSha: sha };
  }

  abortOperation(ws: Workspace): GitOperationResult {
    ws.pendingConflict = null;
    return { ok: true, message: 'Aborted' };
  }

  // Detect race: master HEAD changed after workspace was created.
  detectRace(ws: Workspace): boolean {
    const current = this.repo.branches[this.repo.targetBranch];
    return current.head !== ws.baseCommit;
  }

  snapshot(ws: Workspace) {
    return {
      head: ws.head,
      files: Object.keys(ws.files),
      fileCount: Object.keys(ws.files).length,
      commits: ws.commits.length,
      pendingConflict: ws.pendingConflict ? ws.pendingConflict.file : null,
    };
  }
}

// ---------- Conflict detection ----------

export function detectConflict(
  file: string,
  baseData: unknown,
  oursData: unknown,
  theirsData: unknown,
): PendingConflict | null {
  // For JSON arrays of records with `id`, compute per-id conflicts.
  // For JSON objects, compute per-key conflicts.
  if (Array.isArray(baseData) && Array.isArray(oursData) && Array.isArray(theirsData)) {
    const baseArr = baseData as { id?: string }[];
    const ourArr = oursData as { id?: string }[];
    const theirArr = theirsData as { id?: string }[];
    const baseIds = new Set(baseArr.filter((r) => r && r.id).map((r) => r.id));
    // Detect mass deletion (>40% of records removed)
    const removed = baseArr.filter((r) => r && r.id && !ourArr.find((x) => x.id === r.id));
    if (removed.length >= baseArr.length * 0.3 && baseArr.length > 2) {
      return { file, base: baseData, ours: oursData, theirs: theirsData, sourceBranch: '', sourceHead: '' };
    }
    const removedTheirs = baseArr.filter((r) => r && r.id && !theirArr.find((x) => x.id === r.id));
    if (removedTheirs.length >= baseArr.length * 0.3 && baseArr.length > 2) {
      return { file, base: baseData, ours: oursData, theirs: theirsData, sourceBranch: '', sourceHead: '' };
    }
    // Per-id field-level conflict
    for (const baseRec of baseArr) {
      if (!baseRec || !baseRec.id) continue;
      if (!baseIds.has(baseRec.id)) continue;
      const ourRec = ourArr.find((x) => x.id === baseRec.id);
      const theirRec = theirArr.find((x) => x.id === baseRec.id);
      if (!ourRec || !theirRec) continue;
      const ourChanged = JSON.stringify(ourRec) !== JSON.stringify(baseRec);
      const theirChanged = JSON.stringify(theirRec) !== JSON.stringify(baseRec);
      if (ourChanged && theirChanged) {
        const ourDiff = diffFields(baseRec, ourRec);
        const theirDiff = diffFields(baseRec, theirRec);
        const overlap = Object.keys(ourDiff).filter((k) => k in theirDiff && JSON.stringify(ourDiff[k]) !== JSON.stringify(theirDiff[k]));
        if (overlap.length > 0) {
          return { file, base: baseData, ours: oursData, theirs: theirsData, sourceBranch: '', sourceHead: '' };
        }
      }
    }
    return null;
  }
  if (baseData && typeof baseData === 'object' && !Array.isArray(baseData)) {
    const baseObj = baseData as Record<string, unknown>;
    const ourObj = oursData as Record<string, unknown>;
    const theirObj = theirsData as Record<string, unknown>;
    for (const k of Object.keys(baseObj)) {
      const ourChanged = JSON.stringify(ourObj?.[k]) !== JSON.stringify(baseObj[k]);
      const theirChanged = JSON.stringify(theirObj?.[k]) !== JSON.stringify(baseObj[k]);
      if (ourChanged && theirChanged && JSON.stringify(ourObj?.[k]) !== JSON.stringify(theirObj?.[k])) {
        return { file, base: baseData, ours: oursData, theirs: theirsData, sourceBranch: '', sourceHead: '' };
      }
    }
    return null;
  }
  // Primitive/scalar
  if (JSON.stringify(oursData) !== JSON.stringify(theirsData)) {
    return { file, base: baseData, ours: oursData, theirs: theirsData, sourceBranch: '', sourceHead: '' };
  }
  return null;
}

function diffFields(base: Record<string, unknown>, other: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const k of Object.keys(base)) {
    if (JSON.stringify(base[k]) !== JSON.stringify(other?.[k])) out[k] = other?.[k];
  }
  return out;
}

// ---------- Utilities ----------

function deepClone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v)) as T;
}

export function randomSha(): string {
  return uuid().replace(/-/g, '').slice(0, 12);
}

export function classifyRisk(file: string, base: unknown, ours: unknown, theirs: unknown): 'low' | 'medium' | 'high' {
  // Mass deletion detection
  if (Array.isArray(base) && Array.isArray(ours)) {
    const removed = (base as { id?: string }[]).filter((r) => r && r.id && !(ours as { id?: string }[]).find((x) => x.id === r.id));
    if (removed.length >= 3) return 'high';
    if (removed.length >= 1) return 'medium';
  }
  if (Array.isArray(base) && Array.isArray(theirs)) {
    const removed = (base as { id?: string }[]).filter((r) => r && r.id && !(theirs as { id?: string }[]).find((x) => x.id === r.id));
    if (removed.length >= 3) return 'high';
    if (removed.length >= 1) return 'medium';
  }
  // Same record different field value → medium
  if (Array.isArray(base) && Array.isArray(ours) && Array.isArray(theirs)) {
    for (const baseRec of base as { id?: string; [k: string]: unknown }[]) {
      if (!baseRec || !baseRec.id) continue;
      const ourRec = (ours as { id?: string; [k: string]: unknown }[]).find((x) => x.id === baseRec.id);
      const theirRec = (theirs as { id?: string; [k: string]: unknown }[]).find((x) => x.id === baseRec.id);
      if (!ourRec || !theirRec) continue;
      const ourDiff = diffFields(baseRec, ourRec);
      const theirDiff = diffFields(baseRec, theirRec);
      const overlap = Object.keys(ourDiff).filter((k) => k in theirDiff && JSON.stringify(ourDiff[k]) !== JSON.stringify(theirDiff[k]));
      if (overlap.length > 0) return 'high';
    }
  }
  return 'low';
}
