// Seed script — populates the database with realistic mock data:
// a seed-data repository, Jira tickets, Bitbucket PRs (correlated to
// the mock repo's branches), approval evidence, and a few historical
// agent runs / releases / deployments for the dashboard.
//
// Run with: bun run src/lib/mock/seed.ts

import { db } from '@/lib/db';

async function main() {
  console.log('Seeding AI Seed Release Agent mock data...');

  // 1. Repository
  const repo = await db.repository.upsert({
    where: { name: 'seed-data' },
    update: {},
    create: {
      name: 'seed-data',
      slug: 'seed-data',
      provider: 'bitbucket',
      targetBranch: 'master',
      cloneUrl: 'https://bitbucket.corp.io/scm/seed/seed-data.git',
    },
  });

  // 2. A few users
  const users = [
    { email: 'alice@corp.io', name: 'Alice Anderson', role: 'engineer' },
    { email: 'bob@corp.io', name: 'Bob Brown', role: 'engineer' },
    { email: 'seed-team@corp.io', name: 'Seed Team', role: 'seed_team' },
    { email: 'admin@corp.io', name: 'Admin', role: 'admin' },
  ];
  for (const u of users) {
    await db.user.upsert({ where: { email: u.email }, update: {}, create: u });
  }

  // 3. Jira tickets + correlated PRs + approval evidence.
  // We define 7 tickets corresponding to the 7 mock branches SEED-1001..1007.
  type Seed = {
    key: string;
    summary: string;
    description: string;
    status: string;
    assignee: string;
    reporter: string;
    prUrl: string;
    prNumber: number;
    prTitle: string;
    sourceBranch: string;
    prAuthor: string;
    prState: string;
    prReviewStatus: string;
    prReviewers: number;
    prRequiredReviewers: number;
    prApproved: boolean;
    prMergeable: boolean;
    prCommits: { sha: string; message: string; author: string }[];
    prFilesChanged: { path: string; additions: number; deletions: number }[];
    approvals: { source: string; evidence: string; confidence: number }[];
    comments: { author: string; body: string }[];
    attachments: { filename: string; mimeType: string; size: number; content: string; isApproval: boolean }[];
  };

  const seeds: Seed[] = [
    {
      key: 'SEED-1001',
      summary: 'Onboard Ivy and Jack into Engineering',
      description: 'Two new engineers joining the platform team. Approve to add to seed/employees.json.',
      status: 'approved',
      assignee: 'alice@corp.io',
      reporter: 'recruiting@corp.io',
      prUrl: `https://bitbucket.corp.io/seed/seed-data/pull-requests/101`,
      prNumber: 101,
      prTitle: 'SEED-1001: add Ivy and Jack to Engineering',
      sourceBranch: 'feature/SEED-1001',
      prAuthor: 'alice@corp.io',
      prState: 'open',
      prReviewStatus: 'approved',
      prReviewers: 3,
      prRequiredReviewers: 2,
      prApproved: true,
      prMergeable: true,
      prCommits: [{ sha: 'a1b2c3d4e5f6', message: 'SEED-1001: add Ivy and Jack to Engineering', author: 'alice@corp.io' }],
      prFilesChanged: [{ path: 'seed/employees.json', additions: 2, deletions: 0 }],
      approvals: [
        { source: 'jira_status', evidence: 'Jira status is "approved"', confidence: 1 },
        { source: 'bitbucket_reviewer', evidence: '3 reviewers approved (>= 2 required)', confidence: 1 },
      ],
      comments: [
        { author: 'seed-team@corp.io', body: 'LGTM, please proceed.' },
        { author: 'alice@corp.io', body: 'PR: https://bitbucket.corp.io/seed/seed-data/pull-requests/101' },
      ],
      attachments: [],
    },
    {
      key: 'SEED-1002',
      summary: 'Promote Alice to Principal Engineer',
      description: 'Alice promoted to Principal Engineer. Update role on seed/employees.json E001.',
      status: 'approved',
      assignee: 'bob@corp.io',
      reporter: 'alice@corp.io',
      prUrl: `https://bitbucket.corp.io/seed/seed-data/pull-requests/102`,
      prNumber: 102,
      prTitle: 'SEED-1002: promote Alice to Principal Engineer',
      sourceBranch: 'feature/SEED-1002',
      prAuthor: 'bob@corp.io',
      prState: 'open',
      prReviewStatus: 'approved',
      prReviewers: 2,
      prRequiredReviewers: 2,
      prApproved: true,
      prMergeable: true,
      prCommits: [{ sha: 'b2c3d4e5f6a1', message: 'SEED-1002: promote Alice to Principal Engineer', author: 'bob@corp.io' }],
      prFilesChanged: [{ path: 'seed/employees.json', additions: 1, deletions: 1 }],
      approvals: [
        { source: 'jira_status', evidence: 'Jira status is "approved"', confidence: 1 },
        { source: 'jira_attachment', evidence: 'Signed approval PDF "SEED-1002-approval.pdf" attached', confidence: 0.95 },
        { source: 'bitbucket_reviewer', evidence: '2 reviewers approved (meets requirement)', confidence: 1 },
      ],
      comments: [{ author: 'seed-team@corp.io', body: 'Approved via signed PDF.' }],
      attachments: [
        {
          filename: 'SEED-1002-approval.pdf',
          mimeType: 'application/pdf',
          size: 102400,
          content: 'APPROVAL DOCUMENT\n\nThis certifies that the seed-data change SEED-1002 (promote Alice Anderson to Principal Engineer) has been reviewed and approved by the Seed Team Lead on 2026-09-08.\n\nSignature: Seed Team Lead',
          isApproval: true,
        },
      ],
    },
    {
      key: 'SEED-1003',
      summary: 'Add Delta Data Lake project',
      description: 'New project P103 Delta Data Lake owned by E004. Add to seed/projects.json.',
      status: 'approved',
      assignee: 'david@corp.io',
      reporter: 'david@corp.io',
      prUrl: `https://bitbucket.corp.io/seed/seed-data/pull-requests/103`,
      prNumber: 103,
      prTitle: 'SEED-1003: add Delta Data Lake project',
      sourceBranch: 'feature/SEED-1003',
      prAuthor: 'david@corp.io',
      prState: 'open',
      prReviewStatus: 'approved',
      prReviewers: 2,
      prRequiredReviewers: 2,
      prApproved: true,
      prMergeable: true,
      prCommits: [{ sha: 'c3d4e5f6a1b2', message: 'SEED-1003: add Delta Data Lake project', author: 'david@corp.io' }],
      prFilesChanged: [{ path: 'seed/projects.json', additions: 1, deletions: 0 }],
      approvals: [
        { source: 'jira_status', evidence: 'Jira status is "approved"', confidence: 1 },
        { source: 'bitbucket_reviewer', evidence: '2 reviewers approved', confidence: 1 },
      ],
      comments: [],
      attachments: [],
    },
    {
      key: 'SEED-1004',
      summary: 'Move Alice to Office of the CTO',
      description: 'Reassign Alice (E001) to Office of the CTO. Updates department field on seed/employees.json E001.',
      status: 'approved',
      assignee: 'alice@corp.io',
      reporter: 'cto@corp.io',
      prUrl: `https://bitbucket.corp.io/seed/seed-data/pull-requests/104`,
      prNumber: 104,
      prTitle: 'SEED-1004: move Alice to Office of the CTO',
      sourceBranch: 'feature/SEED-1004',
      prAuthor: 'cto@corp.io',
      prState: 'open',
      prReviewStatus: 'approved',
      prReviewers: 2,
      prRequiredReviewers: 2,
      prApproved: true,
      prMergeable: true,
      prCommits: [{ sha: 'd4e5f6a1b2c3', message: 'SEED-1004: move Alice to Office of the CTO', author: 'cto@corp.io' }],
      prFilesChanged: [{ path: 'seed/employees.json', additions: 1, deletions: 1 }],
      approvals: [
        { source: 'jira_status', evidence: 'Jira status is "approved"', confidence: 1 },
        { source: 'bitbucket_reviewer', evidence: '2 reviewers approved', confidence: 1 },
      ],
      comments: [],
      attachments: [],
    },
    {
      key: 'SEED-1005',
      summary: 'Appoint Alice as VP Engineering',
      description: 'Promote Alice (E001) to VP Engineering. CONFLICTS with SEED-1002 (same field, different value).',
      status: 'in_review',
      assignee: 'cto@corp.io',
      reporter: 'cto@corp.io',
      prUrl: `https://bitbucket.corp.io/seed/seed-data/pull-requests/105`,
      prNumber: 105,
      prTitle: 'SEED-1005: appoint Alice as VP Engineering',
      sourceBranch: 'feature/SEED-1005',
      prAuthor: 'cto@corp.io',
      prState: 'open',
      prReviewStatus: 'pending',
      prReviewers: 1,
      prRequiredReviewers: 2,
      prApproved: false,
      prMergeable: false,
      prCommits: [{ sha: 'e5f6a1b2c3d4', message: 'SEED-1005: appoint Alice as VP Engineering', author: 'cto@corp.io' }],
      prFilesChanged: [{ path: 'seed/employees.json', additions: 1, deletions: 1 }],
      approvals: [{ source: 'bitbucket_reviewer', evidence: 'Only 1/2 required reviewers approved', confidence: 0.6 }],
      comments: [{ author: 'seed-team@corp.io', body: 'Pending second reviewer.' }],
      attachments: [],
    },
    {
      key: 'SEED-1006',
      summary: 'Extend retention to 120 days',
      description: 'Increase seed retention window from 90 to 120 days in seed/config.json.',
      status: 'done',
      assignee: 'seed-team@corp.io',
      reporter: 'compliance@corp.io',
      prUrl: `https://bitbucket.corp.io/seed/seed-data/pull-requests/106`,
      prNumber: 106,
      prTitle: 'SEED-1006: extend retention to 120 days',
      sourceBranch: 'feature/SEED-1006',
      prAuthor: 'seed-team@corp.io',
      prState: 'merged',
      prReviewStatus: 'approved',
      prReviewers: 3,
      prRequiredReviewers: 2,
      prApproved: true,
      prMergeable: true,
      prCommits: [{ sha: 'f6a1b2c3d4e5', message: 'SEED-1006: extend retention to 120 days', author: 'seed-team@corp.io' }],
      prFilesChanged: [{ path: 'seed/config.json', additions: 1, deletions: 1 }],
      approvals: [{ source: 'jira_status', evidence: 'Jira status is "done"', confidence: 1 }],
      comments: [{ author: 'seed-team@corp.io', body: 'Already merged last release.' }],
      attachments: [],
    },
    {
      key: 'SEED-1007',
      summary: 'Remove departed Sales/HR employees',
      description: 'Mass deletion of E006, E007, E008 from seed/employees.json. HIGH RISK — destructive.',
      status: 'blocked',
      assignee: 'hr@corp.io',
      reporter: 'hr@corp.io',
      prUrl: `https://bitbucket.corp.io/seed/seed-data/pull-requests/107`,
      prNumber: 107,
      prTitle: 'SEED-1007: remove departed Sales/HR employees',
      sourceBranch: 'feature/SEED-1007',
      prAuthor: 'hr@corp.io',
      prState: 'open',
      prReviewStatus: 'changes_requested',
      prReviewers: 1,
      prRequiredReviewers: 2,
      prApproved: false,
      prMergeable: true,
      prCommits: [{ sha: 'a7b8c9d0e1f2', message: 'SEED-1007: remove departed Sales/HR employees', author: 'hr@corp.io' }],
      prFilesChanged: [{ path: 'seed/employees.json', additions: 0, deletions: 3 }],
      approvals: [],
      comments: [{ author: 'seed-team@corp.io', body: 'BLOCKED: requires HR sign-off attachment and explicit deletion approval.' }],
      attachments: [],
    },
  ];

  for (const s of seeds) {
    // Ticket
    const ticket = await db.jiraTicket.upsert({
      where: { key: s.key },
      update: {
        projectKey: 'SEED',
        summary: s.summary,
        description: s.description,
        status: s.status,
        assignee: s.assignee,
        reporter: s.reporter,
        approvalField: s.status === 'approved' || s.status === 'done' ? 'approved' : null,
        prUrl: s.prUrl,
      },
      create: {
        key: s.key,
        projectKey: 'SEED',
        summary: s.summary,
        description: s.description,
        status: s.status,
        assignee: s.assignee,
        reporter: s.reporter,
        approvalField: s.status === 'approved' || s.status === 'done' ? 'approved' : null,
        prUrl: s.prUrl,
      },
    });

    // Comments
    for (const c of s.comments) {
      const exists = await db.jiraComment.findFirst({ where: { ticketId: ticket.id, author: c.author, body: c.body } });
      if (!exists) await db.jiraComment.create({ data: { ticketId: ticket.id, author: c.author, body: c.body } });
    }
    // Attachments
    for (const a of s.attachments) {
      const exists = await db.jiraAttachment.findFirst({ where: { ticketId: ticket.id, filename: a.filename } });
      if (!exists)
        await db.jiraAttachment.create({
          data: { ticketId: ticket.id, filename: a.filename, mimeType: a.mimeType, size: a.size, content: a.content, isApproval: a.isApproval },
        });
    }
    // Approvals
    for (const ap of s.approvals) {
      const exists = await db.approvalEvidence.findFirst({ where: { ticketId: ticket.id, source: ap.source, evidence: ap.evidence } });
      if (!exists) await db.approvalEvidence.create({ data: { ticketId: ticket.id, source: ap.source, evidence: ap.evidence, confidence: ap.confidence } });
    }

    // PR
    await db.pullRequest.upsert({
      where: { jiraTicketId: ticket.id },
      update: {
        repositoryId: repo.id,
        prNumber: s.prNumber,
        title: s.prTitle,
        sourceBranch: s.sourceBranch,
        targetBranch: 'master',
        state: s.prState,
        description: s.description,
        author: s.prAuthor,
        reviewStatus: s.prReviewStatus,
        reviewers: s.prReviewers,
        requiredReviewers: s.prRequiredReviewers,
        approved: s.prApproved,
        mergeable: s.prMergeable,
        commits: s.prCommits,
        filesChanged: s.prFilesChanged,
      },
      create: {
        repositoryId: repo.id,
        prNumber: s.prNumber,
        title: s.prTitle,
        sourceBranch: s.sourceBranch,
        targetBranch: 'master',
        state: s.prState,
        description: s.description,
        author: s.prAuthor,
        reviewStatus: s.prReviewStatus,
        reviewers: s.prReviewers,
        requiredReviewers: s.prRequiredReviewers,
        approved: s.prApproved,
        mergeable: s.prMergeable,
        jiraTicketId: ticket.id,
        commits: s.prCommits,
        filesChanged: s.prFilesChanged,
      },
    });
  }

  // 4. Historical agent runs + releases + deployments for the dashboard
  const now = new Date();
  const historyRuns: Array<{
    runId: string;
    userRequest: string;
    mode: string;
    status: string;
    currentStep: string;
    summary: string;
    ageHours: number;
    releaseId: string;
    releaseStatus: string;
    deployedAt?: Date;
    jenkinsBuild: number;
    jenkinsStatus: string;
    totalTickets: number;
    approvedTickets: number;
  }> = [
    {
      runId: 'RUN-2026-09-09-A',
      userRequest: 'Process all approved seed changes for release 2026.09.09.',
      mode: 'release',
      status: 'completed',
      currentStep: 'generate_report',
      summary: 'Released 4 approved PRs, 1 conflict resolved semantically, deployment #8271 succeeded.',
      ageHours: 26,
      releaseId: 'REL-2026-09-09',
      releaseStatus: 'deployed',
      deployedAt: new Date(now.getTime() - 24 * 3600 * 1000),
      jenkinsBuild: 8271,
      jenkinsStatus: 'success',
      totalTickets: 5,
      approvedTickets: 4,
    },
    {
      runId: 'RUN-2026-09-09-B',
      userRequest: 'Why did the release fail?',
      mode: 'recover',
      status: 'completed',
      currentStep: 'generate_report',
      summary: 'Jenkins build #8270 failed: transient infra timeout. Retried and succeeded.',
      ageHours: 30,
      releaseId: 'REL-2026-09-09',
      releaseStatus: 'deployed',
      deployedAt: new Date(now.getTime() - 26 * 3600 * 1000),
      jenkinsBuild: 8270,
      jenkinsStatus: 'failed',
      totalTickets: 5,
      approvedTickets: 4,
    },
    {
      runId: 'RUN-2026-09-08-A',
      userRequest: 'Create a release plan for this week.',
      mode: 'plan',
      status: 'completed',
      currentStep: 'generate_report',
      summary: 'Plan: 6 approved PRs, 1 conflict expected on seed/employees.json.',
      ageHours: 50,
      releaseId: 'REL-2026-09-08',
      releaseStatus: 'deployed',
      deployedAt: new Date(now.getTime() - 48 * 3600 * 1000),
      jenkinsBuild: 8255,
      jenkinsStatus: 'success',
      totalTickets: 7,
      approvedTickets: 6,
    },
  ];

  for (const h of historyRuns) {
    const run = await db.agentRun.create({
      data: {
        runId: h.runId,
        userRequest: h.userRequest,
        mode: h.mode,
        status: h.status,
        currentStep: h.currentStep,
        summary: h.summary,
        createdAt: new Date(now.getTime() - h.ageHours * 3600 * 1000),
        startedAt: new Date(now.getTime() - h.ageHours * 3600 * 1000),
        finishedAt: new Date(now.getTime() - (h.ageHours - 1) * 3600 * 1000),
        warnings: [],
        errors: [],
        requestIntent: h.mode,
      },
    });
    const release = await db.release.upsert({
      where: { releaseId: h.releaseId },
      update: {},
      create: {
        releaseId: h.releaseId,
        runId: run.id,
        repositoryId: repo.id,
        targetBranch: 'master',
        releaseBranch: `release/${h.releaseId.toLowerCase()}`,
        status: h.releaseStatus,
        totalTickets: h.totalTickets,
        approvedTickets: h.approvedTickets,
        alreadyMerged: 1,
        toIntegrate: h.approvedTickets - 1,
        conflictsCount: h.mode === 'release' ? 1 : 0,
        recordsAdded: 4,
        recordsUpdated: 2,
        recordsDeleted: 0,
        riskLevel: 'low',
        planJson: {},
        createdAt: new Date(now.getTime() - h.ageHours * 3600 * 1000),
        updatedAt: new Date(now.getTime() - (h.ageHours - 1) * 3600 * 1000),
      },
    });
    await db.deployment.create({
      data: {
        deploymentId: `DEP-${h.jenkinsBuild}`,
        releaseId: release.id,
        jenkinsJob: 'seed-data-deploy',
        buildNumber: h.jenkinsBuild,
        branch: release.releaseBranch,
        parameters: { RELEASE_ID: h.releaseId, TARGET: 'prod' },
        status: h.jenkinsStatus,
        stage: h.jenkinsStatus === 'success' ? 'Deploy' : 'Build',
        consoleLog:
          h.jenkinsStatus === 'success'
            ? `[Build] seed-data-deploy #${h.jenkinsBuild} started\n[Validate] schema OK\n[Deploy] pushed to prod\n[Post] notified Jira\nSUCCESS`
            : `[Build] started\n[Fetch] timeout contacting git server\n[Validate] aborted\nFAILED: connection timeout`,
        failureAnalysis:
          h.jenkinsStatus === 'failed'
            ? {
                status: 'failed',
                likelyCause: 'Transient network timeout contacting git server during fetch stage.',
                evidence: ['[Fetch] timeout contacting git server', 'FAILED: connection timeout'],
                retryable: true,
                recommendedAction: 'retry_build',
                confidence: 0.82,
              }
            : undefined,
        retryCount: h.jenkinsStatus === 'failed' ? 1 : 0,
        startedAt: new Date(now.getTime() - (h.ageHours - 0.5) * 3600 * 1000),
        finishedAt: new Date(now.getTime() - (h.ageHours - 1) * 3600 * 1000),
        durationMs: 1800000,
      },
    });
  }

  console.log('Seed complete. Jira tickets, PRs, approvals, historical runs/releases/deployments created.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
