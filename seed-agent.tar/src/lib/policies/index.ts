// Policy engine — deterministic business policies that govern autonomy.
// Per spec sections 19, 31, 25, 32: deterministic rules always outrank LLM
// suggestions and external content.

import type {
  ApprovalDecision,
  ConflictRisk,
  ConflictStrategy,
  PolicyDecision,
  ToolRisk,
} from '../agent/types';

// ---------- Approval policy (spec section 10) ----------

export interface ApprovalPolicyConfig {
  requireJiraApprovedStatus: boolean;
  requireAttachmentApprovalForDestructive: boolean;
  requireMinReviewers: number;
  requireMergeable: boolean;
  blockOnPendingReview: boolean;
}

export const DEFAULT_APPROVAL_POLICY: ApprovalPolicyConfig = {
  requireJiraApprovedStatus: true,
  requireAttachmentApprovalForDestructive: true,
  requireMinReviewers: 2,
  requireMergeable: true,
  blockOnPendingReview: true,
};

export function evaluateApproval(opts: {
  jiraStatus: string;
  hasApprovalAttachment: boolean;
  reviewers: number;
  requiredReviewers: number;
  prApproved: boolean;
  prMergeable: boolean;
  isDestructive: boolean;
  policy?: ApprovalPolicyConfig;
}): ApprovalDecision {
  const p = opts.policy ?? DEFAULT_APPROVAL_POLICY;
  const evidence: ApprovalDecision['evidence'] = [];
  const blockers: string[] = [];

  if (p.requireJiraApprovedStatus) {
    const ok = opts.jiraStatus === 'approved' || opts.jiraStatus === 'done';
    evidence.push({
      source: 'jira_status',
      evidence: `Jira status is "${opts.jiraStatus}"`,
      confidence: ok ? 1 : 0,
    });
    if (!ok) blockers.push(`Jira status "${opts.jiraStatus}" is not approved/done`);
  }

  if (opts.isDestructive && p.requireAttachmentApprovalForDestructive) {
    evidence.push({
      source: 'jira_attachment',
      evidence: opts.hasApprovalAttachment
        ? 'Signed approval attachment present'
        : 'No signed approval attachment present (required for destructive changes)',
      confidence: opts.hasApprovalAttachment ? 0.95 : 0,
    });
    if (!opts.hasApprovalAttachment)
      blockers.push('Destructive changes require a signed approval attachment in Jira');
  }

  if (p.requireMinReviewers > 0) {
    const ok = opts.reviewers >= Math.max(p.requireMinReviewers, opts.requiredReviewers) && opts.prApproved;
    evidence.push({
      source: 'bitbucket_reviewer',
      evidence: `${opts.reviewers}/${Math.max(p.requireMinReviewers, opts.requiredReviewers)} reviewers approved`,
      confidence: ok ? 1 : 0.5,
    });
    if (!ok) blockers.push(`PR reviewer approval incomplete (${opts.reviewers}/${Math.max(p.requireMinReviewers, opts.requiredReviewers)})`);
  }

  if (p.requireMergeable) {
    evidence.push({
      source: 'bitbucket_pr_approval',
      evidence: opts.prMergeable ? 'PR is mergeable' : 'PR is not mergeable',
      confidence: opts.prMergeable ? 1 : 0,
    });
    if (!opts.prMergeable) blockers.push('PR is not mergeable');
  }

  if (p.blockOnPendingReview && opts.jiraStatus === 'in_review') {
    blockers.push('Jira ticket is still "in_review"');
  }

  const approved = blockers.length === 0;
  const confidence = approved
    ? 1
    : Math.max(0, 1 - blockers.length * 0.25);
  return { approved, confidence, evidence, blockers };
}

// ---------- Conflict safety policy (spec section 19) ----------

export interface ConflictPolicy {
  // Strategies the autonomous agent may apply without human approval.
  autonomousStrategies: ConflictStrategy[];
  // Risk levels that block autonomous execution.
  blockedRisks: ConflictRisk[];
}

export const DEFAULT_CONFLICT_POLICY: ConflictPolicy = {
  autonomousStrategies: ['semantic_merge', 'ours', 'theirs'],
  blockedRisks: ['high'],
};

export function evaluateConflictAutonomy(
  riskLevel: ConflictRisk,
  strategy: ConflictStrategy,
  confidence: number,
  policy: ConflictPolicy = DEFAULT_CONFLICT_POLICY,
): { allowed: boolean; reason: string } {
  if (policy.blockedRisks.includes(riskLevel)) {
    return { allowed: false, reason: `Risk level "${riskLevel}" blocks autonomous resolution per policy` };
  }
  if (!policy.autonomousStrategies.includes(strategy)) {
    return { allowed: false, reason: `Strategy "${strategy}" is not in the autonomous allowlist` };
  }
  if (confidence < 0.7) {
    return { allowed: false, reason: `Confidence ${confidence.toFixed(2)} below autonomous threshold 0.70` };
  }
  return { allowed: true, reason: 'Within autonomous policy envelope' };
}

// ---------- Tool permission policy (spec section 31) ----------

const DESTRUCTIVE_OPS = new Set([
  'git_push',
  'git_force_push',
  'merge_pull_request',
  'delete_branch',
  'trigger_jenkins',
  'abort_merge',
]);

const WRITE_OPS = new Set([
  'git_clone',
  'git_fetch',
  'git_checkout',
  'git_create_branch',
  'git_merge',
  'git_cherry_pick',
  'git_apply_patch',
  'git_commit',
  'resolve_conflict',
  'update_jira',
  'transition_jira',
]);

export function classifyToolRisk(tool: string): ToolRisk {
  if (DESTRUCTIVE_OPS.has(tool)) return 'destructive';
  if (WRITE_OPS.has(tool)) return 'write';
  return 'read';
}

export function evaluateActionPolicy(opts: {
  tool: string;
  mode: string; // observe | plan | execute | release | recover
  state: { status: string };
}): PolicyDecision {
  const risk = classifyToolRisk(opts.tool);
  // Observe mode → read-only
  if (opts.mode === 'observe' && risk !== 'read') {
    return { allowed: false, reason: 'observe mode permits read-only operations', risk };
  }
  // Plan mode → no write/destructive
  if (opts.mode === 'plan' && risk !== 'read') {
    return { allowed: false, reason: 'plan mode permits read-only operations', risk };
  }
  // Execute / release / recover → all allowed within policy
  return { allowed: true, reason: 'within mode policy', risk };
}

// ---------- Retry policy (spec section 25) ----------

export interface RetryPolicy {
  maxAttempts: number;
  baseDelayMs: number;
  maxDelayMs: number;
  jitterMs: number;
  retryableErrors: string[];
  nonRetryableErrors: string[];
}

export const DEFAULT_RETRY_POLICY: RetryPolicy = {
  maxAttempts: 3,
  baseDelayMs: 500,
  maxDelayMs: 5000,
  jitterMs: 250,
  retryableErrors: [
    'timeout',
    'rate_limit',
    'transient',
    'connection_reset',
    '5xx',
    'service_unavailable',
  ],
  nonRetryableErrors: [
    'invalid_seed_data',
    'schema_failure',
    'authorization_failure',
    'bad_credentials',
    'broken_code',
    'deterministic_build_failure',
    'git_conflict',
  ],
};

export function isRetryable(error: string, attempts: number, policy: RetryPolicy = DEFAULT_RETRY_POLICY): boolean {
  if (attempts >= policy.maxAttempts) return false;
  const lower = error.toLowerCase();
  if (policy.nonRetryableErrors.some((e) => lower.includes(e))) return false;
  if (policy.retryableErrors.some((e) => lower.includes(e))) return true;
  return false;
}

export function backoffDelay(attempts: number, policy: RetryPolicy = DEFAULT_RETRY_POLICY): number {
  const exp = Math.min(policy.maxDelayMs, policy.baseDelayMs * 2 ** attempts);
  const jitter = Math.floor(Math.random() * policy.jitterMs);
  return exp + jitter;
}
