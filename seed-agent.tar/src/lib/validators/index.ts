// Seed-data validation engine (spec sections 20, 21).
// Pluggable validators for JSON seed data — duplicate ids, referential
// integrity, required fields, schema sanity. No shell execution.

import type { ReleaseValidationReport, ValidationResult } from '../agent/types';
import type { SeedFile } from '../mock/git-workspace';

export type ValidatorFn = (file: SeedFile, allFiles: Record<string, SeedFile>) => ValidationResult[];

interface ValidatorRegistry {
  [name: string]: ValidatorFn;
}

const registry: ValidatorRegistry = {};

export function registerValidator(name: string, fn: ValidatorFn) {
  registry[name] = fn;
}

export function listValidators(): string[] {
  return Object.keys(registry);
}

// ---------- Built-in validators ----------

function asArray(v: unknown): { id?: string; [k: string]: unknown }[] {
  return Array.isArray(v) ? (v as { id?: string; [k: string]: unknown }[]) : [];
}

registerValidator('json_valid', (file): ValidationResult[] => {
  const results: ValidationResult[] = [];
  try {
    if (file.data === null || file.data === undefined) {
      results.push({ validator: 'json_valid', file: file.path, status: 'fail', message: 'Empty file content' });
    } else {
      JSON.stringify(file.data); // throws on cyclic
      results.push({ validator: 'json_valid', file: file.path, status: 'pass', message: 'Valid JSON' });
    }
  } catch (e) {
    results.push({ validator: 'json_valid', file: file.path, status: 'fail', message: `Invalid JSON: ${(e as Error).message}` });
  }
  return results;
});

registerValidator('duplicate_id', (file): ValidationResult[] => {
  const arr = asArray(file.data);
  if (!arr.length) return [];
  const ids = arr.map((r) => r?.id).filter((id): id is string => Boolean(id));
  const dupes = ids.filter((id, i) => ids.indexOf(id) !== i);
  const uniqueDupes = Array.from(new Set(dupes));
  if (uniqueDupes.length) {
    return [
      {
        validator: 'duplicate_id',
        file: file.path,
        status: 'fail',
        message: `Duplicate ids: ${uniqueDupes.join(', ')}`,
        details: { duplicates: uniqueDupes },
      },
    ];
  }
  return [{ validator: 'duplicate_id', file: file.path, status: 'pass', message: 'No duplicate ids' }];
});

registerValidator('required_fields_employees', (file): ValidationResult[] => {
  if (!file.path.includes('employees')) return []; // only run on employee files
  const arr = asArray(file.data);
  if (!arr.length) return [];
  const required = ['id', 'name', 'email', 'department', 'role', 'active'];
  const missing: { id?: string; fields: string[] }[] = [];
  for (const rec of arr) {
    const miss = required.filter((f) => rec?.[f] === undefined || rec?.[f] === null || rec?.[f] === '');
    if (miss.length) missing.push({ id: rec?.id as string | undefined, fields: miss });
  }
  if (missing.length) {
    return [
      {
        validator: 'required_fields_employees',
        file: file.path,
        status: 'fail',
        message: `${missing.length} record(s) missing required fields`,
        details: { missing },
      },
    ];
  }
  return [{ validator: 'required_fields_employees', file: file.path, status: 'pass', message: 'All required fields present' }];
});

registerValidator('referential_integrity_projects_owner', (file, allFiles): ValidationResult[] => {
  if (!file.path.startsWith('seed/projects.json')) return [];
  const employees = asArray(allFiles['seed/employees.json']?.data);
  const empIds = new Set(employees.map((e) => e.id));
  const projects = asArray(file.data);
  const broken: { project: string; owner: string }[] = [];
  for (const p of projects) {
    const owner = p?.owner as string | undefined;
    if (owner && !empIds.has(owner)) broken.push({ project: String(p?.id), owner });
  }
  if (broken.length) {
    return [
      {
        validator: 'referential_integrity_projects_owner',
        file: file.path,
        status: 'fail',
        message: `${broken.length} project(s) reference non-existent employees`,
        details: { broken },
      },
    ];
  }
  return [{ validator: 'referential_integrity_projects_owner', file: file.path, status: 'pass', message: 'All project owners exist' }];
});

registerValidator('no_mass_deletion', (file, allFiles): ValidationResult[] => {
  if (!file.path.includes('employees')) return [];
  // Heuristic: detect >30% reduction in any seed array vs config baseline.
  // For our purposes we compare against the master baseline (the snapshot before release).
  // allFiles includes the CURRENT release candidate files; we cannot see the baseline here.
  // We just verify each file has at least N records.
  const arr = asArray(file.data);
  if (!arr.length) return [];
  if (file.path.includes('employees') && arr.length < 3) {
    return [{ validator: 'no_mass_deletion', file: file.path, status: 'fail', message: `Suspiciously low employee count: ${arr.length}` }];
  }
  return [{ validator: 'no_mass_deletion', file: file.path, status: 'pass', message: `Record count healthy (${arr.length})` }];
});

registerValidator('email_format', (file): ValidationResult[] => {
  if (!file.path.includes('employees')) return [];
  const arr = asArray(file.data);
  if (!arr.length) return [];
  const bad: { id?: string; email: string }[] = [];
  for (const rec of arr) {
    const email = rec?.email as string | undefined;
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) bad.push({ id: rec?.id as string | undefined, email });
  }
  if (bad.length) {
    return [{ validator: 'email_format', file: file.path, status: 'fail', message: `${bad.length} record(s) with invalid email`, details: { bad } }];
  }
  return [{ validator: 'email_format', file: file.path, status: 'pass', message: 'All emails valid' }];
});

// ---------- Validation runner ----------

export interface ValidateOpts {
  // When provided, compare release candidate files against the baseline (master)
  // to compute recordsAdded / recordsUpdated / recordsDeleted per file.
  baseline?: Record<string, SeedFile>;
  candidate?: Record<string, SeedFile>;
  files?: Record<string, SeedFile>; // shorthand: if both omitted, validate this directly
}

export function runValidation(opts: ValidateOpts): ReleaseValidationReport {
  const baseline = opts.baseline || {};
  const candidate = opts.candidate || opts.files || {};
  const results: ValidationResult[] = [];
  const warnings: string[] = [];
  const errors: string[] = [];

  let filesChanged = 0;
  let recordsAdded = 0;
  let recordsUpdated = 0;
  let recordsDeleted = 0;

  for (const [path, file] of Object.entries(candidate)) {
    const base = baseline[path];
    if (!base || JSON.stringify(base.data) !== JSON.stringify(file.data)) filesChanged++;
    const arr = asArray(file.data);
    const baseArr = asArray(base?.data);
    if (arr.length && baseArr.length) {
      const baseIds = new Set(baseArr.map((r) => r.id));
      const candIds = new Set(arr.map((r) => r.id));
      for (const id of candIds) if (!baseIds.has(id)) recordsAdded++;
      for (const id of baseIds) if (!candIds.has(id)) recordsDeleted++;
      for (const rec of arr) {
        if (!rec?.id) continue;
        const prev = baseArr.find((r) => r.id === rec.id);
        if (prev && JSON.stringify(prev) !== JSON.stringify(rec)) recordsUpdated++;
      }
    } else if (arr.length && !baseArr.length) {
      recordsAdded += arr.length;
    }

    // Run all registered validators
    for (const [name, fn] of Object.entries(registry)) {
      try {
        const out = fn(file, candidate);
        for (const r of out) {
          results.push(r);
          if (r.status === 'fail') errors.push(`[${name}] ${r.file || ''}: ${r.message}`);
          if (r.status === 'warning') warnings.push(`[${name}] ${r.file || ''}: ${r.message}`);
        }
      } catch (e) {
        results.push({ validator: name, file: path, status: 'fail', message: `Validator threw: ${(e as Error).message}` });
        errors.push(`[${name}] ${path}: validator threw ${(e as Error).message}`);
      }
    }
  }

  const hasErrors = errors.length > 0;
  const riskLevel: 'low' | 'medium' | 'high' =
    recordsDeleted >= 3 ? 'high' : recordsDeleted >= 1 || recordsUpdated >= 5 ? 'medium' : 'low';

  return {
    filesChanged,
    recordsAdded,
    recordsUpdated,
    recordsDeleted,
    results,
    warnings,
    errors,
    riskLevel,
    passed: !hasErrors && riskLevel !== 'high',
  };
}
