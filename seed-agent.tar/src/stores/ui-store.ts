'use client';

import { create } from 'zustand';

export type ViewKey =
  | 'dashboard'
  | 'agent'
  | 'releases'
  | 'conflicts'
  | 'deployments'
  | 'jira'
  | 'prs'
  | 'audit';

interface UIState {
  view: ViewKey;
  setView: (v: ViewKey) => void;
  activeRunId: string | null;
  setActiveRunId: (id: string | null) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

export const useUIStore = create<UIState>((set) => ({
  view: 'dashboard',
  setView: (v) => set({ view: v }),
  activeRunId: null,
  setActiveRunId: (id) => set({ activeRunId: id }),
  sidebarOpen: false,
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
}));
