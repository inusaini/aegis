// GET /api/releases/:release_id — full release detail with plan, items, conflicts, deployment

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(_req: NextRequest, ctx: { params: Promise<{ release_id: string }> }) {
  const { release_id } = await ctx.params;
  const release = await db.release.findFirst({
    where: { OR: [{ id: release_id }, { releaseId: release_id }] },
    include: {
      repository: true,
      deployments: true,
      items: { include: { jiraTicket: true, pullRequest: true } },
      run: true,
    },
  });
  if (!release) return NextResponse.json({ error: 'release not found' }, { status: 404 });
  return NextResponse.json({ release });
}
