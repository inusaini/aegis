// GET /api/releases — list releases
// POST /api/releases/plan — start a plan-mode run

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { startRun } from '@/lib/agent/orchestrator';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  const releases = await db.release.findMany({
    orderBy: { createdAt: 'desc' },
    take: 50,
    include: { repository: true, deployments: true, items: { include: { jiraTicket: true, pullRequest: true } } },
  });
  return NextResponse.json({ releases });
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const userRequest: string = body.userRequest || 'Create a release plan for this week\'s approved changes.';
  const runId = await startRun(userRequest, 'plan');
  return NextResponse.json({ runId, status: 'running', mode: 'plan' }, { status: 202 });
}
