// POST /api/releases/plan — alias of POST /api/releases (plan-mode run)

import { NextRequest, NextResponse } from 'next/server';
import { startRun } from '@/lib/agent/orchestrator';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const userRequest: string = body.userRequest || 'Create a release plan for this week\'s approved changes.';
  const runId = await startRun(userRequest, 'plan');
  return NextResponse.json({ runId, status: 'running', mode: 'plan' }, { status: 202 });
}
