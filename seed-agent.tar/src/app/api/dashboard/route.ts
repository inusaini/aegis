// GET /api/dashboard — aggregated metrics for the operations dashboard.

import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getLiveRun } from '@/lib/agent/orchestrator';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  const [tickets, prs, recentRuns, recentReleases, recentDeployments, recentConflicts, recentAudit] = await Promise.all([
    db.jiraTicket.findMany({ include: { pullRequest: true } }),
    db.pullRequest.findMany({ include: { jiraTicket: true } }),
    db.agentRun.findMany({ orderBy: { createdAt: 'desc' }, take: 8, include: { releases: { take: 1 } } }),
    db.release.findMany({ orderBy: { createdAt: 'desc' }, take: 10, include: { deployments: true } }),
    db.deployment.findMany({ orderBy: { createdAt: 'desc' }, take: 8, include: { release: true } }),
    db.conflict.findMany({ orderBy: { createdAt: 'desc' }, take: 10, include: { resolution: true } }),
    db.auditLog.findMany({ orderBy: { createdAt: 'desc' }, take: 20 }),
  ]);

  // Live runs (in-progress)
  const liveRunIds: string[] = [];
  // we don't have direct access; emulate via recent runs that are status 'running'
  const running = recentRuns.filter((r) => r.status === 'running');
  for (const r of running) {
    const live = getLiveRun(r.runId);
    if (live) liveRunIds.push(r.runId);
  }

  const approvedTickets = tickets.filter((t) => t.status === 'approved' || t.status === 'done').length;
  const pendingTickets = tickets.filter((t) => t.status === 'open' || t.status === 'in_review').length;
  const blockedTickets = tickets.filter((t) => t.status === 'blocked').length;
  const approvedPRs = prs.filter((p) => p.approved).length;
  const blockedPRs = prs.filter((p) => p.state === 'open' && !p.approved).length;
  const activeConflicts = recentConflicts.filter((c) => c.status === 'analyzing' || c.status === 'detected').length;
  const resolvedConflicts = recentConflicts.filter((c) => c.status === 'resolved').length;
  const blockedConflicts = recentConflicts.filter((c) => c.status === 'blocked').length;
  const recentFailures = recentDeployments.filter((d) => d.status === 'failed').length;
  const successfulReleases = recentReleases.filter((r) => r.status === 'deployed').length;

  return NextResponse.json({
    metrics: {
      activeRuns: running.length,
      approvedTickets,
      pendingTickets,
      blockedTickets,
      approvedPRs,
      blockedPRs,
      activeConflicts,
      resolvedConflicts,
      blockedConflicts,
      recentFailures,
      successfulReleases,
      totalReleases: recentReleases.length,
      totalTickets: tickets.length,
      totalPRs: prs.length,
    },
    recentRuns,
    recentReleases,
    recentDeployments,
    recentConflicts,
    recentAudit,
    liveRunIds,
  });
}
