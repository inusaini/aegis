// GET /api/deployments — list deployments
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  const deployments = await db.deployment.findMany({
    orderBy: { createdAt: 'desc' },
    include: { release: true },
  });
  return NextResponse.json({ deployments });
}
