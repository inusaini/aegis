// GET /api/deployments/:id — deployment detail with console log + AI analysis
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const deployment = await db.deployment.findFirst({
    where: { OR: [{ id }, { deploymentId: id }] },
    include: { release: true },
  });
  if (!deployment) return NextResponse.json({ error: 'deployment not found' }, { status: 404 });
  return NextResponse.json({ deployment });
}
