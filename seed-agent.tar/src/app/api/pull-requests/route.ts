// GET /api/pull-requests — list PRs with correlated Jira ticket

import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  const prs = await db.pullRequest.findMany({
    orderBy: { createdAt: 'desc' },
    include: { jiraTicket: true, repository: true, mergeResults: true },
  });
  return NextResponse.json({ pullRequests: prs });
}
