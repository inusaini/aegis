// GET /api/audit — list audit log entries
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const limit = Math.min(200, Number(url.searchParams.get('limit') || '100'));
  const runId = url.searchParams.get('runId');
  const where = runId ? { run: { runId } } : {};
  const logs = await db.auditLog.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: limit,
    include: { run: true, pullRequest: true, ticket: true },
  });
  return NextResponse.json({ logs });
}
