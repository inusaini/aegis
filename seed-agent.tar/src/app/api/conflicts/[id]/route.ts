// GET /api/conflicts/:id — conflict detail with base/ours/theirs/resolution
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const conflict = await db.conflict.findFirst({
    where: { OR: [{ id }, { conflictId: id }] },
    include: { resolution: true, pullRequest: { include: { jiraTicket: true } } },
  });
  if (!conflict) return NextResponse.json({ error: 'conflict not found' }, { status: 404 });
  return NextResponse.json({ conflict });
}
