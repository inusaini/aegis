// GET /api/conflicts — list all conflicts
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  const conflicts = await db.conflict.findMany({
    orderBy: { createdAt: 'desc' },
    include: { resolution: true, pullRequest: { include: { jiraTicket: true } } },
  });
  return NextResponse.json({ conflicts });
}
