// GET /api/jira/issues — list Jira tickets with PR + approvals

import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  const tickets = await db.jiraTicket.findMany({
    orderBy: { createdAt: 'desc' },
    include: {
      pullRequest: true,
      comments: true,
      attachments: true,
      approvals: true,
    },
  });
  return NextResponse.json({ tickets });
}
