// POST /api/agent/runs — start a new agent run (spec section 51).
// GET  /api/agent/runs — list all agent runs.

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { startRun } from '@/lib/agent/orchestrator';
import type { AgentMode } from '@/lib/agent/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const userRequest: string = body.userRequest || body.request || '';
  const mode: AgentMode = (body.mode as AgentMode) || 'execute';
  if (!userRequest) {
    return NextResponse.json({ error: 'userRequest is required' }, { status: 400 });
  }
  if (!['observe', 'plan', 'execute', 'release', 'recover'].includes(mode)) {
    return NextResponse.json({ error: 'invalid mode' }, { status: 400 });
  }
  const runId = await startRun(userRequest, mode);
  return NextResponse.json({ runId, status: 'running' }, { status: 202 });
}

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const limit = Math.min(50, Number(url.searchParams.get('limit') || '50'));
  const runs = await db.agentRun.findMany({
    orderBy: { createdAt: 'desc' },
    take: limit,
    include: { _count: { select: { events: true, agentActions: true, workflowStates: true } } },
  });
  return NextResponse.json({
    runs: runs.map((r) => ({
      runId: r.runId,
      id: r.id,
      userRequest: r.userRequest,
      mode: r.mode,
      status: r.status,
      currentStep: r.currentStep,
      requestIntent: r.requestIntent,
      retryCount: r.retryCount,
      warnings: r.warnings,
      errors: r.errors,
      summary: r.summary,
      createdAt: r.createdAt,
      finishedAt: r.finishedAt,
      counts: (r as { _count?: { events?: number; agentActions?: number; workflowStates?: number } })._count,
    })),
  });
}
