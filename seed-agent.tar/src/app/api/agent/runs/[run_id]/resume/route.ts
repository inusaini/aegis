// POST /api/agent/runs/:run_id/resume — resume a blocked/failed run (spec section 37).

import { NextRequest, NextResponse } from 'next/server';
import { resumeRun } from '@/lib/agent/orchestrator';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(_req: NextRequest, ctx: { params: Promise<{ run_id: string }> }) {
  const { run_id } = await ctx.params;
  const ok = await resumeRun(run_id);
  if (!ok) return NextResponse.json({ error: 'run not resumable' }, { status: 409 });
  return NextResponse.json({ runId: run_id, status: 'running' });
}
