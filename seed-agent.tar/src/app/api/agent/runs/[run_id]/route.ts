// GET /api/agent/runs/:run_id — full run state for the agent workspace UI.

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getLiveRun } from '@/lib/agent/orchestrator';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(_req: NextRequest, ctx: { params: Promise<{ run_id: string }> }) {
  const { run_id } = await ctx.params;
  const live = getLiveRun(run_id);
  const dbRun = await db.agentRun.findFirst({
    where: { runId: run_id },
    include: {
      workflowStates: { orderBy: { createdAt: 'desc' }, take: 50 },
      agentActions: { orderBy: { createdAt: 'desc' }, take: 50 },
      events: { orderBy: { timestamp: 'desc' }, take: 100 },
      releases: { take: 1 },
    },
  });
  if (!dbRun) return NextResponse.json({ error: 'run not found' }, { status: 404 });

  return NextResponse.json({
    run: {
      id: dbRun.id,
      runId: dbRun.runId,
      userRequest: dbRun.userRequest,
      mode: dbRun.mode,
      status: dbRun.status,
      currentStep: dbRun.currentStep,
      requestIntent: dbRun.requestIntent,
      retryCount: dbRun.retryCount,
      warnings: dbRun.warnings,
      errors: dbRun.errors,
      summary: dbRun.summary,
      createdAt: dbRun.createdAt,
      startedAt: dbRun.startedAt,
      finishedAt: dbRun.finishedAt,
    },
    liveState: live ? {
      workflowId: live.state.workflowId,
      mode: live.state.mode,
      currentStep: live.state.currentStep,
      status: live.state.status,
      jiraTickets: live.state.jiraTickets.length,
      pullRequests: live.state.pullRequests.length,
      correlations: Object.keys(live.state.correlations).length,
      approvedTickets: Object.values(live.state.approvalEvidence).filter((a) => a.approved).length,
      conflicts: live.state.conflicts,
      conflictResolutions: live.state.conflictResolutions,
      releasePlan: live.state.releasePlan,
      validationReport: live.state.validationReport,
      mergeResults: live.state.mergeResults,
      deployment: live.state.deployment,
      warnings: live.state.warnings,
      errors: live.state.errors,
    } : null,
    workflowStates: dbRun.workflowStates,
    agentActions: dbRun.agentActions,
    events: dbRun.events,
    releases: dbRun.releases,
  });
}
