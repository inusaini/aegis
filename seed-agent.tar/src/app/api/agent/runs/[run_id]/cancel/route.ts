// POST /api/agent/runs/:run_id/cancel — request cancellation.

import { NextRequest, NextResponse } from 'next/server';
import { cancelRun } from '@/lib/agent/orchestrator';
import { db } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(_req: NextRequest, ctx: { params: Promise<{ run_id: string }> }) {
  const { run_id } = await ctx.params;
  const ok = await cancelRun(run_id);
  // Also mark as cancelled in DB
  await db.agentRun.updateMany({ where: { runId: run_id }, data: { status: 'cancelled', finishedAt: new Date() } });
  if (!ok) return NextResponse.json({ error: 'run not found' }, { status: 404 });
  return NextResponse.json({ runId: run_id, status: 'cancelled' });
}
