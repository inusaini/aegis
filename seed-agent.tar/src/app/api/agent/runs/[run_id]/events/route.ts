// GET /api/agent/runs/:run_id/events — Server-Sent Events stream
// (spec section 51: "Live updates / Prefer SSE").

import { NextRequest } from 'next/server';
import { subscribe, getLiveRun } from '@/lib/agent/orchestrator';
import { db } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest, ctx: { params: Promise<{ run_id: string }> }) {
  const { run_id } = await ctx.params;

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      // First, replay the last 100 persisted events (so UI catches up after reconnect)
      const persisted = await db.agentEvent.findMany({
        where: { runId: { equals: (await db.agentRun.findFirst({ where: { runId: run_id } }))?.id } },
        orderBy: { timestamp: 'asc' },
        take: 100,
      });
      for (const ev of persisted) {
        controller.enqueue(encoder.encode(`event: ${ev.event}\ndata: ${JSON.stringify({ ...ev.payload, workflowId: run_id, timestamp: ev.timestamp })}\n\n`));
      }

      // Subscribe to live events
      const live = getLiveRun(run_id);
      if (live) {
        controller.enqueue(encoder.encode(`event: hello\ndata: ${JSON.stringify({ workflowId: run_id, status: live.state.status, step: live.state.currentStep })}\n\n`));
      }

      const unsubscribe = subscribe(run_id, (ev) => {
        try {
          controller.enqueue(encoder.encode(`event: ${ev.event}\ndata: ${JSON.stringify(ev)}\n\n`));
        } catch {
          // ignore
        }
      });

      // Heartbeat
      const heartbeat = setInterval(() => {
        try {
          controller.enqueue(encoder.encode(`: ping\n\n`));
        } catch {
          // ignore
        }
      }, 15000);

      // Clean up on abort
      req.signal.addEventListener('abort', () => {
        unsubscribe();
        clearInterval(heartbeat);
        try { controller.close(); } catch { /* ignore */ }
      });
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    },
  });
}
