'use client';

import { AppShell } from '@/components/layout/app-shell';
import { useUIStore } from '@/stores/ui-store';
import { DashboardView } from '@/components/dashboard/dashboard-view';
import { AgentWorkspaceView } from '@/components/agent-workspace/agent-workspace-view';
import { ReleasesView } from '@/components/releases/releases-view';
import { ConflictsView } from '@/components/conflicts/conflicts-view';
import { DeploymentsView } from '@/components/deployments/deployments-view';
import { JiraView } from '@/components/jira/jira-view';
import { PullRequestsView } from '@/components/pull-requests/prs-view';
import { AuditView } from '@/components/audit/audit-view';

export default function Home() {
  const view = useUIStore((s) => s.view);
  return (
    <AppShell>
      {view === 'dashboard' && <DashboardView />}
      {view === 'agent' && <AgentWorkspaceView />}
      {view === 'releases' && <ReleasesView />}
      {view === 'conflicts' && <ConflictsView />}
      {view === 'deployments' && <DeploymentsView />}
      {view === 'jira' && <JiraView />}
      {view === 'prs' && <PullRequestsView />}
      {view === 'audit' && <AuditView />}
    </AppShell>
  );
}
