'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { StatusPill, RiskBadge } from '@/components/common/status-pill';
import { JsonViewer } from '@/components/common/json-viewer';
import { Progress } from '@/components/ui/progress';
import { GitBranch, ChevronRight } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export function ConflictsView() {
  const [selected, setSelected] = useState<string | null>(null);
  const { data, isLoading } = useQuery({ queryKey: ['conflicts'], queryFn: api.listConflicts, refetchInterval: 10000 });

  return (
    <div className="space-y-4 p-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Conflicts</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">Git merge / cherry-pick conflicts with AI-driven semantic resolution.</p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <GitBranch className="h-4 w-4 text-brand-600" /> All conflicts
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading || !data ? (
            <Skeleton className="h-48" />
          ) : data.conflicts.length === 0 ? (
            <p className="py-6 text-center text-sm text-slate-500">No conflicts recorded yet. Start a release to see how the agent detects and resolves conflicts.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Conflict</TableHead>
                  <TableHead>File</TableHead>
                  <TableHead>PR</TableHead>
                  <TableHead>Ticket</TableHead>
                  <TableHead>Risk</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>When</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.conflicts.map((c) => (
                  <TableRow key={c.id} className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-900" onClick={() => setSelected(c.id)}>
                    <TableCell className="font-mono text-xs">{c.conflictId}</TableCell>
                    <TableCell className="font-mono text-xs">{c.file}</TableCell>
                    <TableCell className="font-mono text-xs">PR-{c.pullRequest?.prNumber ?? '-'}</TableCell>
                    <TableCell className="text-xs">{c.pullRequest?.jiraTicket?.key ?? '-'}</TableCell>
                    <TableCell><RiskBadge level={c.riskLevel} /></TableCell>
                    <TableCell><StatusPill status={c.status} /></TableCell>
                    <TableCell className="text-xs text-slate-500">{formatDistanceToNow(new Date(c.createdAt), { addSuffix: true })}</TableCell>
                    <TableCell><ChevronRight className="h-3 w-3 text-slate-400" /></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-5xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Conflict detail</DialogTitle>
          </DialogHeader>
          {selected && <ConflictDetail id={selected} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ConflictDetail({ id }: { id: string }) {
  const { data, isLoading } = useQuery({ queryKey: ['conflict', id], queryFn: () => api.getConflict(id) });
  if (isLoading || !data) return <Skeleton className="h-96" />;
  const c = data.conflict;
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <span className="font-mono text-sm">{c.conflictId}</span>
        <RiskBadge level={c.riskLevel} />
        <StatusPill status={c.status} />
        <span className="font-mono text-xs text-slate-500">{c.file}</span>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Pane label="BASE" data={c.base} />
        <Pane label="OURS" data={c.ours} />
        <Pane label="THEIRS" data={c.theirs} />
        <Pane label="PROPOSED / FINAL" data={c.resolution?.final ?? c.resolution?.proposed ?? null} highlight />
      </div>

      {c.resolution && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Resolution</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-xs">
            <div className="flex items-center gap-3">
              <span>strategy: <span className="font-mono">{c.resolution.strategy}</span></span>
              <span>risk: <RiskBadge level={c.resolution.riskLevel} /></span>
              <span>validation: {c.resolution.validationPassed ? '✓ passed' : '✗ failed'}</span>
            </div>
            <div>
              <div className="mb-1 flex items-center justify-between">
                <span className="text-slate-500">confidence</span>
                <span className="font-mono">{(c.resolution.confidence * 100).toFixed(0)}%</span>
              </div>
              <Progress value={c.resolution.confidence * 100} className="h-1.5" />
            </div>
            {c.resolution.reasoning && (
              <div>
                <div className="text-slate-500">reasoning</div>
                <div className="rounded-md bg-slate-50 p-2 dark:bg-slate-900/40">{c.resolution.reasoning}</div>
              </div>
            )}
            {c.resolution.evidence.length > 0 && (
              <div>
                <div className="text-slate-500">evidence</div>
                <ul className="list-inside list-disc text-slate-600 dark:text-slate-300">
                  {c.resolution.evidence.map((e, i) => <li key={i}>{e}</li>)}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function Pane({ label, data, highlight = false }: { label: string; data: unknown; highlight?: boolean }) {
  return (
    <div className={`rounded-md border p-2 ${highlight ? 'border-brand-300 bg-brand-50/40 dark:border-brand-800 dark:bg-brand-950/20' : 'border-slate-200 dark:border-slate-800'}`}>
      <div className={`mb-1 text-xs font-medium ${highlight ? 'text-brand-700 dark:text-brand-300' : 'text-slate-600 dark:text-slate-300'}`}>{label}</div>
      <JsonViewer data={data} className="text-[11px]" />
    </div>
  );
}

