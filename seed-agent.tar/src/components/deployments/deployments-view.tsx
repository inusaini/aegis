'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { StatusPill } from '@/components/common/status-pill';
import { Server, ChevronRight } from 'lucide-react';
import { formatDistanceToNow, format } from 'date-fns';

export function DeploymentsView() {
  const [selected, setSelected] = useState<string | null>(null);
  const { data, isLoading } = useQuery({ queryKey: ['deployments'], queryFn: api.listDeployments, refetchInterval: 10000 });

  return (
    <div className="space-y-4 p-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Deployments</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">Jenkins deployments triggered by the agent, with AI failure analysis.</p>
      </div>
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Server className="h-4 w-4 text-brand-600" /> Jenkins deployments
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading || !data ? (
            <Skeleton className="h-48" />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Deployment</TableHead>
                  <TableHead>Job</TableHead>
                  <TableHead>Build</TableHead>
                  <TableHead>Branch</TableHead>
                  <TableHead>Stage</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Retries</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>When</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.deployments.map((d) => (
                  <TableRow key={d.id} className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-900" onClick={() => setSelected(d.id)}>
                    <TableCell className="font-mono text-xs">{d.deploymentId}</TableCell>
                    <TableCell className="font-mono text-xs">{d.jenkinsJob}</TableCell>
                    <TableCell className="font-mono text-xs">#{d.buildNumber ?? '-'}</TableCell>
                    <TableCell className="font-mono text-xs">{d.branch ?? '-'}</TableCell>
                    <TableCell className="text-xs">{d.stage ?? '-'}</TableCell>
                    <TableCell><StatusPill status={d.status} /></TableCell>
                    <TableCell className="text-xs">{d.retryCount}</TableCell>
                    <TableCell className="text-xs">{d.durationMs ? `${(d.durationMs / 1000).toFixed(0)}s` : '-'}</TableCell>
                    <TableCell className="text-xs text-slate-500">{formatDistanceToNow(new Date(d.createdAt), { addSuffix: true })}</TableCell>
                    <TableCell><ChevronRight className="h-3 w-3 text-slate-400" /></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-3xl overflow-y-auto">
          <DialogHeader><DialogTitle>Deployment detail</DialogTitle></DialogHeader>
          {selected && <DeploymentDetail id={selected} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function DeploymentDetail({ id }: { id: string }) {
  const { data, isLoading } = useQuery({ queryKey: ['deployment', id], queryFn: () => api.getDeployment(id) });
  if (isLoading || !data) return <Skeleton className="h-96" />;
  const d = data.deployment;
  return (
    <div className="space-y-3 text-sm">
      <div className="flex items-center gap-2">
        <span className="font-mono">{d.deploymentId}</span>
        <span className="font-mono text-slate-500">{d.jenkinsJob} #{d.buildNumber ?? '-'}</span>
        <StatusPill status={d.status} />
      </div>
      <div className="grid grid-cols-2 gap-2 text-xs">
        <Field label="Branch" value={d.branch ?? '-'} />
        <Field label="Stage" value={d.stage ?? '-'} />
        <Field label="Retries" value={d.retryCount} />
        <Field label="Duration" value={d.durationMs ? `${(d.durationMs / 1000).toFixed(0)}s` : '-'} />
        <Field label="Started" value={d.startedAt ? format(new Date(d.startedAt), "yyyy-MM-dd HH:mm:ss") : '-'} />
        <Field label="Finished" value={d.finishedAt ? format(new Date(d.finishedAt), "yyyy-MM-dd HH:mm:ss") : '-'} />
      </div>
      <div>
        <div className="text-xs font-medium">Parameters</div>
        <pre className="mt-1 overflow-auto rounded-md bg-slate-50 p-2 font-mono text-xs dark:bg-slate-900/40">{JSON.stringify(d.parameters, null, 2)}</pre>
      </div>
      {d.failureAnalysis && (
        <div className="rounded-md border border-rose-200 bg-rose-50 p-3 dark:border-rose-800 dark:bg-rose-950/30">
          <div className="text-xs font-medium text-rose-700 dark:text-rose-300">AI Failure Analysis</div>
          <div className="mt-1 text-rose-700 dark:text-rose-200">{d.failureAnalysis.likelyCause}</div>
          <div className="mt-1 text-xs">retryable: <span className={d.failureAnalysis.retryable ? 'text-brand-600' : 'text-rose-600'}>{d.failureAnalysis.retryable ? 'yes' : 'no'}</span> · recommended: <span className="font-mono">{d.failureAnalysis.recommendedAction}</span> · confidence {(d.failureAnalysis.confidence * 100).toFixed(0)}%</div>
          {d.failureAnalysis.evidence.length > 0 && (
            <ul className="mt-1 list-inside list-disc text-xs text-rose-700 dark:text-rose-200">
              {d.failureAnalysis.evidence.map((e, i) => <li key={i}>{e}</li>)}
            </ul>
          )}
        </div>
      )}
      {d.consoleLog && (
        <div>
          <div className="text-xs font-medium">Console log</div>
          <pre className="mt-1 max-h-80 overflow-auto rounded-md bg-slate-900 p-3 font-mono text-[11px] leading-relaxed text-slate-100">{d.consoleLog}</pre>
        </div>
      )}
    </div>
  );
}

function Field({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-md border border-slate-200 p-2 dark:border-slate-800">
      <div className="text-[10px] uppercase tracking-wide text-slate-400">{label}</div>
      <div className="font-mono text-xs">{value}</div>
    </div>
  );
}

