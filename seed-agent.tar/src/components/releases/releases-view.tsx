'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api, type ReleaseSummary, type Deployment } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Skeleton } from '@/components/ui/skeleton';
import { StatusPill, RiskBadge } from '@/components/common/status-pill';
import { JsonViewer } from '@/components/common/json-viewer';
import { format, formatDistanceToNow } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Boxes, ChevronRight } from 'lucide-react';
import { useUIStore } from '@/stores/ui-store';
import { toast } from 'sonner';
import { Input } from '@/components/ui/input';

export function ReleasesView() {
  const setView = useUIStore((s) => s.setView);
  const [selected, setSelected] = useState<string | null>(null);
  const { data, isLoading } = useQuery({ queryKey: ['releases'], queryFn: api.listReleases, refetchInterval: 10000 });
  const [planPrompt, setPlanPrompt] = useState("Create a release plan for this week's approved changes.");

  const startPlan = async () => {
    try {
      const r = await api.planRelease(planPrompt);
      toast.success(`Started plan run ${r.runId}`);
      useUIStore.getState().setActiveRunId(r.runId);
      setView('agent');
    } catch (e) {
      toast.error((e as Error).message);
    }
  };

  return (
    <div className="space-y-4 p-6">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-semibold tracking-tight">Releases</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">All seed-data releases and their integration outcomes.</p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Boxes className="h-4 w-4 text-brand-600" /> Plan a new release
          </CardTitle>
        </CardHeader>
        <CardContent className="flex gap-2">
          <Input value={planPrompt} onChange={(e) => setPlanPrompt(e.target.value)} />
          <Button onClick={startPlan}>Plan</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">All releases</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading || !data ? (
            <Skeleton className="h-64" />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Release</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Branch</TableHead>
                  <TableHead>Approved</TableHead>
                  <TableHead>Integrated</TableHead>
                  <TableHead>Conflicts</TableHead>
                  <TableHead>Records</TableHead>
                  <TableHead>Risk</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.releases.map((r) => (
                  <TableRow key={r.id} className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-900" onClick={() => setSelected(r.id)}>
                    <TableCell className="font-mono text-xs">{r.releaseId}</TableCell>
                    <TableCell><StatusPill status={r.status} /></TableCell>
                    <TableCell className="font-mono text-xs">{r.targetBranch}</TableCell>
                    <TableCell className="text-xs">{r.approvedTickets} / {r.totalTickets}</TableCell>
                    <TableCell className="text-xs">{r.alreadyMerged}</TableCell>
                    <TableCell className="text-xs">{r.conflictsCount}</TableCell>
                    <TableCell className="text-xs">+{r.recordsAdded} ~{r.recordsUpdated} -{r.recordsDeleted}</TableCell>
                    <TableCell><RiskBadge level={r.riskLevel} /></TableCell>
                    <TableCell className="text-xs text-slate-500">{formatDistanceToNow(new Date(r.createdAt), { addSuffix: true })}</TableCell>
                    <TableCell><ChevronRight className="h-3 w-3 text-slate-400" /></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Sheet open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <SheetContent side="right" className="w-full max-w-2xl overflow-y-auto sm:max-w-xl">
          <SheetHeader>
            <SheetTitle>Release detail</SheetTitle>
          </SheetHeader>
          {selected && <ReleaseDetail id={selected} />}
        </SheetContent>
      </Sheet>
    </div>
  );
}

function ReleaseDetail({ id }: { id: string }) {
  const { data, isLoading } = useQuery({ queryKey: ['release', id], queryFn: () => api.getRelease(id) });
  if (isLoading || !data) return <div className="p-4"><Skeleton className="h-64" /></div>;
  const r = data.release;
  return (
    <div className="space-y-4 px-4 pb-6">
      <div className="space-y-1">
        <div className="font-mono text-sm">{r.releaseId}</div>
        <div className="flex items-center gap-2">
          <StatusPill status={r.status} />
          <RiskBadge level={r.riskLevel} />
        </div>
        <div className="text-xs text-slate-500">
          target: {r.targetBranch} · branch: {r.releaseBranch || '-'} · created {format(new Date(r.createdAt), "yyyy-MM-dd HH:mm")}
        </div>
      </div>

      <div className="grid grid-cols-4 gap-2 text-xs">
        <Stat label="Tickets" value={`${r.approvedTickets}/${r.totalTickets}`} />
        <Stat label="Already merged" value={r.alreadyMerged} />
        <Stat label="To integrate" value={r.toIntegrate} />
        <Stat label="Conflicts" value={r.conflictsCount} />
        <Stat label="Added" value={`+${r.recordsAdded}`} tone="brand" />
        <Stat label="Updated" value={`~${r.recordsUpdated}`} tone="amber" />
        <Stat label="Deleted" value={`-${r.recordsDeleted}`} tone="rose" />
      </div>

      {r.items && r.items.length > 0 && (
        <div>
          <div className="mb-1 text-xs font-medium">Release plan items</div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>PR</TableHead>
                <TableHead>Ticket</TableHead>
                <TableHead>Strategy</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Reason</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {r.items.map((it) => (
                <TableRow key={it.id}>
                  <TableCell className="font-mono text-xs">PR-{it.pullRequest?.prNumber}</TableCell>
                  <TableCell className="text-xs">{it.jiraTicket?.key}</TableCell>
                  <TableCell className="font-mono text-xs">{it.strategy}</TableCell>
                  <TableCell><StatusPill status={it.status} /></TableCell>
                  <TableCell className="max-w-[240px] truncate text-xs">{it.reason}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {r.validationJson && (
        <div>
          <div className="mb-1 text-xs font-medium">Validation report</div>
          <JsonViewer data={r.validationJson} />
        </div>
      )}

      {r.deployments && r.deployments.length > 0 && (
        <div>
          <div className="mb-1 text-xs font-medium">Deployments</div>
          <div className="space-y-2">
            {r.deployments.map((d) => <DeploymentCard key={d.id} d={d} />)}
          </div>
        </div>
      )}
    </div>
  );
}

function Stat({ label, value, tone = 'slate' }: { label: string; value: string | number; tone?: 'slate' | 'brand' | 'amber' | 'rose' }) {
  const tones = { slate: '', brand: 'text-brand-600', amber: 'text-amber-600', rose: 'text-rose-600' };
  return (
    <div className="rounded-md border border-slate-200 p-2 dark:border-slate-800">
      <div className="text-[10px] uppercase tracking-wide text-slate-400">{label}</div>
      <div className={`font-mono text-sm ${tones[tone]}`}>{value}</div>
    </div>
  );
}

function DeploymentCard({ d }: { d: Deployment }) {
  return (
    <div className="rounded-md border border-slate-200 p-2 text-xs dark:border-slate-800">
      <div className="flex items-center gap-2">
        <span className="font-mono">{d.jenkinsJob}</span>
        <span className="font-mono text-slate-500">#{d.buildNumber}</span>
        <span className="ml-auto"><StatusPill status={d.status} /></span>
      </div>
      <div className="mt-1 text-slate-500">
        branch: {d.branch || '-'} · stage: {d.stage || '-'} · retry: {d.retryCount}
      </div>
      {d.failureAnalysis && (
        <div className="mt-1 rounded border border-rose-200 bg-rose-50 p-1.5 text-rose-700 dark:border-rose-800 dark:bg-rose-950/30 dark:text-rose-200">
          <div className="font-medium">AI analysis: {d.failureAnalysis.likelyCause}</div>
          <div>retryable: {d.failureAnalysis.retryable ? 'yes' : 'no'} · recommended: {d.failureAnalysis.recommendedAction}</div>
        </div>
      )}
    </div>
  );
}
