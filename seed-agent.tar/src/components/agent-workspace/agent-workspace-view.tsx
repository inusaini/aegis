'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Loader2, Check, X, SkipForward, Circle, Play, Square, RotateCcw, Send, ChevronRight, AlertCircle } from 'lucide-react';
import { api, type RunDetailResponse, type AgentEventRow } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { StatusPill, ModeBadge } from '@/components/common/status-pill';
import { JsonViewer } from '@/components/common/json-viewer';
import { useUIStore } from '@/stores/ui-store';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

const WORKFLOW_STEPS = [
  { key: 'interpret_request', label: 'Interpret request', icon: '🧭' },
  { key: 'jira_discovery', label: 'Discover Jira tickets', icon: '🎫' },
  { key: 'pr_discovery', label: 'Discover PRs', icon: '🔀' },
  { key: 'jira_pr_correlation', label: 'Correlate Jira ↔ PR', icon: '🔗' },
  { key: 'approval_evaluation', label: 'Evaluate approvals', icon: '✅' },
  { key: 'clone_repository', label: 'Clone repository', icon: '📥' },
  { key: 'fetch_repository_state', label: 'Fetch repository state', icon: '📡' },
  { key: 'build_release_plan', label: 'Build release plan', icon: '🗺️' },
  { key: 'create_release_workspace', label: 'Create release workspace', icon: '🗂️' },
  { key: 'apply_changes', label: 'Apply merge / cherry-pick', icon: '🍒' },
  { key: 'validate_release', label: 'Validate release', icon: '🔬' },
  { key: 'final_git_verification', label: 'Final git verification', icon: '🔎' },
  { key: 'integrate_changes', label: 'Integrate changes', icon: '🚀' },
  { key: 'update_jira', label: 'Update Jira', icon: '📝' },
  { key: 'trigger_jenkins', label: 'Trigger Jenkins', icon: '🏗️' },
  { key: 'monitor_jenkins', label: 'Monitor Jenkins', icon: '📈' },
  { key: 'generate_report', label: 'Generate report', icon: '📊' },
] as const;

const EXAMPLES = [
  'Process all approved seed-data changes for the current release.',
  "Create a release plan for this week's approved changes.",
  'Show all blocked seed PRs.',
  'Resolve conflicts and continue the current release.',
  'Deploy the latest approved seed release.',
  'Why did the release fail?',
  'Resume release RUN-1234.',
];

export function AgentWorkspaceView() {
  const activeRunId = useUIStore((s) => s.activeRunId);
  const setActiveRunId = useUIStore((s) => s.setActiveRunId);

  const [userRequest, setUserRequest] = useState('Process all approved seed-data changes for the current release.');
  const [mode, setMode] = useState('release');
  const [starting, setStarting] = useState(false);
  const [liveEvents, setLiveEvents] = useState<AgentEventRow[]>([]);
  const eventSourceRef = useRef<EventSource | null>(null);

  // Fetch the active run (if any)
  const { data: runData, refetch } = useQuery({
    queryKey: ['run', activeRunId],
    queryFn: () => (activeRunId ? api.getRun(activeRunId) : Promise.resolve(null)),
    enabled: !!activeRunId,
    refetchInterval: 2000,
  });

  // SSE subscription
  useEffect(() => {
    if (!activeRunId) return;
    // Reset events when run changes
    setLiveEvents([]);
    let closed = false;
    const es = new EventSource(`/api/agent/runs/${encodeURIComponent(activeRunId)}/events`);
    eventSourceRef.current = es;
    es.onmessage = (e) => {
      try {
        const payload = JSON.parse(e.data) as AgentEventRow;
        setLiveEvents((prev) => [payload, ...prev].slice(0, 200));
      } catch {
        // ignore keepalives
      }
    };
    // Listen to named events (the server emits `event: <name>\ndata: <json>`)
    // Note: EventSource dispatches named events as separate event listeners.
    // We use onmessage as a fallback for unnamed events, but also wire up the
    // generic handler for our named events by listening to all of them.
    const knownEvents = [
      'workflow.step.started', 'workflow.step.completed', 'workflow.step.failed',
      'workflow.completed', 'workflow.failed', 'workflow.blocked', 'workflow.cancelled',
      'supervisor.interpreted', 'jira.tickets_discovered', 'pr.discovered',
      'jira_pr.correlated', 'approval.verified', 'approval.blocked',
      'git.cloned', 'git.fetched', 'git.workspace_created', 'git.merge.success',
      'git.cherry_pick.success', 'git.conflict.detected', 'conflict.analyzing',
      'conflict.resolved', 'conflict.blocked', 'conflict.failed',
      'validation.completed', 'git.race_detected', 'git.no_race', 'git.pushed',
      'jira.updated', 'deployment.started', 'deployment.progress', 'deployment.completed',
      'deployment.failed', 'deployment.retry', 'report.generated',
      'release.plan_built', 'release.item.skipped', 'release.item.blocked', 'release.item.failed',
      'supervisor.fallback',
    ];
    for (const evName of knownEvents) {
      es.addEventListener(evName, (e) => {
        try {
          const payload = JSON.parse((e as MessageEvent).data);
          setLiveEvents((prev) => [{ event: evName, payload, timestamp: new Date().toISOString(), id: crypto.randomUUID() }, ...prev].slice(0, 200));
          // Toast on key events
          if (evName === 'workflow.completed') toast.success('Agent run completed');
          if (evName === 'workflow.failed') toast.error('Agent run failed');
          if (evName === 'workflow.blocked') toast.warning('Agent run blocked');
          if (evName === 'conflict.resolved') toast.success('Conflict resolved');
          if (evName === 'conflict.blocked') toast.warning('Conflict blocked by policy');
          if (evName === 'deployment.completed') toast.success('Deployment succeeded');
          if (evName === 'deployment.failed') toast.error('Deployment failed');
          refetch();
        } catch {
          // ignore
        }
      });
    }
    es.onerror = () => {
      // EventSource auto-reconnects; just log
      if (closed) return;
    };
    return () => {
      closed = true;
      es.close();
      eventSourceRef.current = null;
    };
  }, [activeRunId, refetch]);

  const startRun = async () => {
    if (!userRequest.trim()) {
      toast.error('Enter a release request first');
      return;
    }
    setStarting(true);
    try {
      const resp = await api.startRun(userRequest, mode);
      setActiveRunId(resp.runId);
      toast.success(`Started ${mode} run ${resp.runId}`);
      refetch();
    } catch (e) {
      toast.error(`Failed to start: ${(e as Error).message}`);
    } finally {
      setStarting(false);
    }
  };

  const resume = async () => {
    if (!activeRunId) return;
    try {
      await api.resumeRun(activeRunId);
      toast.success('Run resumed');
      refetch();
    } catch (e) {
      toast.error(`Resume failed: ${(e as Error).message}`);
    }
  };
  const cancel = async () => {
    if (!activeRunId) return;
    try {
      await api.cancelRun(activeRunId);
      toast.message('Run cancellation requested');
      refetch();
    } catch (e) {
      toast.error(`Cancel failed: ${(e as Error).message}`);
    }
  };

  return (
    <div className="space-y-4 p-6">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-semibold tracking-tight">Agent Workspace</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Issue a natural-language release request. The agent autonomously plans, applies, validates, and deploys.
        </p>
      </div>

      {/* Command bar */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Send className="h-4 w-4 text-brand-600" /> Release request
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Textarea
            value={userRequest}
            onChange={(e) => setUserRequest(e.target.value)}
            rows={3}
            placeholder="Process all approved seed-data changes for the current release."
            className="resize-none"
          />
          <div className="flex flex-wrap items-center gap-2">
            <Select value={mode} onValueChange={setMode}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Mode" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="observe">observe</SelectItem>
                <SelectItem value="plan">plan</SelectItem>
                <SelectItem value="execute">execute</SelectItem>
                <SelectItem value="release">release</SelectItem>
                <SelectItem value="recover">recover</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={startRun} disabled={starting} className="gap-2">
              {starting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
              {starting ? 'Starting…' : 'Run'}
            </Button>
            {activeRunId && (
              <>
                <Button variant="outline" onClick={resume} disabled={runData?.run.status === 'running'} className="gap-2">
                  <RotateCcw className="h-3.5 w-3.5" /> Resume
                </Button>
                <Button variant="outline" onClick={cancel} disabled={runData?.run.status !== 'running'} className="gap-2">
                  <Square className="h-3.5 w-3.5" /> Cancel
                </Button>
                <Badge variant="outline" className="font-mono text-xs">
                  {activeRunId}
                </Badge>
                {runData && <StatusPill status={runData.run.status} />}
                {runData && <ModeBadge mode={runData.run.mode} />}
              </>
            )}
          </div>
          <div className="flex flex-wrap gap-1">
            {EXAMPLES.map((ex) => (
              <button
                key={ex}
                type="button"
                onClick={() => setUserRequest(ex)}
                className="rounded-full border border-slate-200 bg-slate-50 px-2 py-0.5 text-[11px] text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                {ex}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {!activeRunId ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center gap-3 py-16 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-50 text-brand-600 dark:bg-brand-950 dark:text-brand-400">
              <Play className="h-5 w-5" />
            </div>
            <div className="text-sm text-slate-500 dark:text-slate-400">
              No active run. Click <strong>Run</strong> above to start an autonomous release.
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          <StepTimeline runData={runData ?? null} />
          <div className="space-y-4">
            <EventFeed events={liveEvents} />
            <StatePanel runData={runData ?? null} />
          </div>
        </div>
      )}
    </div>
  );
}

function StepTimeline({ runData }: { runData: RunDetailResponse | null }) {
  const stepStatus = useMemo(() => {
    const map: Record<string, 'pending' | 'running' | 'completed' | 'failed' | 'skipped'> = {};
    for (const s of WORKFLOW_STEPS) map[s.key] = 'pending';
    if (runData) {
      for (const ws of runData.workflowStates) {
        const cur = map[ws.step];
        if (ws.status === 'running') map[ws.step] = 'running';
        else if (ws.status === 'failed') map[ws.step] = 'failed';
        else if (ws.status === 'completed') {
          // Don't downgrade completed
          if (cur !== 'failed') map[ws.step] = 'completed';
        }
      }
      // Observe/plan modes stop after build_release_plan
      const mode = runData.run.mode;
      if (mode === 'observe' || mode === 'plan') {
        const planIdx = WORKFLOW_STEPS.findIndex((s) => s.key === 'build_release_plan');
        for (let i = planIdx + 1; i < WORKFLOW_STEPS.length; i++) {
          if (map[WORKFLOW_STEPS[i].key] === 'pending') map[WORKFLOW_STEPS[i].key] = 'skipped';
        }
      }
    }
    return map;
  }, [runData]);

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Execution timeline</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[640px] pr-3">
          <ol className="relative ml-2">
            {WORKFLOW_STEPS.map((s, i) => {
              const status = stepStatus[s.key];
              return (
                <motion.li
                  key={s.key}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.2, delay: i * 0.01 }}
                  className="relative flex items-start gap-3 pb-4 last:pb-0"
                >
                  {/* Connector line */}
                  {i < WORKFLOW_STEPS.length - 1 && (
                    <div
                      className={cn(
                        'absolute left-[11px] top-7 h-[calc(100%-1.5rem)] w-px',
                        status === 'completed' ? 'bg-brand-300 dark:bg-brand-700' : 'bg-slate-200 dark:bg-slate-700',
                      )}
                    />
                  )}
                  {/* Step icon */}
                  <div
                    className={cn(
                      'relative z-10 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 bg-white dark:bg-slate-950',
                      status === 'pending' && 'border-slate-200 text-slate-400 dark:border-slate-700',
                      status === 'running' && 'border-amber-400 text-amber-600',
                      status === 'completed' && 'border-brand-500 bg-brand-500 text-white',
                      status === 'failed' && 'border-rose-500 bg-rose-500 text-white',
                      status === 'skipped' && 'border-slate-300 bg-slate-100 text-slate-400 dark:border-slate-700 dark:bg-slate-900',
                    )}
                  >
                    {status === 'pending' && <Circle className="h-2 w-2" />}
                    {status === 'running' && <Loader2 className="h-3 w-3 animate-spin" />}
                    {status === 'completed' && <Check className="h-3 w-3" />}
                    {status === 'failed' && <X className="h-3 w-3" />}
                    {status === 'skipped' && <SkipForward className="h-3 w-3" />}
                  </div>
                  <div className="flex-1 pt-0.5">
                    <div
                      className={cn(
                        'flex items-center gap-2 text-sm',
                        status === 'pending' && 'text-slate-500 dark:text-slate-400',
                        status === 'running' && 'font-medium text-amber-700 dark:text-amber-300',
                        status === 'completed' && 'text-slate-800 dark:text-slate-100',
                        status === 'failed' && 'font-medium text-rose-700 dark:text-rose-300',
                        status === 'skipped' && 'text-slate-400 line-through',
                      )}
                    >
                      <span className="text-xs opacity-70">{s.icon}</span>
                      {s.label}
                      {status === 'running' && <span className="text-xs text-amber-600">· running…</span>}
                    </div>
                    {status === 'completed' && s.key === 'jira_discovery' && runData?.liveState && (
                      <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                        {runData.liveState.jiraTickets} tickets found
                      </div>
                    )}
                    {status === 'completed' && s.key === 'pr_discovery' && runData?.liveState && (
                      <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                        {runData.liveState.pullRequests} PRs found
                      </div>
                    )}
                    {status === 'completed' && s.key === 'jira_pr_correlation' && runData?.liveState && (
                      <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                        {runData.liveState.correlations} correlations
                      </div>
                    )}
                    {status === 'completed' && s.key === 'approval_evaluation' && runData?.liveState && (
                      <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                        {runData.liveState.approvedTickets} approved · {runData.liveState.pullRequests - runData.liveState.approvedTickets} blocked
                      </div>
                    )}
                    {status === 'completed' && s.key === 'build_release_plan' && runData?.liveState?.releasePlan && (
                      <div className="mt-1 space-y-0.5 text-xs text-slate-500 dark:text-slate-400">
                        <div>{runData.liveState.releasePlan.items.length} items · {runData.liveState.releasePlan.executionOrder.length} to integrate</div>
                      </div>
                    )}
                    {s.key === 'apply_changes' && runData?.liveState && (
                      <div className="mt-1 space-y-0.5">
                        {runData.liveState.releasePlan?.items.map((it) => (
                          <div key={it.prNumber} className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                            <span className="font-mono">PR-{it.prNumber}</span>
                            <span className="text-slate-400">·</span>
                            <span>{it.jiraTicketKey}</span>
                            <span className="text-slate-400">·</span>
                            <span className="font-mono">{it.strategy}</span>
                            <span className="text-slate-400">·</span>
                            {it.status === 'applied' || it.status === 'resolved' || it.status === 'validated' ? (
                              <Check className="h-3 w-3 text-brand-600" />
                            ) : it.status === 'conflict' || it.status === 'failed' ? (
                              <X className="h-3 w-3 text-rose-600" />
                            ) : it.status === 'skipped' ? (
                              <SkipForward className="h-3 w-3 text-slate-400" />
                            ) : (
                              <Circle className="h-2 w-2 text-slate-400" />
                            )}
                            <span className="text-[10px]">{it.status}</span>
                          </div>
                        ))}
                      </div>
                    )}
                    {status === 'completed' && s.key === 'validate_release' && runData?.liveState?.validationReport && (
                      <div className="mt-1 text-xs">
                        <span className={runData.liveState.validationReport.passed ? 'text-brand-600' : 'text-rose-600'}>
                          {runData.liveState.validationReport.passed ? '✓ passed' : '✗ failed'}
                        </span>
                        <span className="text-slate-400"> · +{runData.liveState.validationReport.recordsAdded} ~{runData.liveState.validationReport.recordsUpdated} -{runData.liveState.validationReport.recordsDeleted}</span>
                      </div>
                    )}
                    {s.key === 'monitor_jenkins' && runData?.liveState?.deployment && (
                      <div className="mt-1 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                        <span>Jenkins #{runData.liveState.deployment.buildNumber}</span>
                        {runData.liveState.deployment.stage && <span>· stage: {runData.liveState.deployment.stage}</span>}
                        <StatusPill status={runData.liveState.deployment.status} />
                      </div>
                    )}
                    {status === 'failed' && (
                      <div className="mt-1 text-xs text-rose-600 dark:text-rose-400">
                        See errors panel →
                      </div>
                    )}
                  </div>
                </motion.li>
              );
            })}
          </ol>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

function eventColor(event: string): string {
  if (event.includes('failed') || event.includes('blocked')) return 'text-rose-600';
  if (event.includes('conflict') || event.includes('retry')) return 'text-amber-600';
  if (event.includes('completed') || event.includes('resolved') || event.includes('verified') || event.includes('success')) return 'text-brand-600';
  if (event.includes('started') || event.includes('progress')) return 'text-amber-600';
  return 'text-slate-500';
}

function EventFeed({ events }: { events: AgentEventRow[] }) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-base">
          <span>Live event feed</span>
          <span className="text-xs font-normal text-slate-500">{events.length} events</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-72 max-h-72 pr-3">
          {events.length === 0 ? (
            <div className="flex h-32 items-center justify-center text-sm text-slate-400">
              Waiting for events…
            </div>
          ) : (
            <ul className="space-y-1.5">
              {events.map((ev, i) => (
                <li key={ev.id ?? i} className="flex items-start gap-2 rounded-md border border-slate-100 bg-slate-50 px-2 py-1.5 text-xs dark:border-slate-800 dark:bg-slate-900/40">
                  <span className="font-mono text-[10px] text-slate-400">
                    {ev.timestamp ? format(new Date(ev.timestamp), 'HH:mm:ss.SSS') : ''}
                  </span>
                  <span className={cn('font-mono font-medium', eventColor(ev.event))}>{ev.event}</span>
                  <span className="ml-auto max-w-[60%] truncate text-slate-500 dark:text-slate-400">
                    {summarizePayload(ev)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

function summarizePayload(ev: AgentEventRow): string {
  const p = ev.payload as Record<string, unknown>;
  if (typeof p.step === 'string') return `step: ${p.step}`;
  if (typeof p.pr === 'number') return `PR-${p.pr}`;
  if (typeof p.file === 'string') return p.file;
  if (typeof p.ticket === 'string') return p.ticket;
  if (typeof p.build === 'number') return `build #${p.build}`;
  if (typeof p.count === 'number') return `${p.count}`;
  if (typeof p.reason === 'string') return p.reason;
  return '';
}

function StatePanel({ runData }: { runData: RunDetailResponse | null }) {
  if (!runData?.liveState) {
    return (
      <Card>
        <CardContent className="py-6 text-sm text-slate-500">State unavailable (run may have expired from memory).</CardContent>
      </Card>
    );
  }
  const ls = runData.liveState;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Current state</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="plan">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="plan">Plan</TabsTrigger>
            <TabsTrigger value="conflicts">Conflicts ({ls.conflicts.length})</TabsTrigger>
            <TabsTrigger value="validation">Validation</TabsTrigger>
            <TabsTrigger value="deploy">Deploy</TabsTrigger>
          </TabsList>
          <TabsContent value="plan" className="mt-3 space-y-2">
            {ls.releasePlan ? (
              <>
                <div className="text-xs text-slate-500 dark:text-slate-400">{ls.releasePlan.justification || ''}</div>
                <div className="space-y-1">
                  {ls.releasePlan.items.map((it) => (
                    <div key={it.prNumber} className="flex items-center gap-2 rounded-md border border-slate-100 px-2 py-1.5 text-xs dark:border-slate-800">
                      <span className="font-mono">PR-{it.prNumber}</span>
                      <ChevronRight className="h-3 w-3 text-slate-400" />
                      <span>{it.jiraTicketKey}</span>
                      <ChevronRight className="h-3 w-3 text-slate-400" />
                      <span className="font-mono text-slate-500">{it.strategy}</span>
                      <span className="ml-auto"><StatusPill status={it.status} /></span>
                    </div>
                  ))}
                </div>
                {ls.releasePlan.dependencies.length > 0 && (
                  <div>
                    <div className="text-xs font-medium text-slate-600 dark:text-slate-300">Dependencies</div>
                    <ul className="text-xs text-slate-500 dark:text-slate-400">
                      {ls.releasePlan.dependencies.map((d, i) => (
                        <li key={i}>PR-{d.from} → PR-{d.to} ({d.reason})</li>
                      ))}
                    </ul>
                  </div>
                )}
              </>
            ) : (
              <p className="text-xs text-slate-400">Plan not yet built.</p>
            )}
          </TabsContent>
          <TabsContent value="conflicts" className="mt-3">
            {ls.conflicts.length === 0 ? (
              <p className="text-xs text-slate-400">No conflicts detected.</p>
            ) : (
              <div className="space-y-2">
                {ls.conflicts.map((c) => {
                  const res = ls.conflictResolutions.find((r) => r.conflictId === c.conflictId);
                  return (
                    <div key={c.conflictId} className="rounded-md border border-slate-200 p-2 text-xs dark:border-slate-800">
                      <div className="flex items-center gap-2">
                        <span className="font-mono">{c.conflictId}</span>
                        <span className="font-mono text-slate-500">{c.file}</span>
                        <span className="ml-auto"><StatusPill status={c.status} /></span>
                      </div>
                      {res && (
                        <div className="mt-1 space-y-1">
                          <div>strategy: <span className="font-mono">{res.strategy}</span> · confidence {(res.confidence * 100).toFixed(0)}% · risk <span className="capitalize">{res.riskLevel}</span></div>
                          {res.reasoning && <div className="text-slate-500">{res.reasoning}</div>}
                          {res.evidence.length > 0 && (
                            <ul className="list-inside list-disc text-slate-500">
                              {res.evidence.map((e, i) => <li key={i}>{e}</li>)}
                            </ul>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </TabsContent>
          <TabsContent value="validation" className="mt-3 space-y-2">
            {ls.validationReport ? (
              <>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>Files changed: <span className="font-mono">{ls.validationReport.filesChanged}</span></div>
                  <div>Added: <span className="font-mono text-brand-600">+{ls.validationReport.recordsAdded}</span></div>
                  <div>Updated: <span className="font-mono text-amber-600">~{ls.validationReport.recordsUpdated}</span></div>
                  <div>Deleted: <span className="font-mono text-rose-600">-{ls.validationReport.recordsDeleted}</span></div>
                </div>
                <div className={ls.validationReport.passed ? 'text-brand-600 text-xs' : 'text-rose-600 text-xs'}>
                  {ls.validationReport.passed ? '✓ Validation passed' : '✗ Validation failed'}
                </div>
                {ls.validationReport.errors.length > 0 && (
                  <div>
                    <div className="text-xs font-medium text-rose-600">Errors</div>
                    <ul className="text-xs text-rose-600 list-inside list-disc">
                      {ls.validationReport.errors.map((e, i) => <li key={i}>{e}</li>)}
                    </ul>
                  </div>
                )}
                {ls.validationReport.warnings.length > 0 && (
                  <div>
                    <div className="text-xs font-medium text-amber-600">Warnings</div>
                    <ul className="text-xs text-amber-600 list-inside list-disc">
                      {ls.validationReport.warnings.map((e, i) => <li key={i}>{e}</li>)}
                    </ul>
                  </div>
                )}
                <div>
                  <div className="text-xs font-medium text-slate-600 dark:text-slate-300">Validator results</div>
                  <ul className="space-y-1 text-xs">
                    {ls.validationReport.results.map((r, i) => (
                      <li key={i} className="flex items-center gap-2">
                        {r.status === 'pass' ? <Check className="h-3 w-3 text-brand-600" /> : r.status === 'warning' ? <AlertCircle className="h-3 w-3 text-amber-600" /> : <X className="h-3 w-3 text-rose-600" />}
                        <span className="font-mono">{r.validator}</span>
                        {r.file && <span className="text-slate-500">{r.file}</span>}
                        <span className="text-slate-500">{r.message}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </>
            ) : (
              <p className="text-xs text-slate-400">Not yet validated.</p>
            )}
          </TabsContent>
          <TabsContent value="deploy" className="mt-3 space-y-2">
            {ls.deployment ? (
              <>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-sm">{ls.deployment.jenkinsJob}</span>
                  <span className="font-mono text-xs text-slate-500">#{ls.deployment.buildNumber}</span>
                  <span className="ml-auto"><StatusPill status={ls.deployment.status} /></span>
                </div>
                {ls.deployment.stage && <div className="text-xs text-slate-500">Stage: {ls.deployment.stage}</div>}
                {ls.deployment.failureAnalysis && (
                  <div className="rounded-md border border-rose-200 bg-rose-50 p-2 text-xs dark:border-rose-800 dark:bg-rose-950/30">
                    <div className="font-medium text-rose-700 dark:text-rose-300">AI Failure Analysis</div>
                    <div className="mt-1 text-rose-700 dark:text-rose-200">{ls.deployment.failureAnalysis.likelyCause}</div>
                    <div className="mt-1 flex items-center gap-2">
                      <span>retryable:</span>
                      <span className={ls.deployment.failureAnalysis.retryable ? 'text-brand-600' : 'text-rose-600'}>
                        {ls.deployment.failureAnalysis.retryable ? 'yes' : 'no'}
                      </span>
                      <span>·</span>
                      <span>recommended: <span className="font-mono">{ls.deployment.failureAnalysis.recommendedAction}</span></span>
                      <span>·</span>
                      <span>confidence {(ls.deployment.failureAnalysis.confidence * 100).toFixed(0)}%</span>
                    </div>
                    {ls.deployment.failureAnalysis.evidence.length > 0 && (
                      <ul className="mt-1 list-inside list-disc text-rose-700 dark:text-rose-200">
                        {ls.deployment.failureAnalysis.evidence.map((e, i) => <li key={i} className="truncate">{e}</li>)}
                      </ul>
                    )}
                  </div>
                )}
                {ls.deployment.consoleLog && (
                  <div>
                    <div className="text-xs font-medium text-slate-600 dark:text-slate-300">Console log</div>
                    <JsonViewer data={ls.deployment.consoleLog} className="mt-1" />
                  </div>
                )}
              </>
            ) : (
              <p className="text-xs text-slate-400">No deployment triggered yet.</p>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
