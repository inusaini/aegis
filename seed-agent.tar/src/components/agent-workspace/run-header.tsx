'use client';

import * as React from 'react';
import {
  Ban,
  Check,
  Copy,
  Loader2,
  PlayCircle,
  RotateCw,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { StatusPill } from '@/components/common/status-pill';
import { api } from '@/lib/api';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface RunHeaderProps {
  runId: string | null;
  status: string;
  mode: string;
  retryCount: number;
  warnings: string[];
  errors: string[];
  onResumed?: () => void;
  onCancelled?: () => void;
}

export function RunHeader({
  runId,
  status,
  mode,
  retryCount,
  warnings,
  errors,
  onResumed,
  onCancelled,
}: RunHeaderProps) {
  const [busy, setBusy] = React.useState<'resume' | 'cancel' | null>(null);
  const [copied, setCopied] = React.useState(false);

  const resume = React.useCallback(async () => {
    if (!runId) return;
    setBusy('resume');
    try {
      await api.resumeRun(runId);
      toast.success(`Run ${runId} resumed`);
      onResumed?.();
    } catch (e) {
      toast.error('Failed to resume run', { description: e instanceof Error ? e.message : String(e) });
    } finally {
      setBusy(null);
    }
  }, [runId, onResumed]);

  const cancel = React.useCallback(async () => {
    if (!runId) return;
    setBusy('cancel');
    try {
      await api.cancelRun(runId);
      toast.success(`Run ${runId} cancelled`);
      onCancelled?.();
    } catch (e) {
      toast.error('Failed to cancel run', { description: e instanceof Error ? e.message : String(e) });
    } finally {
      setBusy(null);
    }
  }, [runId, onCancelled]);

  const copy = React.useCallback(async () => {
    if (!runId) return;
    try {
      await navigator.clipboard.writeText(runId);
      setCopied(true);
      setTimeout(() => setCopied(false), 1200);
    } catch {
      // ignore
    }
  }, [runId]);

  return (
    <div className="flex flex-col gap-2 rounded-xl border border-border/70 bg-card p-3 sm:p-4 shadow-sm">
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs uppercase tracking-wide text-muted-foreground">Run</span>
        <Badge
          variant="outline"
          className="font-mono text-xs cursor-pointer hover:bg-accent/60"
          onClick={copy}
          title="Copy run ID"
        >
          {runId ?? '—'}
          {runId ? (
            copied ? (
              <Check className="size-3 text-brand-600" />
            ) : (
              <Copy className="size-3 text-muted-foreground" />
            )
          ) : null}
        </Badge>
        <StatusPill status={status || 'pending'} />
        <Badge variant="secondary" className="text-[11px] font-mono">{mode}</Badge>
        {retryCount > 0 ? (
          <span className="text-[11px] text-amber-700 dark:text-amber-400">
            ↻ {retryCount} retry{retryCount === 1 ? '' : 's'}
          </span>
        ) : null}
        <div className="ml-auto flex items-center gap-1.5">
          {(status === 'blocked' || status === 'failed') && runId ? (
            <Button
              size="sm"
              variant="outline"
              onClick={resume}
              disabled={busy !== null}
              className="border-brand-500/30 text-brand-700 dark:text-brand-400 hover:bg-brand-500/10"
            >
              {busy === 'resume' ? <Loader2 className="size-3.5 animate-spin" /> : <RotateCw className="size-3.5" />}
              Resume
            </Button>
          ) : null}
          {(status === 'running' || status === 'pending') && runId ? (
            <Button
              size="sm"
              variant="outline"
              onClick={cancel}
              disabled={busy !== null}
              className="border-rose-500/30 text-rose-700 dark:text-rose-400 hover:bg-rose-500/10"
            >
              {busy === 'cancel' ? <Loader2 className="size-3.5 animate-spin" /> : <Ban className="size-3.5" />}
              Cancel
            </Button>
          ) : null}
        </div>
      </div>
      {(warnings.length > 0 || errors.length > 0) && (
        <div className="flex flex-col gap-1 text-xs">
          {errors.slice(0, 2).map((e, i) => (
            <p key={`e-${i}`} className="flex items-start gap-1.5 text-rose-700 dark:text-rose-400">
              <Ban className="mt-0.5 size-3.5 shrink-0" />
              <span className="leading-relaxed">{e}</span>
            </p>
          ))}
          {warnings.slice(0, 2).map((w, i) => (
            <p key={`w-${i}`} className="flex items-start gap-1.5 text-amber-700 dark:text-amber-400">
              <Check className="mt-0.5 size-3.5 shrink-0" />
              <span className="leading-relaxed">{w}</span>
            </p>
          ))}
        </div>
      )}
      {!runId ? (
        <p className={cn('text-xs text-muted-foreground')}>
          <PlayCircle className="mr-1 inline size-3.5 align-text-bottom" />
          No run selected. Start one above with the command bar.
        </p>
      ) : null}
    </div>
  );
}
