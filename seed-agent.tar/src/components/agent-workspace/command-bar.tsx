'use client';

import * as React from 'react';
import { Loader2, Play, Sparkles, Wand2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { api } from '@/lib/api';
import type { AgentMode } from '@/lib/agent/types';
import { useUIStore } from '@/stores/ui-store';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const EXAMPLE_PROMPTS: { text: string; mode: AgentMode; hint: string }[] = [
  { text: 'Process all approved seed-data changes for the current release.', mode: 'release', hint: 'Full autonomous release' },
  { text: 'Create a release plan for this week\'s approved changes.', mode: 'plan', hint: 'Plan-only mode' },
  { text: 'Show all blocked seed PRs.', mode: 'observe', hint: 'Read-only observation' },
  { text: 'Resolve conflicts and continue the current release.', mode: 'recover', hint: 'Resume a blocked run' },
  { text: 'Deploy the latest approved seed release.', mode: 'release', hint: 'Execute + deploy' },
  { text: 'Why did the release fail?', mode: 'recover', hint: 'Failure analysis' },
  { text: 'Resume release RUN-1234.', mode: 'recover', hint: 'Resume a specific run' },
];

const MODES: { value: AgentMode; label: string; description: string }[] = [
  { value: 'observe', label: 'Observe', description: 'Read-only — gather state, no changes' },
  { value: 'plan', label: 'Plan', description: 'Build a release plan, then stop' },
  { value: 'execute', label: 'Execute', description: 'Apply plan but do not deploy' },
  { value: 'release', label: 'Release', description: 'Plan → apply → validate → deploy' },
  { value: 'recover', label: 'Recover', description: 'Analyze failure and resume' },
];

export interface CommandBarProps {
  /** When provided, the run will start with this exact text/mode (overrides the store). */
  defaults?: { command?: string; mode?: AgentMode };
  /** Called when a run is successfully started. */
  onStarted?: (runId: string, mode: AgentMode) => void;
  /** Compact layout for use inside a dialog. */
  compact?: boolean;
  className?: string;
}

export function CommandBar({ defaults, onStarted, compact, className }: CommandBarProps) {
  const storeCommand = useUIStore((s) => s.command);
  const storeMode = useUIStore((s) => s.mode);
  const setCommand = useUIStore((s) => s.setCommand);
  const setMode = useUIStore((s) => s.setMode);

  const command = defaults?.command ?? storeCommand;
  const mode = defaults?.mode ?? storeMode;

  const [submitting, setSubmitting] = React.useState(false);

  const submit = React.useCallback(
    async (cmdOverride?: string, modeOverride?: AgentMode) => {
      const cmd = (cmdOverride ?? command).trim();
      const m = modeOverride ?? mode;
      if (!cmd) {
        toast.error('Please enter a request for the agent.');
        return;
      }
      setSubmitting(true);
      try {
        const res = await api.startRun({ userRequest: cmd, mode: m });
        toast.success(`Run started`, { description: `${res.runId} · mode: ${m}` });
        setCommand(cmd);
        setMode(m);
        onStarted?.(res.runId, m);
      } catch (e) {
        toast.error('Failed to start run', {
          description: e instanceof Error ? e.message : String(e),
        });
      } finally {
        setSubmitting(false);
      }
    },
    [command, mode, onStarted, setCommand, setMode],
  );

  return (
    <div className={cn('rounded-xl border border-border/70 bg-card shadow-sm', className)}>
      <div className="flex flex-col gap-3 p-3 sm:p-4">
        <div className="flex items-center gap-2 text-sm font-medium text-foreground">
          <Sparkles className="size-4 text-brand-600 dark:text-brand-400" />
          <span>Describe what you want the agent to do</span>
        </div>
        <Textarea
          value={command}
          onChange={(e) => setCommand(e.target.value)}
          placeholder="e.g. Process all approved seed-data changes for the current release."
          className={cn('min-h-24 resize-y font-mono text-sm', compact && 'min-h-20')}
          aria-label="Natural-language request for the agent"
          onKeyDown={(e) => {
            if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
              void submit();
            }
          }}
        />
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Mode</span>
            <Select value={mode} onValueChange={(v) => setMode(v as AgentMode)}>
              <SelectTrigger size="sm" className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {MODES.map((m) => (
                  <SelectItem key={m.value} value={m.value}>
                    <div className="flex flex-col items-start gap-0.5">
                      <span className="font-medium">{m.label}</span>
                      <span className="text-[11px] text-muted-foreground">{m.description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Badge variant="outline" className="hidden sm:inline-flex border-brand-500/30 bg-brand-500/10 text-brand-700 dark:text-brand-400">
              <Wand2 className="size-3" /> Autonomy: on
            </Badge>
          </div>
          <Button
            type="button"
            onClick={() => void submit()}
            disabled={submitting || !command.trim()}
            className="bg-brand-600 hover:bg-brand-700 text-white"
          >
            {submitting ? <Loader2 className="size-4 animate-spin" /> : <Play className="size-4" />}
            {submitting ? 'Starting…' : 'Run'}
            <span className="ml-1 hidden text-[10px] font-normal opacity-70 sm:inline">⌘↵</span>
          </Button>
        </div>
        {!compact ? (
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
              Examples
            </span>
            {EXAMPLE_PROMPTS.map((ex) => (
              <button
                key={ex.text}
                type="button"
                onClick={() => {
                  setCommand(ex.text);
                  setMode(ex.mode);
                }}
                className="group inline-flex items-center gap-1.5 rounded-md border border-border/70 bg-muted/30 px-2 py-1 text-xs text-muted-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
                title={ex.hint}
              >
                <span className="size-1.5 rounded-full bg-brand-500/70" />
                <span className="max-w-[26ch] truncate">{ex.text}</span>
              </button>
            ))}
          </div>
        ) : null}
      </div>
    </div>
  );
}

export { EXAMPLE_PROMPTS, MODES };
