'use client';

import * as React from 'react';
import {
  Check,
  Circle,
  GitMerge,
  GitPullRequestArrow,
  ListChecks,
  Loader2,
  PackageCheck,
  PlayCircle,
  Rocket,
  ScrollText,
  ShieldAlert,
  SkipForward,
  Sparkles,
  SquareDashedBottom,
  Ticket,
  TreePalm,
  Workflow,
  X,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type {
  AgentEventPayload,
  ConflictRecord,
  ConflictResolution,
  ReleasePlan,
  ReleaseValidationReport,
  WorkflowStep,
} from '@/lib/agent/types';
import type { WorkflowStateRow } from '@/lib/api';
import { RiskBadge } from '@/components/common/risk-badge';

// The 17 canonical workflow steps in execution order.
export const WORKFLOW_STEPS: {
  key: WorkflowStep;
  label: string;
  icon: React.ReactNode;
  group: string;
}[] = [
  { key: 'interpret_request', label: 'Interpret request', icon: <Sparkles className="size-3.5" />, group: 'Understand' },
  { key: 'jira_discovery', label: 'Discover Jira tickets', icon: <Ticket className="size-3.5" />, group: 'Understand' },
  { key: 'pr_discovery', label: 'Discover pull requests', icon: <GitPullRequestArrow className="size-3.5" />, group: 'Understand' },
  { key: 'jira_pr_correlation', label: 'Correlate Jira ↔ PR', icon: <Workflow className="size-3.5" />, group: 'Understand' },
  { key: 'approval_evaluation', label: 'Evaluate approvals', icon: <ListChecks className="size-3.5" />, group: 'Understand' },
  { key: 'clone_repository', label: 'Clone repository', icon: <TreePalm className="size-3.5" />, group: 'Plan & prepare' },
  { key: 'fetch_repository_state', label: 'Fetch repository state', icon: <GitMerge className="size-3.5" />, group: 'Plan & prepare' },
  { key: 'build_release_plan', label: 'Build release plan', icon: <PackageCheck className="size-3.5" />, group: 'Plan & prepare' },
  { key: 'create_release_workspace', label: 'Create release workspace', icon: <SquareDashedBottom className="size-3.5" />, group: 'Plan & prepare' },
  { key: 'apply_changes', label: 'Apply changes', icon: <GitMerge className="size-3.5" />, group: 'Apply' },
  { key: 'validate_release', label: 'Validate release', icon: <ShieldAlert className="size-3.5" />, group: 'Apply' },
  { key: 'final_git_verification', label: 'Final Git verification', icon: <ShieldAlert className="size-3.5" />, group: 'Apply' },
  { key: 'integrate_changes', label: 'Integrate changes', icon: <GitPullRequestArrow className="size-3.5" />, group: 'Integrate & deploy' },
  { key: 'update_jira', label: 'Update Jira', icon: <Ticket className="size-3.5" />, group: 'Integrate & deploy' },
  { key: 'trigger_jenkins', label: 'Trigger Jenkins', icon: <Rocket className="size-3.5" />, group: 'Integrate & deploy' },
  { key: 'monitor_jenkins', label: 'Monitor Jenkins', icon: <PlayCircle className="size-3.5" />, group: 'Integrate & deploy' },
  { key: 'generate_report', label: 'Generate report', icon: <ScrollText className="size-3.5" />, group: 'Integrate & deploy' },
];

export type StepStatus = 'pending' | 'running' | 'completed' | 'failed' | 'skipped';

interface StepTimelineProps {
  workflowStates: WorkflowStateRow[];
  currentStep: string | null;
  liveStep: string | null | undefined;
  runStatus: string;
  events: AgentEventPayload[];
  liveState: {
    jiraTickets: number;
    pullRequests: number;
    correlations: number;
    approvedTickets: number;
    conflicts: ConflictRecord[];
    conflictResolutions: ConflictResolution[];
    releasePlan?: ReleasePlan;
    validationReport?: ReleaseValidationReport;
    deployment?: {
      deploymentId: string;
      jenkinsJob: string;
      buildNumber?: number;
      status: string;
      stage?: string;
      retryCount: number;
    };
    warnings: string[];
    errors: string[];
    mergeResults: { prNumber: number; strategy: string; commitSha?: string; status: string }[];
  } | null;
}

function deriveStepStatus(
  step: string,
  workflowStates: WorkflowStateRow[],
  currentStep: string | null,
  runStatus: string,
): StepStatus {
  // Most recent workflow state row for this step.
  const rows = workflowStates.filter((r) => r.step === step);
  const latest = rows[0]; // API returns desc order
  if (latest) {
    if (latest.status === 'completed') return 'completed';
    if (latest.status === 'failed') return 'failed';
    if (latest.status === 'skipped') return 'skipped';
    if (latest.status === 'running') return 'running';
  }
  // No persisted state for this step — infer from current step / run status.
  if (currentStep === step) {
    if (runStatus === 'failed') return 'failed';
    if (runStatus === 'blocked') return 'failed';
    if (runStatus === 'cancelled') return 'skipped';
    return 'running';
  }
  return 'pending';
}

const STATUS_ICON: Record<StepStatus, React.ReactNode> = {
  pending: <Circle className="size-3.5 text-muted-foreground/50" />,
  running: <Loader2 className="size-3.5 text-amber-500 animate-spin" />,
  completed: <Check className="size-3.5 text-brand-600 dark:text-brand-400" />,
  failed: <X className="size-3.5 text-rose-600 dark:text-rose-400" />,
  skipped: <SkipForward className="size-3.5 text-muted-foreground/70" />,
};

const STATUS_LINE: Record<StepStatus, string> = {
  pending: 'bg-border/40',
  running: 'bg-amber-500/40',
  completed: 'bg-brand-500/40',
  failed: 'bg-rose-500/40',
  skipped: 'bg-border/40',
};

function StepSubBullets({
  step,
  status,
  liveState,
  events,
}: {
  step: string;
  status: StepStatus;
  liveState: StepTimelineProps['liveState'];
  events: AgentEventPayload[];
}) {
  if (!liveState) return null;
  // For completed/running steps, render the relevant per-step data.
  if (status === 'pending' || status === 'skipped') return null;

  const bullets: React.ReactNode[] = [];

  switch (step) {
    case 'interpret_request': {
      const interpreted = events.find(
        (e) => e.event === 'supervisor.interpreted',
      );
      if (interpreted?.intent) {
        bullets.push(
          <SubBullet key="intent">
            Intent: <span className="font-medium">{String(interpreted.intent)}</span>
          </SubBullet>,
        );
      }
      if (interpreted?.mode) {
        bullets.push(
          <SubBullet key="mode">Mode: <span className="font-medium">{String(interpreted.mode)}</span></SubBullet>,
        );
      }
      break;
    }
    case 'jira_discovery': {
      if (liveState.jiraTickets > 0) {
        bullets.push(<SubBullet key="t">{liveState.jiraTickets} tickets found</SubBullet>);
      }
      break;
    }
    case 'pr_discovery': {
      if (liveState.pullRequests > 0) {
        bullets.push(<SubBullet key="p">{liveState.pullRequests} pull requests found</SubBullet>);
      }
      break;
    }
    case 'jira_pr_correlation': {
      if (liveState.correlations > 0) {
        bullets.push(<SubBullet key="c">{liveState.correlations} correlated pairs</SubBullet>);
      }
      break;
    }
    case 'approval_evaluation': {
      if (liveState.approvedTickets > 0 || liveState.jiraTickets > 0) {
        bullets.push(
          <SubBullet key="a">
            {liveState.approvedTickets} approved / {liveState.jiraTickets} total
          </SubBullet>,
        );
      }
      break;
    }
    case 'build_release_plan': {
      const plan = liveState.releasePlan;
      if (plan) {
        bullets.push(
          <SubBullet key="plan">
            Plan: {plan.items.length} items · target <code className="font-mono text-[11px]">{plan.targetBranch}</code>
          </SubBullet>,
        );
        if (plan.skipped.length > 0) {
          bullets.push(<SubBullet key="sk" tone="amber">Skipped: {plan.skipped.join(', ')}</SubBullet>);
        }
        if (plan.conflicts.length > 0) {
          bullets.push(<SubBullet key="cf" tone="rose">Expected conflicts: {plan.conflicts.join(', ')}</SubBullet>);
        }
      }
      break;
    }
    case 'apply_changes': {
      if (liveState.mergeResults.length > 0) {
        liveState.mergeResults.forEach((m) => {
          const ok = m.status === 'success';
          const warn = m.status === 'conflict';
          bullets.push(
            <SubBullet key={`m-${m.prNumber}`} tone={ok ? 'brand' : warn ? 'amber' : 'rose'}>
              PR #{m.prNumber} · {m.strategy}
              {ok ? ' ✓' : warn ? ' ⚠ conflict' : ' ✗'}
            </SubBullet>,
          );
        });
      }
      if (liveState.conflicts.length > 0) {
        bullets.push(
          <SubBullet key="conflicts" tone="rose">
            {liveState.conflicts.length} conflict(s) detected
          </SubBullet>,
        );
        liveState.conflicts.slice(0, 4).forEach((c) => {
          bullets.push(
            <SubBullet key={`c-${c.conflictId}`} tone="amber">
              <code className="font-mono text-[11px]">{c.file}</code> · {c.status}
            </SubBullet>,
          );
        });
      }
      break;
    }
    case 'validate_release': {
      const vr = liveState.validationReport;
      if (vr) {
        bullets.push(
          <SubBullet key="v">
            {vr.filesChanged} files · +{vr.recordsAdded} / ~{vr.recordsUpdated} / -{vr.recordsDeleted} records
          </SubBullet>,
        );
        if (vr.passed) {
          bullets.push(<SubBullet key="vp" tone="brand">Validation passed ({vr.results.length} checks)</SubBullet>);
        } else {
          bullets.push(<SubBullet key="vf" tone="rose">Validation failed</SubBullet>);
        }
        if (vr.warnings.length > 0) {
          bullets.push(<SubBullet key="vw" tone="amber">{vr.warnings.length} warnings</SubBullet>);
        }
      }
      break;
    }
    case 'trigger_jenkins':
    case 'monitor_jenkins': {
      const dep = liveState.deployment;
      if (dep) {
        bullets.push(
          <SubBullet key="dep">
            {dep.jenkinsJob}
            {dep.buildNumber ? ` #${dep.buildNumber}` : ''} · {dep.status}
          </SubBullet>,
        );
        if (dep.stage) {
          bullets.push(<SubBullet key="stage">Stage: {dep.stage}</SubBullet>);
        }
        if (dep.retryCount > 0) {
          bullets.push(<SubBullet key="retry" tone="amber">{dep.retryCount} retry attempt(s)</SubBullet>);
        }
      }
      break;
    }
    case 'generate_report': {
      if (liveState.warnings.length > 0) {
        bullets.push(<SubBullet key="w" tone="amber">{liveState.warnings.length} warnings</SubBullet>);
      }
      if (liveState.errors.length > 0) {
        bullets.push(<SubBullet key="e" tone="rose">{liveState.errors.length} errors</SubBullet>);
      }
      break;
    }
    default:
      break;
  }

  if (bullets.length === 0) return null;
  return <ul className="mt-1.5 flex flex-col gap-1 pl-1">{bullets}</ul>;
}

function SubBullet({
  children,
  tone = 'neutral',
}: {
  children: React.ReactNode;
  tone?: 'neutral' | 'brand' | 'amber' | 'rose';
}) {
  const toneClass =
    tone === 'brand'
      ? 'text-brand-700 dark:text-brand-400'
      : tone === 'amber'
        ? 'text-amber-700 dark:text-amber-400'
        : tone === 'rose'
          ? 'text-rose-700 dark:text-rose-400'
          : 'text-muted-foreground';
  return (
    <li className="flex items-start gap-1.5 text-[11.5px] leading-relaxed">
      <span className={cn('mt-1.5 size-1 shrink-0 rounded-full', toneClass.replace('text-', 'bg-'))} />
      <span className={toneClass}>{children}</span>
    </li>
  );
}

export function StepTimeline({
  workflowStates,
  currentStep,
  liveStep,
  runStatus,
  events,
  liveState,
}: StepTimelineProps) {
  const step = liveStep ?? currentStep;
  // Group steps by their `group` for nicer visual separation.
  const grouped = React.useMemo(() => {
    const groups: Record<string, typeof WORKFLOW_STEPS> = {};
    WORKFLOW_STEPS.forEach((s) => {
      (groups[s.group] ??= []).push(s);
    });
    return groups;
  }, []);

  return (
    <ol className="flex flex-col gap-1">
      {Object.entries(grouped).map(([group, steps], gi) => (
        <li key={group}>
          {gi > 0 ? <div className="h-2" /> : null}
          <p className="px-2 text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground/70">
            {group}
          </p>
          <ol className="mt-1 flex flex-col">
            {steps.map((s, idx) => {
              const status = deriveStepStatus(s.key, workflowStates, step, runStatus);
              const isLast = idx === steps.length - 1;
              return (
                <li
                  key={s.key}
                  className={cn('relative flex gap-2.5 px-2 py-1.5 rounded-md', status === 'running' && 'bg-amber-500/5')}
                >
                  {!isLast && (
                    <span
                      aria-hidden
                      className={cn('absolute left-[14px] top-7 bottom-0 w-px', STATUS_LINE[status])}
                    />
                  )}
                  <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-background ring-1 ring-inset ring-border/70">
                    {STATUS_ICON[status]}
                  </span>
                  <div className="flex flex-col min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className={cn('text-[12.5px] font-medium', status === 'pending' ? 'text-muted-foreground' : 'text-foreground')}>
                        {s.label}
                      </span>
                      {status === 'running' ? (
                        <span className="text-[10px] uppercase tracking-wide text-amber-600 dark:text-amber-400">
                          running
                        </span>
                      ) : null}
                      {status === 'failed' ? (
                        <RiskBadge level="high" className="!px-1.5 !py-0 !text-[10px]" />
                      ) : null}
                    </div>
                    <StepSubBullets step={s.key} status={status} liveState={liveState} events={events} />
                  </div>
                </li>
              );
            })}
          </ol>
        </li>
      ))}
    </ol>
  );
}
