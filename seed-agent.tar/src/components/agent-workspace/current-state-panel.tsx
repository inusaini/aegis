'use client';

import * as React from 'react';
import { motion } from 'framer-motion';
import {
  AlertTriangle,
  CheckCircle2,
  CircleSlash,
  CloudUpload,
  GitMerge,
  ListChecks,
  ShieldAlert,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { RiskBadge } from '@/components/common/risk-badge';
import { StatusPill } from '@/components/common/status-pill';
import { EmptyState } from '@/components/common/empty-state';
import { formatDuration } from '@/lib/format';
import type {
  ConflictRecord,
  ConflictResolution,
  DeploymentStatus,
  ReleasePlan,
  ReleaseValidationReport,
} from '@/lib/agent/types';

interface CurrentStatePanelProps {
  releasePlan?: ReleasePlan;
  conflicts: ConflictRecord[];
  conflictResolutions: ConflictResolution[];
  validationReport?: ReleaseValidationReport;
  deployment?: DeploymentStatus;
}

export function CurrentStatePanel({
  releasePlan,
  conflicts,
  conflictResolutions,
  validationReport,
  deployment,
}: CurrentStatePanelProps) {
  const tabValue = React.useMemo(() => {
    if (conflicts.length > 0) return 'conflicts';
    if (releasePlan) return 'plan';
    return 'plan';
  }, [conflicts.length, releasePlan]);

  return (
    <Tabs defaultValue={tabValue} className="gap-3">
      <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 h-9">
        <TabsTrigger value="plan" className="gap-1.5">
          <ListChecks className="size-3.5" /> Plan
        </TabsTrigger>
        <TabsTrigger value="conflicts" className="gap-1.5">
          <ShieldAlert className="size-3.5" /> Conflicts
          {conflicts.length > 0 ? (
            <span className="ml-1 inline-flex items-center justify-center rounded-full bg-rose-500/20 px-1.5 text-[10px] font-medium text-rose-700 dark:text-rose-400">
              {conflicts.length}
            </span>
          ) : null}
        </TabsTrigger>
        <TabsTrigger value="validation" className="gap-1.5">
          <CheckCircle2 className="size-3.5" /> Validation
        </TabsTrigger>
        <TabsTrigger value="deployment" className="gap-1.5">
          <CloudUpload className="size-3.5" /> Deploy
        </TabsTrigger>
      </TabsList>

      <TabsContent value="plan">
        <PlanTab plan={releasePlan} />
      </TabsContent>
      <TabsContent value="conflicts">
        <ConflictsTab conflicts={conflicts} resolutions={conflictResolutions} />
      </TabsContent>
      <TabsContent value="validation">
        <ValidationTab report={validationReport} />
      </TabsContent>
      <TabsContent value="deployment">
        <DeploymentTab deployment={deployment} />
      </TabsContent>
    </Tabs>
  );
}

function PlanTab({ plan }: { plan?: ReleasePlan }) {
  if (!plan) {
    return (
      <EmptyState
        icon={<ListChecks className="size-5" />}
        title="No release plan yet"
        description="The agent will build a release plan once it has discovered and correlated the approved Jira tickets and pull requests."
      />
    );
  }
  return (
    <motion.div
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.15 }}
      className="space-y-3"
    >
      <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
        <span className="rounded-md border border-border/60 bg-muted/30 px-2 py-0.5 font-mono">
          {plan.releaseId}
        </span>
        <span>→</span>
        <span className="rounded-md border border-border/60 bg-muted/30 px-2 py-0.5 font-mono">
          {plan.targetBranch}
        </span>
        {plan.justification ? (
          <span className="text-muted-foreground italic">
            {plan.justification}
          </span>
        ) : null}
      </div>
      <div className="rounded-md border border-border/60">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/30">
              <TableHead className="w-12 text-center">#</TableHead>
              <TableHead>Jira</TableHead>
              <TableHead>PR</TableHead>
              <TableHead>Strategy</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="min-w-40">Reason</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {plan.items.map((it) => (
              <TableRow key={it.id}>
                <TableCell className="text-center text-xs text-muted-foreground tabular-nums">
                  {it.executionOrder}
                </TableCell>
                <TableCell className="font-mono text-xs">{it.jiraTicketKey}</TableCell>
                <TableCell className="font-mono text-xs">#{it.prNumber}</TableCell>
                <TableCell>
                  <span
                    className={cn(
                      'inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10.5px] font-medium',
                      it.strategy === 'cherry_pick' && 'bg-brand-500/10 text-brand-700 dark:text-brand-400 border-brand-500/30',
                      it.strategy === 'merge' && 'bg-brand-500/10 text-brand-700 dark:text-brand-400 border-brand-500/30',
                      it.strategy === 'skip' && 'bg-slate-500/10 text-slate-600 dark:text-slate-300 border-slate-500/30',
                      it.strategy === 'blocked' && 'bg-rose-500/10 text-rose-700 dark:text-rose-400 border-rose-500/30',
                    )}
                  >
                    <GitMerge className="size-3" />
                    {it.strategy.replace('_', ' ')}
                  </span>
                </TableCell>
                <TableCell>
                  <StatusPill status={it.status} />
                </TableCell>
                <TableCell className="text-xs text-muted-foreground">{it.reason ?? '—'}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      {(plan.dependencies.length > 0 || plan.alreadyIntegrated.length > 0 || plan.skipped.length > 0) && (
        <div className="grid gap-2 sm:grid-cols-3">
          <PlanStat label="Dependencies" value={plan.dependencies.length} tone="slate" />
          <PlanStat label="Already integrated" value={plan.alreadyIntegrated.length} tone="brand" />
          <PlanStat label="Skipped" value={plan.skipped.length} tone="amber" />
        </div>
      )}
    </motion.div>
  );
}

function PlanStat({ label, value, tone }: { label: string; value: number; tone: 'slate' | 'brand' | 'amber' | 'rose' }) {
  const toneClass =
    tone === 'brand'
      ? 'text-brand-700 dark:text-brand-400'
      : tone === 'amber'
        ? 'text-amber-700 dark:text-amber-400'
        : tone === 'rose'
          ? 'text-rose-700 dark:text-rose-400'
          : 'text-muted-foreground';
  return (
    <div className="rounded-md border border-border/60 bg-muted/20 p-3">
      <p className="text-[10.5px] uppercase tracking-wide text-muted-foreground/80">{label}</p>
      <p className={cn('mt-1 text-lg font-semibold tabular-nums', toneClass)}>{value}</p>
    </div>
  );
}

function ConflictsTab({
  conflicts,
  resolutions,
}: {
  conflicts: ConflictRecord[];
  resolutions: ConflictResolution[];
}) {
  if (conflicts.length === 0) {
    return (
      <EmptyState
        icon={<ShieldAlert className="size-5" />}
        title="No conflicts detected"
        description="The agent has not encountered any merge conflicts during this run. Conflicts will appear here as they are detected."
      />
    );
  }
  return (
    <motion.ul
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.15 }}
      className="flex flex-col gap-2"
    >
      {conflicts.map((c) => {
        const res = resolutions.find((r) => r.conflictId === c.conflictId);
        return (
          <li
            key={c.conflictId}
            className="rounded-md border border-border/60 bg-card p-3"
          >
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-xs text-muted-foreground">{c.conflictId}</span>
              <code className="rounded bg-muted/40 px-1.5 py-0.5 text-[11px] font-mono">{c.file}</code>
              <RiskBadge level={c.riskLevel} />
              <StatusPill status={c.status} />
            </div>
            {res ? (
              <div className="mt-2 space-y-1.5 border-t border-border/40 pt-2">
                <p className="text-xs">
                  <span className="text-muted-foreground">Strategy:</span>{' '}
                  <span className="font-medium">{res.strategy.replace('_', ' ')}</span>
                  {' · '}
                  <span className="text-muted-foreground">Confidence:</span>{' '}
                  <span className="font-medium tabular-nums">{Math.round(res.confidence * 100)}%</span>
                </p>
                {res.reasoning ? (
                  <p className="text-xs text-muted-foreground leading-relaxed">{res.reasoning}</p>
                ) : null}
                {res.evidence.length > 0 ? (
                  <ul className="flex flex-col gap-0.5">
                    {res.evidence.map((e, i) => (
                      <li key={i} className="flex items-start gap-1.5 text-[11px] text-muted-foreground">
                        <CircleSlash className="mt-0.5 size-3 shrink-0 text-slate-400" />
                        {e}
                      </li>
                    ))}
                  </ul>
                ) : null}
                <div className="flex items-center gap-2 pt-1">
                  <span className="text-[10.5px] uppercase tracking-wide text-muted-foreground/70">Validation</span>
                  {res.validationPassed ? (
                    <span className="inline-flex items-center gap-1 text-xs text-brand-700 dark:text-brand-400">
                      <CheckCircle2 className="size-3.5" /> passed
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs text-rose-700 dark:text-rose-400">
                      <AlertTriangle className="size-3.5" /> not yet validated
                    </span>
                  )}
                </div>
              </div>
            ) : (
              <p className="mt-1 text-xs text-muted-foreground">
                {c.status === 'analyzing'
                  ? 'Analyzing…'
                  : c.status === 'detected'
                    ? 'Detected — waiting for resolution.'
                    : 'No resolution yet.'}
              </p>
            )}
          </li>
        );
      })}
    </motion.ul>
  );
}

function ValidationTab({ report }: { report?: ReleaseValidationReport }) {
  if (!report) {
    return (
      <EmptyState
        icon={<CheckCircle2 className="size-5" />}
        title="Validation not started"
        description="The agent runs JSON schema, duplicate-id, referential integrity, and no-mass-deletion validators after applying the changes."
      />
    );
  }
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.15 }}
      className="space-y-3"
    >
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Stat label="Files changed" value={report.filesChanged} />
        <Stat label="Added" value={report.recordsAdded} tone="brand" />
        <Stat label="Updated" value={report.recordsUpdated} tone="amber" />
        <Stat label="Deleted" value={report.recordsDeleted} tone="rose" />
      </div>
      <div
        className={cn(
          'flex items-center gap-2 rounded-md border p-3',
          report.passed
            ? 'border-brand-500/30 bg-brand-500/5'
            : 'border-rose-500/30 bg-rose-500/5',
        )}
      >
        {report.passed ? (
          <CheckCircle2 className="size-5 text-brand-600 dark:text-brand-400" />
        ) : (
          <AlertTriangle className="size-5 text-rose-600 dark:text-rose-400" />
        )}
        <div className="flex flex-col">
          <p className={cn('text-sm font-medium', report.passed ? 'text-brand-700 dark:text-brand-400' : 'text-rose-700 dark:text-rose-400')}>
            {report.passed ? 'Validation passed' : 'Validation failed'}
          </p>
          <p className="text-xs text-muted-foreground">
            Risk level: <span className="capitalize">{report.riskLevel}</span>
            {report.errors.length > 0 ? ` · ${report.errors.length} errors` : ''}
            {report.warnings.length > 0 ? ` · ${report.warnings.length} warnings` : ''}
          </p>
        </div>
        <RiskBadge level={report.riskLevel} className="ml-auto" />
      </div>
      <div className="rounded-md border border-border/60">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/30">
              <TableHead className="w-16">Status</TableHead>
              <TableHead>Validator</TableHead>
              <TableHead>Message</TableHead>
              <TableHead>File</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {report.results.map((r, i) => (
              <TableRow key={i}>
                <TableCell>
                  {r.status === 'pass' ? (
                    <span className="inline-flex items-center gap-1 text-xs text-brand-700 dark:text-brand-400">
                      <CheckCircle2 className="size-3.5" /> pass
                    </span>
                  ) : r.status === 'warning' ? (
                    <span className="inline-flex items-center gap-1 text-xs text-amber-700 dark:text-amber-400">
                      <AlertTriangle className="size-3.5" /> warn
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs text-rose-700 dark:text-rose-400">
                      <AlertTriangle className="size-3.5" /> fail
                    </span>
                  )}
                </TableCell>
                <TableCell className="font-mono text-[11px]">{r.validator}</TableCell>
                <TableCell className="text-xs">{r.message}</TableCell>
                <TableCell className="font-mono text-[11px] text-muted-foreground">{r.file ?? '—'}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      {(report.warnings.length > 0 || report.errors.length > 0) && (
        <div className="grid gap-2 sm:grid-cols-2">
          {report.warnings.length > 0 ? (
            <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-3">
              <p className="text-[10.5px] uppercase tracking-wide text-amber-700 dark:text-amber-400 font-medium">
                Warnings
              </p>
              <ul className="mt-1 flex flex-col gap-0.5 text-xs text-muted-foreground">
                {report.warnings.map((w, i) => (
                  <li key={i}>• {w}</li>
                ))}
              </ul>
            </div>
          ) : null}
          {report.errors.length > 0 ? (
            <div className="rounded-md border border-rose-500/30 bg-rose-500/5 p-3">
              <p className="text-[10.5px] uppercase tracking-wide text-rose-700 dark:text-rose-400 font-medium">
                Errors
              </p>
              <ul className="mt-1 flex flex-col gap-0.5 text-xs text-muted-foreground">
                {report.errors.map((w, i) => (
                  <li key={i}>• {w}</li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
      )}
    </motion.div>
  );
}

function Stat({ label, value, tone = 'slate' }: { label: string; value: number; tone?: 'slate' | 'brand' | 'amber' | 'rose' }) {
  const toneClass =
    tone === 'brand'
      ? 'text-brand-700 dark:text-brand-400'
      : tone === 'amber'
        ? 'text-amber-700 dark:text-amber-400'
        : tone === 'rose'
          ? 'text-rose-700 dark:text-rose-400'
          : 'text-foreground';
  return (
    <div className="rounded-md border border-border/60 bg-muted/20 p-3">
      <p className="text-[10.5px] uppercase tracking-wide text-muted-foreground/80">{label}</p>
      <p className={cn('mt-1 text-xl font-semibold tabular-nums', toneClass)}>{value}</p>
    </div>
  );
}

function DeploymentTab({ deployment }: { deployment?: DeploymentStatus }) {
  if (!deployment) {
    return (
      <EmptyState
        icon={<CloudUpload className="size-5" />}
        title="No deployment yet"
        description="Once the changes are validated and integrated, the agent will trigger the Jenkins deployment job. Live build progress will appear here."
      />
    );
  }
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.15 }}
      className="space-y-3"
    >
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-mono text-xs text-muted-foreground">{deployment.deploymentId}</span>
        <StatusPill status={deployment.status} />
        {deployment.retryCount > 0 ? (
          <span className="text-xs text-amber-700 dark:text-amber-400">
            ↻ retried {deployment.retryCount}×
          </span>
        ) : null}
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        <KV label="Jenkins job" value={deployment.jenkinsJob} mono />
        <KV label="Build number" value={deployment.buildNumber ? `#${deployment.buildNumber}` : '—'} mono />
        <KV label="Stage" value={deployment.stage ?? '—'} />
        <KV label="Duration" value={deployment.durationMs ? formatDuration(deployment.durationMs) : '—'} />
      </div>
      {deployment.failureAnalysis ? (
        <div className="rounded-md border border-rose-500/30 bg-rose-500/5 p-3">
          <p className="flex items-center gap-1.5 text-sm font-medium text-rose-700 dark:text-rose-400">
            <AlertTriangle className="size-4" /> AI failure analysis
          </p>
          <p className="mt-1.5 text-xs text-foreground/90 leading-relaxed">
            {deployment.failureAnalysis.likelyCause}
          </p>
          {deployment.failureAnalysis.evidence.length > 0 ? (
            <ul className="mt-1.5 flex flex-col gap-0.5">
              {deployment.failureAnalysis.evidence.map((e, i) => (
                <li key={i} className="flex items-start gap-1.5 text-[11px] text-muted-foreground">
                  <span className="mt-1.5 size-1 rounded-full bg-rose-500/60" />
                  <code className="font-mono text-[10.5px]">{e}</code>
                </li>
              ))}
            </ul>
          ) : null}
          <div className="mt-2 flex items-center gap-3 text-xs">
            <span className="text-muted-foreground">
              Recommended: <span className="font-medium">{deployment.failureAnalysis.recommendedAction.replace(/_/g, ' ')}</span>
            </span>
            <span
              className={cn(
                'inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 text-[10px] font-medium',
                deployment.failureAnalysis.retryable
                  ? 'border-amber-500/30 bg-amber-500/10 text-amber-700 dark:text-amber-400'
                  : 'border-rose-500/30 bg-rose-500/10 text-rose-700 dark:text-rose-400',
              )}
            >
              {deployment.failureAnalysis.retryable ? 'retryable' : 'not retryable'}
            </span>
          </div>
          {typeof deployment.failureAnalysis.confidence === 'number' && (
            <div className="mt-2">
              <p className="text-[10.5px] text-muted-foreground/80">
                Model confidence: {Math.round(deployment.failureAnalysis.confidence * 100)}%
              </p>
              <Progress
                value={Math.round(deployment.failureAnalysis.confidence * 100)}
                className="mt-1 h-1.5"
              />
            </div>
          )}
        </div>
      ) : null}
    </motion.div>
  );
}

function KV({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="rounded-md border border-border/60 bg-muted/20 px-3 py-2">
      <p className="text-[10.5px] uppercase tracking-wide text-muted-foreground/80">{label}</p>
      <p className={cn('mt-0.5 text-sm font-medium', mono && 'font-mono text-xs')}>{value}</p>
    </div>
  );
}
