'use client';

import * as React from 'react';
import { cn } from '@/lib/utils';
import { formatTime } from '@/lib/format';
import type { AgentEventPayload } from '@/lib/agent/types';

// Map event-name → category → color. Categories: workflow, jira, pr,
// approval, git, conflict, validation, deployment, release, supervisor, report, default.
type EventCategory =
  | 'workflow'
  | 'supervisor'
  | 'jira'
  | 'pr'
  | 'approval'
  | 'git'
  | 'conflict'
  | 'validation'
  | 'deployment'
  | 'release'
  | 'report'
  | 'system'
  | 'default';

const CATEGORY_COLOR: Record<EventCategory, string> = {
  workflow: 'bg-slate-500/15 text-slate-600 dark:text-slate-300 border-slate-500/30',
  supervisor: 'bg-brand-500/15 text-brand-700 dark:text-brand-400 border-brand-500/30',
  jira: 'bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30',
  pr: 'bg-brand-500/15 text-brand-700 dark:text-brand-400 border-brand-500/30',
  approval: 'bg-brand-500/15 text-brand-700 dark:text-brand-400 border-brand-500/30',
  git: 'bg-slate-500/15 text-slate-600 dark:text-slate-300 border-slate-500/30',
  conflict: 'bg-rose-500/15 text-rose-700 dark:text-rose-400 border-rose-500/30',
  validation: 'bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30',
  deployment: 'bg-brand-500/15 text-brand-700 dark:text-brand-400 border-brand-500/30',
  release: 'bg-brand-500/15 text-brand-700 dark:text-brand-400 border-brand-500/30',
  report: 'bg-slate-500/15 text-slate-600 dark:text-slate-300 border-slate-500/30',
  system: 'bg-slate-500/15 text-slate-500 dark:text-slate-400 border-slate-500/30',
  default: 'bg-slate-500/15 text-slate-600 dark:text-slate-300 border-slate-500/30',
};

function categorize(eventName: string): EventCategory {
  if (eventName.startsWith('workflow.')) return 'workflow';
  if (eventName.startsWith('supervisor.')) return 'supervisor';
  if (eventName.startsWith('jira.')) return 'jira';
  if (eventName.startsWith('pr.')) return 'pr';
  if (eventName.startsWith('approval.')) return 'approval';
  if (eventName.startsWith('git.')) return 'git';
  if (eventName.startsWith('conflict.')) return 'conflict';
  if (eventName.startsWith('validation.')) return 'validation';
  if (eventName.startsWith('deployment.')) return 'deployment';
  if (eventName.startsWith('release.')) return 'release';
  if (eventName.startsWith('report.')) return 'report';
  if (eventName === 'hello' || eventName === 'ping') return 'system';
  return 'default';
}

// Concise human summary of an event payload.
function summarizeEvent(ev: AgentEventPayload): string {
  const e = ev.event;
  const get = (k: string) => (ev[k] !== undefined ? String(ev[k]) : null);
  switch (e) {
    case 'workflow.step.started':
      return `Step started${ev.step ? `: ${ev.step}` : ''}`;
    case 'workflow.step.completed':
      return `Step completed${ev.step ? `: ${ev.step}` : ''}`;
    case 'workflow.step.failed':
      return `Step failed${ev.step ? `: ${ev.step}` : ''}${ev.error ? ` — ${ev.error}` : ''}`;
    case 'workflow.completed':
      return `Workflow completed${ev.summary ? ` — ${ev.summary}` : ''}`;
    case 'workflow.failed':
      return `Workflow failed${ev.error ? ` — ${ev.error}` : ''}`;
    case 'workflow.blocked':
      return `Workflow blocked${ev.reason ? ` — ${ev.reason}` : ''}`;
    case 'workflow.cancelled':
      return 'Workflow cancelled';
    case 'supervisor.interpreted':
      return `Intent: ${get('intent') ?? '—'}${get('mode') ? ` (mode ${get('mode')})` : ''}`;
    case 'jira.tickets_discovered':
      return `${get('count') ?? '?'} Jira tickets discovered`;
    case 'pr.discovered':
      return `${get('count') ?? '?'} pull requests discovered`;
    case 'jira_pr.correlated':
      return `Correlated ${get('ticket') ?? get('jiraKey') ?? '?'} ↔ PR ${get('prNumber') ?? '?'}`;
    case 'approval.verified':
      return `Approval verified for ${get('ticket') ?? '?'}`;
    case 'approval.blocked':
      return `Approval blocked for ${get('ticket') ?? '?'}${ev.reason ? ` — ${ev.reason}` : ''}`;
    case 'git.cloned':
      return `Cloned ${get('repo') ?? 'repository'}`;
    case 'git.fetched':
      return 'Fetched latest state';
    case 'git.workspace_created':
      return `Workspace ${get('path') ?? ''}`;
    case 'git.merge.success':
      return `Merge OK · PR ${get('prNumber') ?? '?'}`;
    case 'git.cherry_pick.success':
      return `Cherry-pick OK · PR ${get('prNumber') ?? '?'}${ev.commitSha ? ` (${ev.commitSha})` : ''}`;
    case 'git.conflict.detected':
      return `Conflict on ${get('file') ?? 'unknown file'}${ev.prNumber ? ` (PR ${ev.prNumber})` : ''}`;
    case 'conflict.analyzing':
      return `Analyzing conflict ${get('conflictId') ?? ''}`;
    case 'conflict.resolved':
      return `Conflict ${get('conflictId') ?? ''} resolved (${get('strategy') ?? '?'})`;
    case 'conflict.blocked':
      return `Conflict ${get('conflictId') ?? ''} blocked`;
    case 'conflict.failed':
      return `Conflict ${get('conflictId') ?? ''} failed`;
    case 'validation.completed':
      return `Validation ${ev.passed ? 'passed' : 'failed'} (+${get('recordsAdded') ?? 0}/~${get('recordsUpdated') ?? 0}/-${get('recordsDeleted') ?? 0})`;
    case 'git.race_detected':
      return `Git race detected — re-running`;
    case 'git.pushed':
      return `Pushed release branch${get('branch') ? ` (${ev.branch})` : ''}`;
    case 'jira.updated':
      return `Updated Jira ${get('ticket') ?? '?'}`;
    case 'deployment.started':
      return `Jenkins build ${get('buildNumber') ?? ''} started`;
    case 'deployment.progress':
      return `Jenkins stage: ${get('stage') ?? ''}`;
    case 'deployment.completed':
      return `Deployment ${get('status') ?? 'completed'}`;
    case 'deployment.failed':
      return `Deployment failed at ${get('stage') ?? 'unknown'}`;
    case 'deployment.retry':
      return `Retrying build (attempt ${get('attempt') ?? '?'})`;
    case 'report.generated':
      return `Report generated${ev.summary ? ` — ${ev.summary}` : ''}`;
    case 'release.plan_built':
      return `Release plan built (${get('items') ?? '?'})`;
    case 'release.item.skipped':
      return `Skipped ${get('jiraKey') ?? get('prNumber') ?? 'item'}`;
    case 'release.item.blocked':
      return `Blocked ${get('jiraKey') ?? get('prNumber') ?? 'item'}`;
    case 'release.item.failed':
      return `Failed ${get('jiraKey') ?? get('prNumber') ?? 'item'}`;
    case 'hello':
      return `Stream connected · run ${get('workflowId') ?? ''}`;
    default:
      return e.replace(/[._]/g, ' ');
  }
}

export interface EventFeedProps {
  events: AgentEventPayload[];
  maxItems?: number;
  className?: string;
  autoScroll?: boolean;
}

export function EventFeed({ events, maxItems = 200, className, autoScroll = true }: EventFeedProps) {
  // Show newest first; trim to maxItems.
  const list = React.useMemo(() => {
    return events.slice(0, maxItems);
  }, [events, maxItems]);

  const ref = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (!autoScroll) return;
    // Scroll to top when a new event arrives.
    if (ref.current) ref.current.scrollTop = 0;
  }, [list.length, autoScroll]);

  return (
    <div
      ref={ref}
      role="log"
      aria-live="polite"
      className={cn(
        'scrollbar-thin max-h-96 overflow-y-auto rounded-md border border-border/60 bg-muted/20',
        className,
      )}
    >
      {list.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-2 py-10 text-xs text-muted-foreground">
          <span className="flex size-8 items-center justify-center rounded-full bg-muted">
            <span className="size-2 rounded-full bg-muted-foreground/40" />
          </span>
          <span>Waiting for events…</span>
        </div>
      ) : (
        <ul className="divide-y divide-border/40">
          {list.map((ev, i) => {
            const cat = categorize(ev.event ?? 'default');
            return (
              <li
                key={`${ev.timestamp}-${i}`}
                className="flex items-start gap-2 px-2.5 py-1.5 text-xs hover:bg-muted/40 transition-colors"
              >
                <span className="font-mono text-[10.5px] text-muted-foreground/80 mt-0.5 shrink-0 tabular-nums">
                  {formatTime(ev.timestamp)}
                </span>
                <span
                  className={cn(
                    'shrink-0 rounded-md border px-1.5 py-0.5 text-[10px] font-medium leading-tight',
                    CATEGORY_COLOR[cat],
                  )}
                >
                  {ev.event ?? 'event'}
                </span>
                <span className="text-foreground/90 leading-relaxed">{summarizeEvent(ev)}</span>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
