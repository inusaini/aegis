'use client';

import * as React from 'react';
import { ArrowDownRight, ArrowUpRight, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';

interface StatCardProps {
  label: string;
  value: number | string;
  icon: React.ReactNode;
  /** Optional delta value; if provided, shows an up/down arrow with the value. */
  delta?: number;
  /** When `delta` is provided, indicates whether up is good or bad. */
  positiveIsGood?: boolean;
  /** Optional subtitle / hint. */
  hint?: string;
  /** Accent color for the icon container. */
  tone?: 'brand' | 'amber' | 'rose' | 'slate';
}

const TONE_CLASS: Record<NonNullable<StatCardProps['tone']>, string> = {
  brand: 'bg-brand-500/10 text-brand-700 dark:text-brand-400 border-brand-500/20',
  amber: 'bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/20',
  rose: 'bg-rose-500/10 text-rose-700 dark:text-rose-400 border-rose-500/20',
  slate: 'bg-slate-500/10 text-slate-600 dark:text-slate-300 border-slate-500/20',
};

export function StatCard({
  label,
  value,
  icon,
  delta,
  positiveIsGood = true,
  hint,
  tone = 'slate',
}: StatCardProps) {
  const showDelta = typeof delta === 'number' && Number.isFinite(delta);
  const isUp = showDelta ? (delta as number) > 0 : false;
  const isDown = showDelta ? (delta as number) < 0 : false;
  const isFlat = showDelta ? (delta as number) === 0 : false;
  const deltaGood =
    !showDelta || isFlat
      ? null
      : positiveIsGood
        ? isUp
        : isDown;

  return (
    <Card className="py-3 gap-2 overflow-hidden">
      <CardContent className="flex items-start gap-3 pt-0">
        <div className={cn('flex size-9 shrink-0 items-center justify-center rounded-lg border', TONE_CLASS[tone])}>
          {icon}
        </div>
        <div className="flex min-w-0 flex-1 flex-col gap-0.5">
          <p className="text-[11.5px] font-medium uppercase tracking-wide text-muted-foreground/85">
            {label}
          </p>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-semibold tabular-nums leading-none">
              {value}
            </span>
            {showDelta ? (
              <span
                className={cn(
                  'inline-flex items-center gap-0.5 text-[11px] font-medium',
                  deltaGood === null
                    ? 'text-muted-foreground'
                    : deltaGood
                      ? 'text-brand-600 dark:text-brand-400'
                      : 'text-rose-600 dark:text-rose-400',
                )}
              >
                {isUp ? (
                  <ArrowUpRight className="size-3" />
                ) : isDown ? (
                  <ArrowDownRight className="size-3" />
                ) : (
                  <Minus className="size-3" />
                )}
                {Math.abs(delta as number)}
              </span>
            ) : null}
          </div>
          {hint ? (
            <p className="text-[11px] text-muted-foreground/80 truncate" title={hint}>
              {hint}
            </p>
          ) : null}
        </div>
      </CardContent>
    </Card>
  );
}
