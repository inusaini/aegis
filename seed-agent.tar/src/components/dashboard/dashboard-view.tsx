'use client';

import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  GitBranch,
  GitPullRequest,
  Server,
  Ticket,
  XCircle,
  Boxes,
  Bot,
} from 'lucide-react';
import { api, type DashboardResponse } from '@/lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { StatusPill, RiskBadge, ModeBadge } from '@/components/common/status-pill';
import { useUIStore } from '@/stores/ui-store';
import { Button } from '@/components/ui/button';
import { formatDistanceToNow } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';

export function DashboardView() {
  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['dashboard'],
    queryFn: api.dashboard,
    refetchInterval: 5000,
  });

  if (isError) {
    return (
      <div className="p-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-rose-700">
              <AlertTriangle className="h-4 w-4" /> Dashboard unavailable
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-slate-600 dark:text-slate-300">
              The dashboard API returned an error. The backend may be starting up.
            </p>
            <Button className="mt-3" size="sm" onClick={() => refetch()}>
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading || !data) {
    return <DashboardSkeleton />;
  }

  return <DashboardContent data={data} />;
}

function DashboardContent({ data }: { data: DashboardResponse }) {
  const setView = useUIStore((s) => s.setView);
  const setActiveRunId = useUIStore((s) => s.setActiveRunId);

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Operations Dashboard</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Real-time view of releases, agent runs, conflicts, and deployments.
        </p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
        <StatCard icon={Activity} label="Active Runs" value={data.metrics.activeRuns} tone="amber" onClick={() => setView('agent')} />
        <StatCard icon={Ticket} label="Pending Jira" value={data.metrics.pendingTickets} tone="slate" onClick={() => setView('jira')} />
        <StatCard icon={CheckCircle2} label="Approved PRs" value={data.metrics.approvedPRs} tone="brand" onClick={() => setView('prs')} />
        <StatCard icon={XCircle} label="Blocked PRs" value={data.metrics.blockedPRs} tone="rose" onClick={() => setView('prs')} />
        <StatCard icon={GitBranch} label="Active Conflicts" value={data.metrics.activeConflicts} tone="amber" onClick={() => setView('conflicts')} />
        <StatCard icon={Server} label="Resolved Conflicts" value={data.metrics.resolvedConflicts} tone="brand" onClick={() => setView('conflicts')} />
        <StatCard icon={GitPullRequest} label="Total PRs" value={data.metrics.totalPRs} tone="slate" onClick={() => setView('prs')} />
        <StatCard icon={Boxes} label="Releases" value={data.metrics.totalReleases} tone="brand" onClick={() => setView('releases')} />
        <StatCard icon={CheckCircle2} label="Successful" value={data.metrics.successfulReleases} tone="brand" onClick={() => setView('releases')} />
        <StatCard icon={AlertTriangle} label="Recent Failures" value={data.metrics.recentFailures} tone="rose" onClick={() => setView('deployments')} />
      </div>

      {/* Active agent runs */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Bot className="h-4 w-4 text-brand-600" /> Active Agent Runs
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setView('agent');
            }}
          >
            Open workspace
          </Button>
        </CardHeader>
        <CardContent>
          {data.recentRuns.filter((r) => r.status === 'running').length === 0 ? (
            <p className="text-sm text-slate-500 dark:text-slate-400">
              No active agent runs. Open the Agent Workspace to start one.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Run</TableHead>
                  <TableHead>Mode</TableHead>
                  <TableHead>Request</TableHead>
                  <TableHead>Step</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Started</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.recentRuns
                  .filter((r) => r.status === 'running')
                  .map((r) => (
                    <TableRow key={r.id}>
                      <TableCell className="font-mono text-xs">{r.runId}</TableCell>
                      <TableCell><ModeBadge mode={r.mode} /></TableCell>
                      <TableCell className="max-w-[280px] truncate text-sm">{r.userRequest}</TableCell>
                      <TableCell className="font-mono text-xs">{r.currentStep}</TableCell>
                      <TableCell><StatusPill status={r.status} /></TableCell>
                      <TableCell className="text-xs text-slate-500">
                        {r.startedAt ? formatDistanceToNow(new Date(r.startedAt), { addSuffix: true }) : '-'}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setActiveRunId(r.runId);
                            setView('agent');
                          }}
                        >
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Recent releases */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Recent Releases</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Release</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Approved</TableHead>
                  <TableHead>Conflicts</TableHead>
                  <TableHead>Risk</TableHead>
                  <TableHead>Deploy</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.recentReleases.map((r) => {
                  const deploy = r.deployments?.[0];
                  return (
                    <TableRow key={r.id} className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-900" onClick={() => { setView('releases'); }}>
                      <TableCell className="font-mono text-xs">{r.releaseId}</TableCell>
                      <TableCell><StatusPill status={r.status} /></TableCell>
                      <TableCell className="text-xs">{r.approvedTickets} / {r.totalTickets}</TableCell>
                      <TableCell className="text-xs">{r.conflictsCount}</TableCell>
                      <TableCell><RiskBadge level={r.riskLevel} /></TableCell>
                      <TableCell>{deploy ? <StatusPill status={deploy.status} /> : <span className="text-xs text-slate-400">—</span>}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Recent failures */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <AlertTriangle className="h-4 w-4 text-rose-600" /> Recent Failures
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data.recentDeployments.filter((d) => d.status === 'failed').length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400">No recent deployment failures.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Job</TableHead>
                    <TableHead>Build</TableHead>
                    <TableHead>Stage</TableHead>
                    <TableHead>Cause</TableHead>
                    <TableHead>Retryable</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.recentDeployments
                    .filter((d) => d.status === 'failed')
                    .map((d) => (
                      <TableRow key={d.id} className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-900" onClick={() => setView('deployments')}>
                        <TableCell className="font-mono text-xs">{d.jenkinsJob}</TableCell>
                        <TableCell className="font-mono text-xs">#{d.buildNumber}</TableCell>
                        <TableCell className="text-xs">{d.stage || '-'}</TableCell>
                        <TableCell className="max-w-[200px] truncate text-xs">
                          {d.failureAnalysis?.likelyCause || 'No AI analysis yet'}
                        </TableCell>
                        <TableCell>
                          {d.failureAnalysis?.retryable ? (
                            <span className="text-brand-600">yes</span>
                          ) : (
                            <span className="text-rose-600">no</span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent audit (last 8) */}
      <Card>
        <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
          <CardTitle className="text-base">Recent Activity</CardTitle>
          <Button variant="outline" size="sm" onClick={() => setView('audit')}>View full audit</Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>When</TableHead>
                <TableHead>Actor</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Resource</TableHead>
                <TableHead>Reason</TableHead>
                <TableHead>Result</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.recentAudit.slice(0, 8).map((a) => (
                <TableRow key={a.id}>
                  <TableCell className="text-xs text-slate-500">{formatDistanceToNow(new Date(a.createdAt), { addSuffix: true })}</TableCell>
                  <TableCell className="font-mono text-xs">{a.actor}</TableCell>
                  <TableCell className="font-mono text-xs">{a.action}</TableCell>
                  <TableCell className="font-mono text-xs">{a.resource || '-'}</TableCell>
                  <TableCell className="max-w-[280px] truncate text-xs">{a.reason}</TableCell>
                  <TableCell><StatusPill status={a.result} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  tone,
  onClick,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: number;
  tone: 'brand' | 'amber' | 'rose' | 'slate';
  onClick?: () => void;
}) {
  const tones = {
    brand: 'from-brand-500 to-brand-700 text-brand-50',
    amber: 'from-amber-500 to-amber-700 text-amber-50',
    rose: 'from-rose-500 to-rose-700 text-rose-50',
    slate: 'from-slate-500 to-slate-700 text-slate-50',
  };
  return (
    <motion.button
      type="button"
      onClick={onClick}
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      whileHover={{ y: -2 }}
      className="text-left"
    >
      <Card className="overflow-hidden">
        <div className={`flex items-center justify-between bg-gradient-to-br ${tones[tone]} p-3`}>
          <span className="text-xs font-medium opacity-90">{label}</span>
          <Icon className="h-4 w-4 opacity-80" />
        </div>
        <CardContent className="px-3 py-3">
          <div className="text-2xl font-semibold tracking-tight">{value}</div>
        </CardContent>
      </Card>
    </motion.button>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6 p-6">
      <Skeleton className="h-10 w-64" />
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {Array.from({ length: 10 }).map((_, i) => (
          <Skeleton key={i} className="h-24" />
        ))}
      </div>
      <Skeleton className="h-48" />
      <div className="grid gap-4 lg:grid-cols-2">
        <Skeleton className="h-48" />
        <Skeleton className="h-48" />
      </div>
    </div>
  );
}
