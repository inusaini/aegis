'use client';

import * as React from 'react';
import { cn } from '@/lib/utils';

export type RiskLevel = 'low' | 'medium' | 'high' | string;

interface RiskBadgeProps {
  level: RiskLevel;
  className?: string;
}

const RISK_CLASS: Record<'low' | 'medium' | 'high', string> = {
  low: 'bg-brand-500/15 text-brand-700 dark:text-brand-400 border-brand-500/30',
  medium: 'bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-500/30',
  high: 'bg-rose-500/15 text-rose-700 dark:text-rose-400 border-rose-500/30',
};

export function RiskBadge({ level, className }: RiskBadgeProps) {
  const lvl = (level || 'low').toLowerCase() as 'low' | 'medium' | 'high';
  const cls = RISK_CLASS[lvl] ?? RISK_CLASS.low;
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-xs font-medium',
        cls,
        className,
      )}
    >
      <span
        className={cn(
          'size-1.5 rounded-full',
          lvl === 'low' && 'bg-brand-500',
          lvl === 'medium' && 'bg-amber-500',
          lvl === 'high' && 'bg-rose-500',
        )}
        aria-hidden
      />
      <span className="capitalize">{lvl} risk</span>
    </span>
  );
}
