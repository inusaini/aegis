'use client';

import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

export function StatusPill({ status, className }: { status: string; className?: string }) {
  const cfg: Record<string, { cls: string; label: string; pulse?: boolean }> = {
    pending: { cls: 'bg-slate-100 text-slate-600 border-slate-200', label: 'Pending' },
    running: { cls: 'bg-amber-100 text-amber-700 border-amber-300', label: 'Running', pulse: true },
    building: { cls: 'bg-amber-100 text-amber-700 border-amber-300', label: 'Building', pulse: true },
    in_progress: { cls: 'bg-amber-100 text-amber-700 border-amber-300', label: 'In Progress', pulse: true },
    queued: { cls: 'bg-slate-100 text-slate-600 border-slate-200', label: 'Queued' },
    completed: { cls: 'bg-brand-100 text-brand-700 border-brand-300', label: 'Completed' },
    success: { cls: 'bg-brand-100 text-brand-700 border-brand-300', label: 'Success' },
    deployed: { cls: 'bg-brand-100 text-brand-700 border-brand-300', label: 'Deployed' },
    integrated: { cls: 'bg-brand-100 text-brand-700 border-brand-300', label: 'Integrated' },
    resolved: { cls: 'bg-brand-100 text-brand-700 border-brand-300', label: 'Resolved' },
    approved: { cls: 'bg-brand-100 text-brand-700 border-brand-300', label: 'Approved' },
    applied: { cls: 'bg-brand-100 text-brand-700 border-brand-300', label: 'Applied' },
    done: { cls: 'bg-brand-100 text-brand-700 border-brand-300', label: 'Done' },
    validated: { cls: 'bg-brand-100 text-brand-700 border-brand-300', label: 'Validated' },
    failed: { cls: 'bg-rose-100 text-rose-700 border-rose-300', label: 'Failed' },
    blocked: { cls: 'bg-rose-100 text-rose-700 border-rose-300', label: 'Blocked' },
    cancelled: { cls: 'bg-slate-100 text-slate-500 border-slate-200', label: 'Cancelled' },
    aborted: { cls: 'bg-slate-100 text-slate-500 border-slate-200', label: 'Aborted' },
    skipped: { cls: 'bg-slate-100 text-slate-400 border-slate-200', label: 'Skipped' },
    conflict: { cls: 'bg-amber-100 text-amber-700 border-amber-300', label: 'Conflict' },
    detected: { cls: 'bg-amber-100 text-amber-700 border-amber-300', label: 'Detected' },
    analyzing: { cls: 'bg-amber-100 text-amber-700 border-amber-300', label: 'Analyzing', pulse: true },
    open: { cls: 'bg-slate-100 text-slate-600 border-slate-200', label: 'Open' },
    in_review: { cls: 'bg-amber-100 text-amber-700 border-amber-300', label: 'In Review' },
    rejected: { cls: 'bg-rose-100 text-rose-700 border-rose-300', label: 'Rejected' },
    changes_requested: { cls: 'bg-rose-100 text-rose-700 border-rose-300', label: 'Changes Requested' },
    retrying: { cls: 'bg-amber-100 text-amber-700 border-amber-300', label: 'Retrying', pulse: true },
    planned: { cls: 'bg-slate-100 text-slate-600 border-slate-200', label: 'Planned' },
  };
  const c = cfg[status] ?? { cls: 'bg-slate-100 text-slate-600 border-slate-200', label: status };
  return (
    <Badge
      variant="outline"
      className={cn('font-medium', c.cls, c.pulse && 'animate-pulse', className)}
    >
      {c.label}
    </Badge>
  );
}

export function RiskBadge({ level }: { level: 'low' | 'medium' | 'high' | string }) {
  const cfg: Record<string, string> = {
    low: 'bg-brand-100 text-brand-700 border-brand-300',
    medium: 'bg-amber-100 text-amber-700 border-amber-300',
    high: 'bg-rose-100 text-rose-700 border-rose-300',
  };
  return (
    <Badge variant="outline" className={cn('capitalize', cfg[level] ?? cfg.low)}>
      {level}
    </Badge>
  );
}

export function ModeBadge({ mode }: { mode: string }) {
  const cfg: Record<string, string> = {
    observe: 'bg-slate-100 text-slate-700 border-slate-300',
    plan: 'bg-cyan-100 text-cyan-700 border-cyan-300',
    execute: 'bg-amber-100 text-amber-700 border-amber-300',
    release: 'bg-brand-100 text-brand-700 border-brand-300',
    recover: 'bg-violet-100 text-violet-700 border-violet-300',
  };
  return (
    <Badge variant="outline" className={cn('uppercase text-[10px] tracking-wide', cfg[mode] ?? cfg.observe)}>
      {mode}
    </Badge>
  );
}
