'use client';

import { useState } from 'react';
import { cn } from '@/lib/utils';

interface JsonViewerProps {
  data: unknown;
  className?: string;
  collapsed?: boolean;
}

export function JsonViewer({ data, className, collapsed: initialCollapsed = false }: JsonViewerProps) {
  const [collapsed, setCollapsed] = useState(initialCollapsed);
  const text = safeStringify(data, 2);
  return (
    <div className={cn('relative', className)}>
      <button
        type="button"
        onClick={() => setCollapsed((c) => !c)}
        className="absolute right-2 top-2 z-10 rounded border border-slate-200 bg-white px-2 py-0.5 text-[10px] text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
      >
        {collapsed ? 'expand' : 'collapse'}
      </button>
      <pre
        className={cn(
          'overflow-auto rounded-md bg-slate-50 p-3 font-mono text-xs leading-relaxed text-slate-800 dark:bg-slate-900/60 dark:text-slate-200',
          collapsed && 'max-h-32',
        )}
      >
        {collapsed ? text.slice(0, 400) + (text.length > 400 ? '\n… (truncated, click expand)' : '') : text}
      </pre>
    </div>
  );
}

function safeStringify(v: unknown, indent = 2): string {
  try {
    return JSON.stringify(v, null, indent) ?? String(v);
  } catch {
    return String(v);
  }
}
