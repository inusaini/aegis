'use client';

import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { StatusPill } from '@/components/common/status-pill';
import { Badge } from '@/components/ui/badge';
import { ScrollText } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format } from 'date-fns';
import { Input } from '@/components/ui/input';

export function AuditView() {
  const [filter, setFilter] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('');
  const [resultFilter, setResultFilter] = useState<string>('');
  const { data, isLoading } = useQuery({ queryKey: ['audit', 200], queryFn: () => api.listAudit(200), refetchInterval: 15000 });

  const filtered = useMemo(() => {
    const logs = data?.logs ?? [];
    return logs.filter((l) => {
      if (actionFilter && l.action !== actionFilter) return false;
      if (resultFilter && l.result !== resultFilter) return false;
      if (filter) {
        const q = filter.toLowerCase();
        const text = [l.actor, l.action, l.resource, l.reason].join(' ').toLowerCase();
        if (!text.includes(q)) return false;
      }
      return true;
    });
  }, [data, filter, actionFilter, resultFilter]);

  const actions = useMemo(() => Array.from(new Set((data?.logs ?? []).map((l) => l.action))), [data]);

  return (
    <div className="space-y-4 p-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Audit Log</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">Immutable record of every action the agent took on production resources.</p>
      </div>
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <ScrollText className="h-4 w-4 text-brand-600" /> Audit entries
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap gap-2">
            <Input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Search…" className="max-w-xs" />
            <select value={actionFilter} onChange={(e) => setActionFilter(e.target.value)} className="rounded-md border border-slate-200 bg-white px-2 py-2 text-xs dark:border-slate-700 dark:bg-slate-900">
              <option value="">All actions</option>
              {actions.map((a) => <option key={a} value={a}>{a}</option>)}
            </select>
            <select value={resultFilter} onChange={(e) => setResultFilter(e.target.value)} className="rounded-md border border-slate-200 bg-white px-2 py-2 text-xs dark:border-slate-700 dark:bg-slate-900">
              <option value="">All results</option>
              <option value="success">success</option>
              <option value="failed">failed</option>
              <option value="blocked">blocked</option>
            </select>
          </div>
          {isLoading || !data ? (
            <Skeleton className="h-64" />
          ) : (
            <ScrollArea className="h-[640px]">
              <Table>
                <TableHeader className="sticky top-0 bg-white dark:bg-slate-950">
                  <TableRow>
                    <TableHead>When</TableHead>
                    <TableHead>Actor</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>Resource</TableHead>
                    <TableHead>Reason</TableHead>
                    <TableHead>Result</TableHead>
                    <TableHead>Run</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((l) => (
                    <TableRow key={l.id}>
                      <TableCell className="whitespace-nowrap text-xs text-slate-500">{format(new Date(l.createdAt), "yyyy-MM-dd HH:mm:ss")}</TableCell>
                      <TableCell className="font-mono text-xs">{l.actor}</TableCell>
                      <TableCell><Badge variant="outline" className="font-mono text-xs">{l.action}</Badge></TableCell>
                      <TableCell className="font-mono text-xs">{l.resource ?? '-'}</TableCell>
                      <TableCell className="max-w-[320px] truncate text-xs">{l.reason ?? '-'}</TableCell>
                      <TableCell><StatusPill status={l.result} /></TableCell>
                      <TableCell className="font-mono text-xs text-slate-500">{l.run?.runId ?? '-'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

