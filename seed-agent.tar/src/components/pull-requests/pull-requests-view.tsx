'use client';

import * as React from 'react';
import {
  CheckCircle2,
  ChevronDown,
  FileCode,
  GitCommit,
  GitPullRequest,
  GitPullRequestArrow,
  RefreshCw,
  Users,
  XCircle,
} from 'lucide-react';
import { PageHeader } from '@/components/common/page-header';
import { SectionCard } from '@/components/common/section-card';
import { EmptyState } from '@/components/common/empty-state';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { StatusPill } from '@/components/common/status-pill';
import { api, type PullRequestRow } from '@/lib/api';
import { formatRelativeTime } from '@/lib/format';
import { cn } from '@/lib/utils';

export function PullRequestsView() {
  const [prs, setPRs] = React.useState<PullRequestRow[] | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [expanded, setExpanded] = React.useState<string | null>(null);

  const load = React.useCallback(async () => {
    try {
      const res = await api.listPRs();
      setPRs(res.pullRequests);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }, []);

  React.useEffect(() => {
    void load();
  }, [load]);

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Pull Requests"
        description="All Bitbucket pull requests correlated with Jira tickets. The agent uses PR state, reviewers, and mergeable flag to build the release plan."
        icon={<GitPullRequest className="size-5" />}
        actions={
          <Button variant="outline" size="sm" onClick={() => void load()}>
            <RefreshCw className="size-4" /> Refresh
          </Button>
        }
      />

      {error ? (
        <div className="rounded-lg border border-rose-500/30 bg-rose-500/5 p-4 text-sm text-rose-700 dark:text-rose-400">
          Failed to load pull requests: {error}
        </div>
      ) : null}

      <SectionCard
        title="All pull requests"
        description={`${prs?.length ?? 0} PRs tracked`}
        icon={<GitPullRequest className="size-3.5" />}
        bodyClassName="p-0"
      >
        {prs === null ? (
          <div className="space-y-2 p-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        ) : prs.length === 0 ? (
          <div className="p-4">
            <EmptyState
              icon={<GitPullRequest className="size-5" />}
              title="No pull requests"
              description="Bitbucket pull requests are seeded by the mock integration. They appear here once available."
            />
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/30">
                <TableHead className="w-8" />
                <TableHead>PR</TableHead>
                <TableHead className="min-w-64">Title</TableHead>
                <TableHead>Source → Target</TableHead>
                <TableHead>State</TableHead>
                <TableHead>Review</TableHead>
                <TableHead className="text-center">Reviewers</TableHead>
                <TableHead>Approved</TableHead>
                <TableHead>Mergeable</TableHead>
                <TableHead>Jira</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {prs.map((p) => {
                const isOpen = expanded === p.id;
                return (
                  <React.Fragment key={p.id}>
                    <TableRow className="cursor-pointer" onClick={() => setExpanded(isOpen ? null : p.id)}>
                      <TableCell className="w-8 p-2">
                        <ChevronDown
                          className={cn('size-4 text-muted-foreground transition-transform', isOpen && 'rotate-180')}
                        />
                      </TableCell>
                      <TableCell className="font-mono text-xs">#{p.prNumber}</TableCell>
                      <TableCell className="text-xs">
                        <span className="line-clamp-1">{p.title}</span>
                      </TableCell>
                      <TableCell className="font-mono text-[11px]">
                        <span className="text-muted-foreground">{p.sourceBranch}</span>
                        <span className="mx-1 text-muted-foreground/70">→</span>
                        <span>{p.targetBranch}</span>
                      </TableCell>
                      <TableCell><StatusPill status={p.state} /></TableCell>
                      <TableCell><StatusPill status={p.reviewStatus} /></TableCell>
                      <TableCell className="text-center text-xs tabular-nums">
                        <span className="font-mono">{p.reviewers}/{p.requiredReviewers}</span>
                      </TableCell>
                      <TableCell>
                        {p.approved ? (
                          <Badge className="border-brand-500/30 bg-brand-500/10 text-brand-700 dark:text-brand-400">
                            <CheckCircle2 className="size-3" /> approved
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="border-slate-500/30 bg-slate-500/10 text-slate-600 dark:text-slate-300">
                            <XCircle className="size-3" /> not approved
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {p.mergeable ? (
                          <span className="text-xs text-brand-700 dark:text-brand-400">mergeable</span>
                        ) : (
                          <span className="text-xs text-rose-700 dark:text-rose-400">conflict</span>
                        )}
                      </TableCell>
                      <TableCell className="font-mono text-xs">{p.jiraTicket?.key ?? '—'}</TableCell>
                    </TableRow>
                    {isOpen ? (
                      <TableRow className="bg-muted/20 hover:bg-muted/20">
                        <TableCell colSpan={10} className="p-0">
                          <PRExpanded pr={p} />
                        </TableCell>
                      </TableRow>
                    ) : null}
                  </React.Fragment>
                );
              })}
            </TableBody>
          </Table>
        )}
      </SectionCard>
    </div>
  );
}

function PRExpanded({ pr }: { pr: PullRequestRow }) {
  return (
    <div className="grid grid-cols-1 gap-3 px-4 py-4 lg:grid-cols-2">
      {/* Commits */}
      <div className="rounded-md border border-border/60 bg-background p-3">
        <p className="flex items-center gap-1.5 text-xs font-medium">
          <GitCommit className="size-3.5" /> Commits
        </p>
        {pr.commits.length === 0 ? (
          <p className="mt-1 text-xs text-muted-foreground">No commits recorded.</p>
        ) : (
          <ul className="mt-1.5 flex flex-col gap-1.5">
            {pr.commits.map((c) => (
              <li key={c.sha} className="text-xs">
                <div className="flex items-center gap-2">
                  <code className="font-mono text-[11px] text-brand-700 dark:text-brand-400">{c.sha.slice(0, 7)}</code>
                  <span className="text-[11px] text-muted-foreground">{c.author}</span>
                </div>
                <p className="mt-0.5 text-foreground/85 leading-relaxed">{c.message}</p>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Files changed */}
      <div className="rounded-md border border-border/60 bg-background p-3">
        <p className="flex items-center gap-1.5 text-xs font-medium">
          <FileCode className="size-3.5" /> Files changed
        </p>
        {pr.filesChanged.length === 0 ? (
          <p className="mt-1 text-xs text-muted-foreground">No files changed.</p>
        ) : (
          <ul className="mt-1.5 flex flex-col gap-1">
            {pr.filesChanged.map((f, i) => (
              <li key={i} className="flex items-center gap-2 text-xs">
                <code className="font-mono text-[11px]">{f.path}</code>
                <span className="ml-auto flex items-center gap-1.5 text-[11px]">
                  <span className="text-brand-700 dark:text-brand-400">+{f.additions}</span>
                  <span className="text-rose-700 dark:text-rose-400">-{f.deletions}</span>
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Review + meta */}
      <div className="rounded-md border border-border/60 bg-background p-3 lg:col-span-2">
        <p className="flex items-center gap-1.5 text-xs font-medium">
          <Users className="size-3.5" /> Review & metadata
        </p>
        <div className="mt-1.5 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
          <Meta label="Author" value={pr.author} mono />
          <Meta label="Created" value={formatRelativeTime(pr.createdAt)} />
          <Meta label="Description" value={pr.description ?? '—'} />
          <Meta label="State" value={pr.state} />
        </div>
      </div>
    </div>
  );
}

function Meta({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="rounded-md border border-border/60 bg-muted/20 px-3 py-2">
      <p className="text-[10.5px] uppercase tracking-wide text-muted-foreground/80">{label}</p>
      <p className={cn('mt-0.5 text-sm font-medium', mono && 'font-mono text-xs')}>{value}</p>
    </div>
  );
}
