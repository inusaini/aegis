'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { StatusPill } from '@/components/common/status-pill';
import { Badge } from '@/components/ui/badge';
import { GitPullRequest, ChevronRight, Check, X } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export function PullRequestsView() {
  const [selected, setSelected] = useState<string | null>(null);
  const { data, isLoading } = useQuery({ queryKey: ['prs'], queryFn: api.listPRs, refetchInterval: 15000 });

  return (
    <div className="space-y-4 p-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Pull Requests</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">Bitbucket PRs correlated with Jira tickets.</p>
      </div>
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <GitPullRequest className="h-4 w-4 text-brand-600" /> All PRs
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading || !data ? (
            <Skeleton className="h-48" />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>PR</TableHead>
                  <TableHead>Title</TableHead>
                  <TableHead>Branch</TableHead>
                  <TableHead>State</TableHead>
                  <TableHead>Reviewers</TableHead>
                  <TableHead>Approved</TableHead>
                  <TableHead>Mergeable</TableHead>
                  <TableHead>Jira</TableHead>
                  <TableHead>When</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.pullRequests.map((p) => (
                  <TableRow key={p.id} className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-900" onClick={() => setSelected(p.id)}>
                    <TableCell className="font-mono text-xs">PR-{p.prNumber}</TableCell>
                    <TableCell className="max-w-[280px] truncate text-sm">{p.title}</TableCell>
                    <TableCell className="font-mono text-xs">{p.sourceBranch}</TableCell>
                    <TableCell><StatusPill status={p.state} /></TableCell>
                    <TableCell className="text-xs">{p.reviewers} / {p.requiredReviewers}</TableCell>
                    <TableCell>{p.approved ? <Check className="h-4 w-4 text-brand-600" /> : <X className="h-4 w-4 text-rose-600" />}</TableCell>
                    <TableCell>{p.mergeable ? <Check className="h-4 w-4 text-brand-600" /> : <X className="h-4 w-4 text-rose-600" />}</TableCell>
                    <TableCell className="font-mono text-xs">{p.jiraTicket?.key ?? '-'}</TableCell>
                    <TableCell className="text-xs text-slate-500">{formatDistanceToNow(new Date(p.createdAt), { addSuffix: true })}</TableCell>
                    <TableCell><ChevronRight className="h-3 w-3 text-slate-400" /></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-2xl overflow-y-auto">
          <DialogHeader><DialogTitle>PR detail</DialogTitle></DialogHeader>
          {selected && <PRDetail id={selected} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function PRDetail({ id }: { id: string }) {
  const { data } = useQuery({ queryKey: ['prs'], queryFn: api.listPRs });
  const p = data?.pullRequests.find((x) => x.id === id);
  if (!p) return <Skeleton className="h-32" />;
  return (
    <div className="space-y-3 text-sm">
      <div className="flex items-center gap-2">
        <span className="font-mono text-base">PR-{p.prNumber}</span>
        <StatusPill status={p.state} />
        <StatusPill status={p.reviewStatus} />
      </div>
      <div className="font-medium">{p.title}</div>
      {p.description && <div className="text-xs text-slate-600 dark:text-slate-300">{p.description}</div>}
      <div className="grid grid-cols-2 gap-2 text-xs">
        <Field label="Source branch" value={p.sourceBranch} />
        <Field label="Target branch" value={p.targetBranch} />
        <Field label="Author" value={p.author} />
        <Field label="Reviewers" value={`${p.reviewers} / ${p.requiredReviewers}`} />
      </div>
      <div className="flex items-center gap-3">
        <span className="text-xs">approved:</span> {p.approved ? <Badge variant="outline" className="text-brand-700">yes</Badge> : <Badge variant="outline" className="text-rose-700">no</Badge>}
        <span className="text-xs">mergeable:</span> {p.mergeable ? <Badge variant="outline" className="text-brand-700">yes</Badge> : <Badge variant="outline" className="text-rose-700">no</Badge>}
        <span className="text-xs">jira:</span> <Badge variant="outline" className="font-mono">{p.jiraTicket?.key ?? '-'}</Badge>
      </div>
      <div>
        <div className="text-xs font-medium">Commits</div>
        <div className="mt-1 space-y-1">
          {p.commits.map((c) => (
            <div key={c.sha} className="flex items-start gap-2 rounded-md border border-slate-200 p-2 text-xs dark:border-slate-800">
              <span className="font-mono text-slate-500">{c.sha.slice(0, 8)}</span>
              <span>{c.message}</span>
              <span className="ml-auto text-slate-400">{c.author}</span>
            </div>
          ))}
        </div>
      </div>
      <div>
        <div className="text-xs font-medium">Files changed</div>
        <div className="mt-1 space-y-1">
          {p.filesChanged.map((f, i) => (
            <div key={i} className="flex items-center gap-2 rounded-md border border-slate-200 p-2 text-xs dark:border-slate-800">
              <span className="font-mono">{f.path}</span>
              <span className="ml-auto text-brand-600">+{f.additions}</span>
              <span className="text-rose-600">-{f.deletions}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-slate-200 p-2 dark:border-slate-800">
      <div className="text-[10px] uppercase tracking-wide text-slate-400">{label}</div>
      <div className="font-mono text-xs">{value}</div>
    </div>
  );
}

