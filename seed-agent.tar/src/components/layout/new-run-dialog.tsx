'use client';

import * as React from 'react';
import { Sparkles } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { CommandBar } from '@/components/agent-workspace/command-bar';
import { useUIStore } from '@/stores/ui-store';

/** Dialog containing the command bar — triggered by the header "New Run" button. */
export function NewRunDialog() {
  const open = useUIStore((s) => s.newRunOpen);
  const setOpen = useUIStore((s) => s.setNewRunOpen);
  const openRun = useUIStore((s) => s.openRun);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="size-4 text-brand-600 dark:text-brand-400" />
            Start a new agent run
          </DialogTitle>
          <DialogDescription>
            Describe what you want the agent to do in natural language. Choose a mode
            and press Run — the agent will open a workspace and start executing.
          </DialogDescription>
        </DialogHeader>
        <CommandBar
          compact
          onStarted={(runId) => {
            setOpen(false);
            openRun(runId);
          }}
        />
      </DialogContent>
    </Dialog>
  );
}

export default NewRunDialog;
