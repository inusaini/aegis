'use client';

export function Footer() {
  return (
    <footer className="mt-auto border-t border-slate-200 bg-white py-4 dark:border-slate-800 dark:bg-slate-950">
      <div className="flex flex-col items-center justify-between gap-2 px-6 text-xs text-slate-500 dark:text-slate-400 sm:flex-row">
        <div className="flex items-center gap-2">
          <span className="font-medium text-slate-700 dark:text-slate-300">AI Seed Release Engineer</span>
          <span className="text-slate-300 dark:text-slate-600">·</span>
          <span>autonomous</span>
          <span className="text-slate-300 dark:text-slate-600">·</span>
          <span>auditable</span>
          <span className="text-slate-300 dark:text-slate-600">·</span>
          <span>safe</span>
        </div>
        <div className="flex items-center gap-3">
          <span>LangGraph-style TS orchestrator</span>
          <span className="text-slate-300 dark:text-slate-600">·</span>
          <span>z-ai-web-dev-sdk</span>
          <span className="text-slate-300 dark:text-slate-600">·</span>
          <span>Prisma · SQLite</span>
        </div>
      </div>
    </footer>
  );
}
