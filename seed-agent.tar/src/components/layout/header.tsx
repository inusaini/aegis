'use client';

import Link from 'next/link';
import { Activity, Bot, Github, Menu, Moon, Sun } from 'lucide-react';
import { useTheme } from 'next-themes';
import { Button } from '@/components/ui/button';
import { useUIStore } from '@/stores/ui-store';

export function Header() {
  const { theme, setTheme } = useTheme();
  const setSidebarOpen = useUIStore((s) => s.setSidebarOpen);
  return (
    <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-slate-200 bg-white/95 backdrop-blur px-4 dark:border-slate-800 dark:bg-slate-950/95">
      <div className="flex items-center gap-3">
        <button
          type="button"
          className="md:hidden rounded-md p-2 hover:bg-slate-100 dark:hover:bg-slate-800"
          onClick={() => setSidebarOpen(true)}
          aria-label="Open menu"
        >
          <Menu className="h-4 w-4" />
        </button>
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-brand-500 to-brand-700 text-white">
            <Bot className="h-4 w-4" />
          </div>
          <div className="leading-tight">
            <div className="text-sm font-semibold tracking-tight">AI Seed Release Engineer</div>
            <div className="text-[10px] text-slate-500 dark:text-slate-400">autonomous · auditable · safe</div>
          </div>
        </Link>
        <div className="ml-2 hidden items-center gap-1 rounded-full border border-brand-200 bg-brand-50 px-2 py-0.5 text-[10px] font-medium text-brand-700 dark:border-brand-800 dark:bg-brand-950 dark:text-brand-300 sm:flex">
          <Activity className="h-3 w-3" /> live
        </div>
      </div>
      <div className="flex items-center gap-2">
        <a
          href="https://bitbucket.corp.io/seed/seed-data"
          target="_blank"
          rel="noreferrer"
          className="hidden items-center gap-1 rounded-md border border-slate-200 px-2 py-1 text-xs text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800 sm:flex"
        >
          <Github className="h-3 w-3" /> seed-data
        </a>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          aria-label="Toggle theme"
        >
          <Sun className="h-4 w-4 dark:hidden" />
          <Moon className="h-4 w-4 hidden dark:block" />
        </Button>
      </div>
    </header>
  );
}
