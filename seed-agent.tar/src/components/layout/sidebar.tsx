'use client';

import {
  Activity,
  Boxes,
  GitBranch,
  GitPullRequest,
  ListChecks,
  ScrollText,
  Server,
  Ticket,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useUIStore, type ViewKey } from '@/stores/ui-store';

const NAV: { key: ViewKey; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { key: 'dashboard', label: 'Dashboard', icon: Activity },
  { key: 'agent', label: 'Agent Workspace', icon: Bot },
  { key: 'releases', label: 'Releases', icon: Boxes },
  { key: 'conflicts', label: 'Conflicts', icon: GitBranch },
  { key: 'deployments', label: 'Deployments', icon: Server },
  { key: 'jira', label: 'Jira Tickets', icon: Ticket },
  { key: 'prs', label: 'Pull Requests', icon: GitPullRequest },
  { key: 'audit', label: 'Audit Log', icon: ScrollText },
];

import { Bot } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';

function NavItems({ onNavigate }: { onNavigate?: () => void }) {
  const view = useUIStore((s) => s.view);
  const setView = useUIStore((s) => s.setView);
  return (
    <nav className="flex flex-col gap-1 p-3">
      {NAV.map((item) => {
        const Icon = item.icon;
        const active = view === item.key;
        return (
          <button
            key={item.key}
            type="button"
            onClick={() => {
              setView(item.key);
              onNavigate?.();
            }}
            className={cn(
              'flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors',
              active
                ? 'bg-brand-50 font-medium text-brand-700 dark:bg-brand-950 dark:text-brand-300'
                : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800',
            )}
          >
            <Icon className={cn('h-4 w-4', active ? 'text-brand-600 dark:text-brand-400' : 'text-slate-400')} />
            <span>{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

function Brand() {
  return (
    <div className="flex items-center gap-2 px-4 py-4">
      <div className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br from-brand-500 to-brand-700 text-white">
        <Bot className="h-4 w-4" />
      </div>
      <div className="leading-tight">
        <div className="text-sm font-semibold">Seed Release Agent</div>
        <div className="text-[10px] text-slate-500 dark:text-slate-400">v2026.09 · autonomous</div>
      </div>
    </div>
  );
}

function SystemStatus() {
  return (
    <div className="m-3 rounded-md border border-slate-200 bg-slate-50 p-3 text-xs dark:border-slate-800 dark:bg-slate-900/40">
      <div className="flex items-center justify-between">
        <span className="font-medium text-slate-700 dark:text-slate-300">System</span>
        <span className="flex items-center gap-1 text-brand-600 dark:text-brand-400">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-brand-500" /> operational
        </span>
      </div>
      <dl className="mt-2 grid grid-cols-2 gap-y-1 text-[11px] text-slate-500 dark:text-slate-400">
        <dt>LLM provider:</dt><dd className="text-right">z-ai</dd>
        <dt>Git backend:</dt><dd className="text-right">mock</dd>
        <dt>Policy:</dt><dd className="text-right">strict</dd>
        <dt>Checkpoints:</dt><dd className="text-right">on</dd>
      </dl>
    </div>
  );
}

export function Sidebar() {
  const sidebarOpen = useUIStore((s) => s.sidebarOpen);
  const setSidebarOpen = useUIStore((s) => s.setSidebarOpen);

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden w-64 shrink-0 border-r border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-950 md:block">
        <div className="flex h-full flex-col">
          <Brand />
          <ScrollArea className="flex-1">
            <NavItems />
          </ScrollArea>
          <SystemStatus />
        </div>
      </aside>

      {/* Mobile sheet */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="w-72 p-0">
          <SheetHeader className="p-0">
            <SheetTitle className="p-0">
              <Brand />
            </SheetTitle>
          </SheetHeader>
          <NavItems onNavigate={() => setSidebarOpen(false)} />
          <SystemStatus />
        </SheetContent>
      </Sheet>
    </>
  );
}

// Re-export ListChecks to avoid unused warning if it's not used
void ListChecks;
