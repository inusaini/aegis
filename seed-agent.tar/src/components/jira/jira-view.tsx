'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { StatusPill } from '@/components/common/status-pill';
import { Badge } from '@/components/ui/badge';
import { Ticket, ChevronRight, FileText } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export function JiraView() {
  const [selected, setSelected] = useState<string | null>(null);
  const { data, isLoading } = useQuery({ queryKey: ['jira'], queryFn: api.listJira, refetchInterval: 15000 });

  return (
    <div className="space-y-4 p-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Jira Tickets</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">Seed-data change requests with approval evidence.</p>
      </div>
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Ticket className="h-4 w-4 text-brand-600" /> All tickets
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading || !data ? (
            <Skeleton className="h-48" />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Key</TableHead>
                  <TableHead>Summary</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Assignee</TableHead>
                  <TableHead>PR</TableHead>
                  <TableHead>Approval</TableHead>
                  <TableHead>Updated</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.tickets.map((t) => (
                  <TableRow key={t.id} className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-900" onClick={() => setSelected(t.id)}>
                    <TableCell className="font-mono text-xs">{t.key}</TableCell>
                    <TableCell className="text-sm">{t.summary}</TableCell>
                    <TableCell><StatusPill status={t.status} /></TableCell>
                    <TableCell className="text-xs">{t.assignee ?? '-'}</TableCell>
                    <TableCell className="font-mono text-xs">{t.pullRequest ? `PR-${t.pullRequest.prNumber}` : '-'}</TableCell>
                    <TableCell>
                      {t.approvals.length > 0 ? (
                        <Badge variant="outline" className="text-brand-700">{t.approvals.length} evidence</Badge>
                      ) : (
                        <span className="text-xs text-slate-400">none</span>
                      )}
                    </TableCell>
                    <TableCell className="text-xs text-slate-500">{formatDistanceToNow(new Date(t.updatedAt), { addSuffix: true })}</TableCell>
                    <TableCell><ChevronRight className="h-3 w-3 text-slate-400" /></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-2xl overflow-y-auto">
          <DialogHeader><DialogTitle>Ticket detail</DialogTitle></DialogHeader>
          {selected && <TicketDetail id={selected} />}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function TicketDetail({ id }: { id: string }) {
  const { data } = useQuery({ queryKey: ['jira'], queryFn: api.listJira });
  const t = data?.tickets.find((x) => x.id === id);
  if (!t) return <Skeleton className="h-32" />;
  return (
    <div className="space-y-3 text-sm">
      <div className="flex items-center gap-2">
        <span className="font-mono text-base">{t.key}</span>
        <StatusPill status={t.status} />
      </div>
      <div className="text-sm font-medium">{t.summary}</div>
      <div className="text-xs text-slate-600 dark:text-slate-300">{t.description}</div>
      <div className="grid grid-cols-2 gap-2 text-xs">
        <Field label="Assignee" value={t.assignee ?? '-'} />
        <Field label="Reporter" value={t.reporter ?? '-'} />
        <Field label="Approval field" value={t.approvalField ?? '-'} />
        <Field label="PR URL" value={t.prUrl ?? '-'} />
      </div>

      {t.attachments.length > 0 && (
        <div>
          <div className="text-xs font-medium">Attachments</div>
          <div className="mt-1 space-y-1">
            {t.attachments.map((a) => (
              <div key={a.id} className="flex items-center gap-2 rounded-md border border-slate-200 p-2 text-xs dark:border-slate-800">
                <FileText className="h-3 w-3 text-slate-400" />
                <span className="font-mono">{a.filename}</span>
                <span className="text-slate-500">{(a.size / 1024).toFixed(1)}KB · {a.mimeType}</span>
                {a.isApproval && <Badge variant="outline" className="ml-auto text-brand-700">approval</Badge>}
              </div>
            ))}
          </div>
        </div>
      )}

      {t.approvals.length > 0 && (
        <div>
          <div className="text-xs font-medium">Approval evidence</div>
          <div className="mt-1 space-y-1">
            {t.approvals.map((a) => (
              <div key={a.id} className="rounded-md border border-brand-200 bg-brand-50 p-2 text-xs dark:border-brand-800 dark:bg-brand-950/30">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-brand-700">{a.source}</Badge>
                  <span className="ml-auto">confidence: {(a.confidence * 100).toFixed(0)}%</span>
                </div>
                <div className="mt-1">{a.evidence}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {t.comments.length > 0 && (
        <div>
          <div className="text-xs font-medium">Comments</div>
          <div className="mt-1 space-y-1.5">
            {t.comments.map((c) => (
              <div key={c.id} className="rounded-md border border-slate-200 p-2 text-xs dark:border-slate-800">
                <div className="text-slate-500">{c.author} · {formatDistanceToNow(new Date(c.createdAt), { addSuffix: true })}</div>
                <div className="mt-0.5">{c.body}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-slate-200 p-2 dark:border-slate-800">
      <div className="text-[10px] uppercase tracking-wide text-slate-400">{label}</div>
      <div className="font-mono text-xs">{value}</div>
    </div>
  );
}

